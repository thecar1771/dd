"""Train the compact conditional melody Transformer."""

from __future__ import annotations

import argparse
import json
import math
import random
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, List, Sequence, Tuple

import torch
from torch import Tensor, nn

try:
    import tomllib
except ModuleNotFoundError:  # Python 3.9 and 3.10
    import tomli as tomllib

from omr.data.manifest import load_manifest
from omr.models.melody_transformer import (
    MelodyTransformer,
    MelodyTransformerConfig,
)
from omr.music.tokenizer import OMRTokenizer


@dataclass(frozen=True)
class TrainingResult:
    initial_loss: float
    final_loss: float
    losses: List[float]
    sample_count: int
    seen_sample_count: int
    device: str
    checkpoint_path: Path
    seed: int
    steps: int
    runtime_seconds: float

    def json_dict(self) -> Dict[str, Any]:
        payload = asdict(self)
        payload["checkpoint_path"] = str(self.checkpoint_path)
        return payload


def _resolve_path(config_path: Path, value: str) -> Path:
    path = Path(value)
    if not path.is_absolute():
        path = config_path.parent / path
    return path.resolve()


def _read_config(config_path: Path) -> Dict[str, Any]:
    with config_path.open("rb") as config_file:
        payload = tomllib.load(config_file)
    if "training" not in payload or "model" not in payload:
        raise ValueError("config requires [training] and [model] sections")
    return payload


def _select_device(requested: str) -> torch.device:
    if requested == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if requested == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was required but is unavailable")
    if requested not in {"cpu", "cuda"}:
        raise ValueError("device must be one of: auto, cpu, cuda")
    return torch.device(requested)


def _collate(
    sequences: Sequence[Sequence[int]], pad_id: int, device: torch.device
) -> Tuple[Tensor, Tensor]:
    if not sequences:
        raise ValueError("training batch is empty")
    max_length = max(len(sequence) for sequence in sequences)
    if max_length < 2:
        raise ValueError("training sequence must contain at least two tokens")
    batch = torch.full(
        (len(sequences), max_length), pad_id, dtype=torch.long, device=device
    )
    for row, sequence in enumerate(sequences):
        batch[row, : len(sequence)] = torch.tensor(
            sequence, dtype=torch.long, device=device
        )
    inputs = batch[:, :-1]
    targets = batch[:, 1:].clone()
    targets[targets == pad_id] = -100
    return inputs, targets


def train(config_path: Path) -> TrainingResult:
    config_path = config_path.resolve()
    payload = _read_config(config_path)
    training = payload["training"]
    model_values = payload["model"]

    seed = int(training["seed"])
    steps = int(training["steps"])
    batch_size = int(training["batch_size"])
    learning_rate = float(training["learning_rate"])
    if steps <= 0 or batch_size <= 0 or learning_rate <= 0:
        raise ValueError("steps, batch_size, and learning_rate must be positive")

    random.seed(seed)
    torch.manual_seed(seed)
    device = _select_device(str(training.get("device", "auto")))
    if device.type == "cuda":
        torch.cuda.manual_seed_all(seed)
    if device.type == "cpu":
        # Avoid severe thread oversubscription on CI and developer workstations.
        torch.set_num_threads(int(training.get("cpu_threads", 1)))
    manifest_path = _resolve_path(config_path, str(training["manifest"]))
    output_dir = _resolve_path(config_path, str(training["output_dir"]))
    examples = load_manifest(
        manifest_path, set(str(item) for item in training["allowed_licenses"])
    )
    if not examples:
        raise ValueError("training dataset is empty")

    tokenizer = OMRTokenizer()
    sequences = [tokenizer.encode(example) for example in examples]

    model_config = MelodyTransformerConfig(
        vocab_size=tokenizer.vocab_size,
        d_model=int(model_values["d_model"]),
        nhead=int(model_values["nhead"]),
        num_layers=int(model_values["num_layers"]),
        dim_feedforward=int(model_values["dim_feedforward"]),
        dropout=float(model_values["dropout"]),
        max_sequence_length=int(model_values["max_sequence_length"]),
        pad_id=tokenizer.pad_id,
    )
    if max(len(sequence) - 1 for sequence in sequences) > model_config.max_sequence_length:
        raise ValueError("encoded training sequence exceeds model maximum")

    model = MelodyTransformer(model_config).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate)
    criterion = nn.CrossEntropyLoss(ignore_index=-100)
    losses: List[float] = []
    start_time = time.perf_counter()
    model.train()
    seen_indices = set()
    for step in range(steps):
        batch_indices = [
            (step * batch_size + offset) % len(sequences)
            for offset in range(batch_size)
        ]
        seen_indices.update(batch_indices)
        inputs, targets = _collate(
            [sequences[index] for index in batch_indices], tokenizer.pad_id, device
        )
        optimizer.zero_grad(set_to_none=True)
        logits = model(inputs)
        loss = criterion(logits.reshape(-1, tokenizer.vocab_size), targets.reshape(-1))
        loss_value = float(loss.detach().cpu())
        if not math.isfinite(loss_value):
            raise RuntimeError("training loss is not finite")
        losses.append(loss_value)
        loss.backward()
        optimizer.step()

    output_dir.mkdir(parents=True, exist_ok=True)
    checkpoint_path = output_dir / "melody-smoke.pt"
    torch.save(
        {
            "format": "omr-melody-v2",
            "model_config": asdict(model_config),
            "model_state": model.state_dict(),
            "optimizer_state": optimizer.state_dict(),
            "vocabulary": tokenizer.tokens,
            "sample_count": len(examples),
            "seen_sample_count": len(seen_indices),
            "seed": seed,
            "steps": steps,
            "losses": losses,
        },
        checkpoint_path,
    )
    runtime_seconds = time.perf_counter() - start_time
    return TrainingResult(
        initial_loss=losses[0],
        final_loss=losses[-1],
        losses=losses,
        sample_count=len(examples),
        seen_sample_count=len(seen_indices),
        device=device.type,
        checkpoint_path=checkpoint_path,
        seed=seed,
        steps=steps,
        runtime_seconds=runtime_seconds,
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("config", type=Path)
    args = parser.parse_args()
    result = train(args.config)
    print("TRAINING_RESULT_JSON=" + json.dumps(result.json_dict(), sort_keys=True))


if __name__ == "__main__":
    main()
