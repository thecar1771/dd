"""Reproducible training and checkpoint verification entry points."""
