"""Reload a saved melody checkpoint and run a minimal inference pass."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict

import torch

from omr.models.melody_transformer import (
    MelodyTransformer,
    MelodyTransformerConfig,
)


def verify_checkpoint(checkpoint_path: Path, device: str = "cpu") -> Dict[str, Any]:
    target = torch.device(device)
    if target.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was required for verification but is unavailable")
    checkpoint = torch.load(checkpoint_path, map_location=target, weights_only=True)
    vocabulary = checkpoint["vocabulary"]
    config = MelodyTransformerConfig(**checkpoint["model_config"])
    if config.vocab_size != len(vocabulary):
        raise ValueError("checkpoint vocabulary and model size disagree")

    model = MelodyTransformer(config).to(target)
    model.load_state_dict(checkpoint["model_state"])
    model.eval()
    bos_id = vocabulary.index("BOS")
    with torch.no_grad():
        logits = model(torch.tensor([[bos_id]], dtype=torch.long, device=target))
    finite = bool(torch.isfinite(logits).all().item())
    if not finite:
        raise RuntimeError("checkpoint inference produced non-finite logits")
    return {
        "device": target.type,
        "finite_logits": finite,
        "vocab_size": len(vocabulary),
        "output_shape": list(logits.shape),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("checkpoint", type=Path)
    parser.add_argument("--device", default="cpu", choices=("cpu", "cuda"))
    args = parser.parse_args()
    result = verify_checkpoint(args.checkpoint, args.device)
    print("CHECKPOINT_VERIFY_JSON=" + json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
