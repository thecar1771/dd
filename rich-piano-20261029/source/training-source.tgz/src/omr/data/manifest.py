"""Load licensed JSONL records into canonical training examples."""

from __future__ import annotations

import json
import hashlib
import re
from datetime import date
from pathlib import Path
from typing import List, Set

from pydantic import Field, field_validator

from omr.schema import SongExample, StrictModel


SHA256_PATTERN = re.compile(r"^[0-9a-f]{64}$")


class DatasetProvenance(StrictModel):
    source_url: str = Field(min_length=1)
    content_license: str = Field(min_length=1)
    code_license: str = Field(min_length=1)
    source_artifact: str = Field(min_length=1)
    retrieved_at: date
    sha256: str
    derivation: str = Field(min_length=1)

    @field_validator("source_url")
    @classmethod
    def source_url_must_be_absolute(cls, value: str) -> str:
        if not value.startswith(("https://", "http://")):
            raise ValueError("source_url must be an absolute HTTP(S) URL")
        return value

    @field_validator("sha256")
    @classmethod
    def sha256_must_be_lowercase_hex(cls, value: str) -> str:
        if not SHA256_PATTERN.fullmatch(value):
            raise ValueError("sha256 must be 64 lowercase hexadecimal characters")
        return value


class ManifestRecord(StrictModel):
    provenance: DatasetProvenance
    example: SongExample


def load_manifest(path: Path, allowed_licenses: Set[str]) -> List[SongExample]:
    """Load examples only when each record has approved provenance."""

    examples: List[SongExample] = []
    with path.open("r", encoding="utf-8") as manifest_file:
        for line_number, raw_line in enumerate(manifest_file, start=1):
            if not raw_line.strip():
                continue
            try:
                payload = json.loads(raw_line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"invalid JSON on manifest line {line_number}") from exc

            record = ManifestRecord.model_validate(payload)
            if record.provenance.content_license not in allowed_licenses:
                raise ValueError(
                    f"license {record.provenance.content_license!r} is not allowed"
                )
            relative_artifact = Path(record.provenance.source_artifact)
            if relative_artifact.is_absolute() or ".." in relative_artifact.parts:
                raise ValueError("source_artifact must stay inside manifest directory")
            artifact_path = (path.parent / relative_artifact).resolve()
            manifest_root = path.parent.resolve()
            try:
                artifact_path.relative_to(manifest_root)
            except ValueError as exc:
                raise ValueError(
                    "source_artifact must stay inside manifest directory"
                ) from exc
            if not artifact_path.is_file():
                raise ValueError(f"source artifact does not exist: {relative_artifact}")
            digest = hashlib.sha256(artifact_path.read_bytes()).hexdigest()
            if digest != record.provenance.sha256:
                raise ValueError(
                    f"source artifact checksum mismatch on manifest line {line_number}"
                )
            examples.append(record.example)

    if not examples:
        raise ValueError("manifest is empty")
    return examples
