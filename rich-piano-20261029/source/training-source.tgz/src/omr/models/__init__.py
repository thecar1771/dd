"""Trainable models for the OMR pipeline."""

from .melody_transformer import MelodyTransformer, MelodyTransformerConfig

__all__ = ["MelodyTransformer", "MelodyTransformerConfig"]
