"""Compact causal Transformer baseline for symbolic melody tokens."""

from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import Tensor, nn


@dataclass(frozen=True)
class MelodyTransformerConfig:
    vocab_size: int
    d_model: int = 128
    nhead: int = 4
    num_layers: int = 4
    dim_feedforward: int = 512
    dropout: float = 0.1
    max_sequence_length: int = 1024
    pad_id: int = 0

    def __post_init__(self) -> None:
        if self.vocab_size <= 0:
            raise ValueError("vocab_size must be positive")
        if self.d_model <= 0 or self.d_model % self.nhead != 0:
            raise ValueError("d_model must be positive and divisible by nhead")
        if self.num_layers <= 0 or self.max_sequence_length <= 0:
            raise ValueError("layer count and maximum sequence length must be positive")


class MelodyTransformer(nn.Module):
    """Decoder-only behavior built from a causally masked Transformer encoder."""

    def __init__(self, config: MelodyTransformerConfig) -> None:
        super().__init__()
        self.config = config
        self.token_embedding = nn.Embedding(
            config.vocab_size, config.d_model, padding_idx=config.pad_id
        )
        self.position_embedding = nn.Embedding(
            config.max_sequence_length, config.d_model
        )
        layer = nn.TransformerEncoderLayer(
            d_model=config.d_model,
            nhead=config.nhead,
            dim_feedforward=config.dim_feedforward,
            dropout=config.dropout,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.transformer = nn.TransformerEncoder(
            layer, num_layers=config.num_layers, enable_nested_tensor=False
        )
        self.final_norm = nn.LayerNorm(config.d_model)
        self.lm_head = nn.Linear(config.d_model, config.vocab_size, bias=False)

    def forward(self, input_ids: Tensor) -> Tensor:
        if input_ids.ndim != 2:
            raise ValueError("input_ids must have shape [batch, sequence]")
        batch_size, sequence_length = input_ids.shape
        if sequence_length > self.config.max_sequence_length:
            raise ValueError("input sequence exceeds configured maximum")
        if sequence_length == 0 or batch_size == 0:
            raise ValueError("input batch and sequence must be non-empty")

        positions = torch.arange(sequence_length, device=input_ids.device).unsqueeze(0)
        positions = positions.expand(batch_size, sequence_length)
        hidden = self.token_embedding(input_ids) + self.position_embedding(positions)
        causal_mask = torch.triu(
            torch.ones(
                sequence_length,
                sequence_length,
                dtype=torch.bool,
                device=input_ids.device,
            ),
            diagonal=1,
        )
        padding_mask = input_ids.eq(self.config.pad_id)
        hidden = self.transformer(
            hidden,
            mask=causal_mask,
            src_key_padding_mask=padding_mask,
        )
        return self.lm_head(self.final_norm(hidden))
