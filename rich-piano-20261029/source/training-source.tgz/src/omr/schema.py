"""Canonical data contracts shared by the OMR training pipeline."""

from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, ConfigDict, Field, model_validator


class StrictModel(BaseModel):
    """Base contract that rejects accidental, unversioned fields."""

    model_config = ConfigDict(extra="forbid")


class LyricSyllable(StrictModel):
    surface: str = Field(min_length=1)
    pronunciation: str = Field(min_length=1)
    phonemes: List[str] = Field(default_factory=list)
    stress: List[int] = Field(default_factory=list)
    keyword_weight: float = Field(default=0.0, ge=0.0, le=1.0)
    phrase_boundary: bool = False


class EmotionPlan(StrictModel):
    primary: str = Field(min_length=1)
    secondary: List[str] = Field(default_factory=list)
    valence: float = Field(ge=-1.0, le=1.0)
    arousal: float = Field(ge=-1.0, le=1.0)
    dominance: float = Field(ge=-1.0, le=1.0)
    arc: List[str] = Field(default_factory=list)


class NoteEvent(StrictModel):
    pitch: Optional[int] = Field(default=None, ge=0, le=127)
    start: float = Field(ge=0.0)
    duration: float = Field(gt=0.0)
    syllable_index: Optional[int] = Field(default=None, ge=0)
    velocity: int = Field(default=80, ge=1, le=127)


class SongExample(StrictModel):
    example_id: str = Field(min_length=1)
    language: str = Field(min_length=2)
    lyrics: List[LyricSyllable]
    emotion: EmotionPlan
    notes: List[NoteEvent]
    tempo_bpm: int = Field(gt=0)
    meter_numerator: int = Field(gt=0)
    meter_denominator: int = Field(gt=0)
    mode: str = Field(min_length=1)
    chords: List[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def note_alignments_must_reference_lyrics(self) -> "SongExample":
        lyric_count = len(self.lyrics)
        for note in self.notes:
            if note.syllable_index is not None and note.syllable_index >= lyric_count:
                raise ValueError("note syllable_index must reference an existing lyric")
        return self
