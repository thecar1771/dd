"""Description-to-interpretation-to-score PoC pipeline."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any, List, Optional

import torch
from pydantic import BaseModel, ConfigDict, Field

from omr.keypoints.data import CONCEPTS, EMOTIONS, SURFACES
from omr.keypoints.training import LoadedKeypointCheckpoint, load_keypoint_checkpoint
from omr.schema import EmotionPlan, LyricSyllable, NoteEvent, SongExample


class KeypointScore(BaseModel):
    model_config = ConfigDict(extra="forbid")
    concept: str
    confidence: float = Field(ge=0.0, le=1.0)


class SceneInterpretation(BaseModel):
    model_config = ConfigDict(extra="forbid")
    description: str
    keypoints: List[KeypointScore]
    primary_emotion: str
    user_hint: Optional[str] = None


MUSIC_PROFILES = {
    "warm_serenity": {"tempo": 84, "mode": "major", "base": 60, "velocity": 76, "scale": (0, 2, 4, 7), "vad": (0.75, -0.15, 0.25)},
    "majesty": {"tempo": 72, "mode": "dorian", "base": 48, "velocity": 96, "scale": (0, 2, 3, 7), "vad": (0.3, 0.55, 0.85)},
    "cold_solitude": {"tempo": 60, "mode": "minor", "base": 64, "velocity": 64, "scale": (0, 3, 5, 7), "vad": (-0.45, -0.55, -0.2)},
    "wonder": {"tempo": 90, "mode": "lydian", "base": 60, "velocity": 80, "scale": (0, 2, 6, 7), "vad": (0.5, 0.3, 0.15)},
    "energy": {"tempo": 120, "mode": "mixolydian", "base": 55, "velocity": 92, "scale": (0, 2, 4, 5), "vad": (0.45, 0.8, 0.45)},
}


def _fit_description_to_context(description: str, max_length: int) -> str:
    """Trim UTF-8 text at a code-point boundary to leave room for BOS."""
    normalized = description.strip()
    if not normalized:
        raise ValueError("description must not be empty")
    max_bytes = max_length - 1
    encoded = normalized.encode("utf-8")
    if len(encoded) <= max_bytes:
        return normalized
    candidate = encoded[:max_bytes]
    while candidate:
        try:
            fitted = candidate.decode("utf-8").rstrip()
            if fitted:
                return fitted
            break
        except UnicodeDecodeError as exc:
            candidate = candidate[:exc.start]
    raise ValueError("description cannot fit the configured model context")


def interpret_description(
    description: str,
    loaded: LoadedKeypointCheckpoint,
    user_hint: Optional[str] = None,
    top_k: int = 3,
) -> SceneInterpretation:
    fitted_description = _fit_description_to_context(
        description, loaded.tokenizer.max_length
    )
    if top_k <= 0 or top_k > len(CONCEPTS):
        raise ValueError("top_k is outside the concept ontology")
    device = next(loaded.model.parameters()).device
    batch = loaded.tokenizer.batch_encode([fitted_description], device)
    with torch.inference_mode():
        output = loaded.model(batch.input_ids, batch.attention_mask)
        concept_scores = torch.sigmoid(output.keyword_logits[0])
        emotion_index = int(output.emotion_logits[0].argmax().item())
        values, indices = concept_scores.topk(top_k)
    keypoints = [
        KeypointScore(concept=CONCEPTS[int(index)], confidence=float(value))
        for value, index in zip(values.cpu(), indices.cpu())
    ]
    return SceneInterpretation(
        description=fitted_description,
        keypoints=keypoints,
        primary_emotion=EMOTIONS[emotion_index],
        user_hint=user_hint.strip() if user_hint and user_hint.strip() else None,
    )


def compose_song(interpretation: SceneInterpretation, language: str) -> SongExample:
    profile = MUSIC_PROFILES[interpretation.primary_emotion]
    surfaces = SURFACES.get(language, SURFACES["en"])
    lyric_surfaces = [surfaces[item.concept] for item in interpretation.keypoints]
    lyrics = [
        LyricSyllable(
            surface=surface, pronunciation=surface,
            keyword_weight=max(0.0, min(1.0, interpretation.keypoints[index].confidence)),
            phrase_boundary=index == len(lyric_surfaces) - 1,
        )
        for index, surface in enumerate(lyric_surfaces)
    ]
    scale = profile["scale"]
    notes = [
        NoteEvent(
            pitch=int(profile["base"] + scale[index % len(scale)]),
            start=float(index), duration=1.0, syllable_index=index,
            velocity=int(profile["velocity"]),
        )
        for index in range(len(lyrics))
    ]
    valence, arousal, dominance = profile["vad"]
    identity = hashlib.sha256(interpretation.description.encode("utf-8")).hexdigest()[:12]
    return SongExample(
        example_id=f"scene-{identity}", language=language, lyrics=lyrics,
        emotion=EmotionPlan(
            primary=interpretation.primary_emotion, secondary=[],
            valence=valence, arousal=arousal, dominance=dominance,
            arc=[interpretation.primary_emotion],
        ),
        notes=notes, tempo_bpm=int(profile["tempo"]),
        meter_numerator=4, meter_denominator=4, mode=str(profile["mode"]),
        chords=["I", "IV", "V", "I"],
    )


def resolve_description(
    description: Optional[str] = None,
    image_path: Optional[Path] = None,
    captioner: Optional[Any] = None,
) -> str:
    """Resolve exactly one text or image input into a grounded description."""
    if bool(description and description.strip()) == bool(image_path):
        raise ValueError("provide exactly one of description or image_path")
    if description:
        return description.strip()
    if captioner is None:
        from omr.vision.smolvlm import SmolVLMCaptioner

        captioner = SmolVLMCaptioner()
    return captioner.caption(image_path)


def main() -> None:
    from omr.score.musicxml import song_to_musicxml

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("checkpoint", type=Path)
    inputs = parser.add_mutually_exclusive_group(required=True)
    inputs.add_argument("--description")
    inputs.add_argument("--image", type=Path)
    parser.add_argument("--language", default="ko", choices=sorted(SURFACES))
    parser.add_argument("--user-hint")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    loaded = load_keypoint_checkpoint(args.checkpoint, device)
    description = resolve_description(args.description, args.image)
    interpretation = interpret_description(description, loaded, args.user_hint)
    song = compose_song(interpretation, args.language)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(song_to_musicxml(song, title="OMR Scene Song"), encoding="utf-8")
    args.output.with_suffix(".interpretation.json").write_text(
        json.dumps(interpretation.model_dump(mode="json"), ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(interpretation.model_dump(mode="json"), ensure_ascii=False))


if __name__ == "__main__":
    main()
