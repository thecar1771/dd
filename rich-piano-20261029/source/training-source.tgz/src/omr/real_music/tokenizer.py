"""Explicit real source/style/instrument prefixes and quantized note events."""
from __future__ import annotations

FORMAT='omr-real-partbar-v2'


class RealTokenizer:
    prefix_length=8

    def __init__(self, *, styles, sources):
        self.styles=sorted(set(styles)); self.sources=sorted(set(sources))
        self.tokens=['PAD','BOS','EOS']
        for prefix,values in [('SRC',self.sources),('STYLE',self.styles),('BPM',range(20,301)),
                              ('METER',[f'{n}/{d}' for n in range(1,33) for d in (1,2,4,8,16,32)]),
                              ('INST',list(range(128))+['drums']),('CONT',range(2)),
                              ('LEN',range(1,385)),
                              ('POS',range(384)),('DUR',range(1,385)),('P',range(128)),('V',range(1,128))]:
            self.tokens.extend(f'{prefix}_{v}' for v in values)
        self.ids={t:i for i,t in enumerate(self.tokens)}

    def prefix(self,row):
        values=['BOS',f"SRC_{row['source']}",f"STYLE_{row['style']}",f"BPM_{row['bpm']}",
                f"METER_{row['meter'][0]}/{row['meter'][1]}",
                'INST_drums' if row['drum'] else f"INST_{row['program']}",f"CONT_{int(row.get('continuation',False))}"]
        nominal=row['meter'][0]*48//row['meter'][1]
        length=row.get('bar_ticks',nominal)
        if not 1<=length<=nominal: raise ValueError('invalid actual bar length')
        values.append(f'LEN_{length}')
        try: return [self.ids[t] for t in values]
        except KeyError as exc: raise ValueError('unknown source/style/control: '+str(exc)) from exc

    def encode(self,row):
        ids=self.prefix(row)
        length=row.get('bar_ticks',row['meter'][0]*48//row['meter'][1])
        for onset,duration,pitch,velocity in row['notes']:
            if not (0<=onset<length and 0<duration<=length-onset and 0<=pitch<128 and 1<=velocity<128):
                raise ValueError('invalid note bounds')
            ids.extend(self.ids[f'{p}_{v}'] for p,v in zip(('POS','DUR','P','V'),(onset,duration,pitch,velocity)))
        ids.append(self.ids['EOS'])
        return ids,[False]*self.prefix_length+[True]*(len(ids)-self.prefix_length)

    def decode(self,ids):
        tokens=[self.tokens[i] for i in ids]
        if len(tokens)<9 or tokens[0]!='BOS' or not tokens[7].startswith('LEN_') or tokens[-1]!='EOS' or (len(tokens)-9)%4:
            raise ValueError('invalid real-music sequence')
        row={'source':tokens[1][4:],'style':tokens[2][6:],'bpm':int(tokens[3][4:]),
             'meter':list(map(int,tokens[4][6:].split('/'))),'drum':tokens[5]=='INST_drums',
             'program':0 if tokens[5]=='INST_drums' else int(tokens[5][5:]),
             'continuation':tokens[6]=='CONT_1','bar_ticks':int(tokens[7][4:]),'notes':[]}
        for index in range(8,len(tokens)-1,4):
            block=tokens[index:index+4]
            if any(not t.startswith(p+'_') for p,t in zip(('POS','DUR','P','V'),block)):
                raise ValueError('invalid event syntax')
            row['notes'].append([int(t.split('_')[1]) for t in block])
        if self.encode(row)[0]!=ids: raise ValueError('noncanonical sequence')
        return row

    def to_dict(self):
        return {'format':FORMAT,'styles':self.styles,'sources':self.sources,'tokens':self.tokens}
