"""Explicit readable notation derived from preserved model performances."""
from dataclasses import replace
from fractions import Fraction
from collections import defaultdict
from .data import canonical_notes,digest
from omr.genres.contracts import Composition,ScoreEvent


def readable_composition(source,drum_grid=3):
    if drum_grid not in (3,4,6): raise ValueError('notation grid must be 3,4,6 twelfth-quarter ticks')
    plan=source.plan; events=[]; drum_bars=defaultdict(list); changed=merged=0
    for event in source.events:
        if event.part!='drums' or event.pitch is None:
            events.append(event); continue
        exact=event.onset*12
        if exact.denominator!=1: raise ValueError('source event is off the learned grid')
        onset=min(48-drum_grid,int((exact+Fraction(drum_grid,2))//drum_grid)*drum_grid)
        duration=Fraction(drum_grid,12)
        changed+=event.onset!=Fraction(onset,12) or event.duration!=duration
        drum_bars[event.bar].append([onset,drum_grid,event.pitch,event.velocity])
    for bar,notes in sorted(drum_bars.items()):
        cleaned,changes=canonical_notes(notes); merged+=changes['simultaneous_unisons_collapsed']
        events.extend(ScoreEvent(bar,Fraction(o,12),Fraction(d,12),'drums',pitch,velocity,unpitched=True) for o,d,pitch,velocity in cleaned)
    marker=plan.instruments.get('piano_rh','acoustic_piano')
    keyboard=marker in ('acoustic_piano','electric_piano','piano') or (marker.startswith('gm_program_') and marker[11:].isdigit() and int(marker[11:])<8)
    split=plan.parts==('piano_rh',) and keyboard
    if split:
        instrument=plan.instruments.get('piano_rh','acoustic_piano')
        events=[replace(e,part='piano_lh' if e.pitch is not None and e.pitch<60 else 'piano_rh') for e in events]
        active=tuple(part for part in ('piano_rh','piano_lh') if any(e.part==part for e in events))
        plan=replace(plan,parts=active,instruments={part:instrument for part in active})
        split=len(active)==2
    metadata=dict(source.metadata)
    metadata['notation']={'kind':'explicit readable rendering of model performance','source_composition_sha256':digest(source.to_dict()),
                          'original_performance_preserved':True,'drum_grid_ticks':drum_grid,'ticks_per_quarter':12,
                          'drum_duration_policy':'one notation-grid unit, clipped to bar; velocities retained',
                          'drum_events_quantized':changed,'drum_hits_merged':merged,'keyboard_hands_split':split,
                          'keyboard_split_midi':60 if split else None,'original_notes':len(source.events),'readable_notes':len(events),
                          'pitched_note_timing_policy':'unchanged; keyboard register only reassigned between staves'}
    return Composition(plan,tuple(events),metadata)
