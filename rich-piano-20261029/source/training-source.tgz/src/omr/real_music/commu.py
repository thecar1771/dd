"""ComMU metadata adapters. These are explicit GM representatives, not source patches."""
import ast
import re

GM_REPRESENTATIVES={'acoustic_piano':0,'electric_piano':4,'celesta':8,'glockenspiel':9,'vibraphone':11,
                    'marimba':12,'xylophone':13,'bell':14,'orgel':10,'accordion':21,'nylon_guitar':24,
                    'acoustic_guitar':25,'electric_guitar_clean':27,'electric_guitar_distortion':30,
                    'acoustic_bass':32,'electric_bass':33,'synth_bass':38,'synth_bass_wobble':39,
                    'string_violin':40,'string_viola':41,'string_cello':42,'string_double_bass':43,
                    'harp':46,'timpani':47,'string_ensemble':48,'choir':52,'synth_voice':54,
                    'trombone':57,'tuba':58,'horn':60,'brass_ensemble':61,'oboe':68,'bassoon':70,
                    'clarinet':71,'flute':73,'synth_pluck':84,'synth_pad':89,'synth_bell':98}


def instrument_program(label):
    family=re.sub(r'-\d+$','',label)
    if family not in GM_REPRESENTATIVES: raise ValueError('unmapped ComMU instrument: '+label)
    return GM_REPRESENTATIVES[family]


def chord_grid(meta):
    text=meta['chord_progressions']
    if len(text)>100000: raise ValueError('oversized chord metadata')
    parsed=ast.literal_eval(text); flat=[]
    def visit(value):
        if isinstance(value,str): flat.append(value)
        elif isinstance(value,(list,tuple)):
            for child in value: visit(child)
        else: raise ValueError('invalid chord metadata')
    visit(parsed)
    measures=int(meta['num_measures'])
    slots=len(flat)//measures if measures>0 and len(flat)%measures==0 else None
    return flat,slots


def chord_for_bar(meta,bar):
    flat,slots=chord_grid(meta)
    if not slots or not 0<=bar<int(meta['num_measures']): return 'unknown',[]
    values=flat[bar*slots:(bar+1)*slots]
    return '>'.join(dict.fromkeys(values)) if values else 'unknown',values
