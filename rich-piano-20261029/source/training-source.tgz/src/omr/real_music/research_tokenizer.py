"""Research-only tokenizer: RealTokenizer plus loss-masked role/key/chord prefix controls."""
from __future__ import annotations

from .tokenizer import RealTokenizer

FORMAT='omr-real-partbar-research-v1'
CONTROLS=(('ROLE','track_role'),('KEY','audio_key'),('CHORD','chord'))


class ResearchTokenizer:
    prefix_length=RealTokenizer.prefix_length+len(CONTROLS)

    def __init__(self, *, styles, sources, roles, keys, chords):
        self.base=RealTokenizer(styles=styles,sources=sources)
        self.styles,self.sources=self.base.styles,self.base.sources
        self.roles,self.keys,self.chords=(sorted(set(v)|{'unknown'}) for v in (roles,keys,chords))
        self.tokens=list(self.base.tokens)
        for (prefix,_),values in zip(CONTROLS,(self.roles,self.keys,self.chords)):
            self.tokens.extend(f'{prefix}_{v}' for v in values)
        self.ids={t:i for i,t in enumerate(self.tokens)}
        if len(self.ids)!=len(self.tokens): raise ValueError('ambiguous research control value')
        self.control_ids=[{self.ids[f'{p}_{v}']:v for v in values}
                          for (p,_),values in zip(CONTROLS,(self.roles,self.keys,self.chords))]

    def controls(self,row):
        values=[row.get(field,'unknown') for _,field in CONTROLS]
        if any(not isinstance(v,str) for v in values): raise ValueError('research controls must be strings')
        try: return [self.ids[f'{p}_{v}'] for (p,_),v in zip(CONTROLS,values)]
        except KeyError as exc: raise ValueError('unknown research control: '+str(exc)) from exc

    def prefix(self,row):
        return self.base.prefix(row)+self.controls(row)

    def encode(self,row):
        controls=self.controls(row); ids,_=self.base.encode(row); n=self.base.prefix_length
        ids=ids[:n]+controls+ids[n:]
        return ids,[False]*self.prefix_length+[True]*(len(ids)-self.prefix_length)

    def decode(self,ids):
        ids=list(ids); n=self.base.prefix_length
        if len(ids)<=self.prefix_length: raise ValueError('invalid research sequence')
        controls=ids[n:self.prefix_length]; core=ids[:n]+ids[self.prefix_length:]
        if any(not 0<=i<len(self.base.tokens) for i in core): raise ValueError('research control outside prefix')
        if any(i not in lookup for i,lookup in zip(controls,self.control_ids)): raise ValueError('invalid research control')
        row=self.base.decode(core)
        row.update({field:lookup[i] for (_,field),i,lookup in zip(CONTROLS,controls,self.control_ids)})
        return row

    def to_dict(self):
        return {'format':FORMAT,'styles':self.styles,'sources':self.sources,'roles':self.roles,
                'keys':self.keys,'chords':self.chords,'tokens':self.tokens}
