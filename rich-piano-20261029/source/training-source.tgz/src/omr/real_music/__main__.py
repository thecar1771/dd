"""CLI: train real source notes, or export experimental genre arrangements."""
from __future__ import annotations

import argparse
import hashlib
import json
from dataclasses import replace
from fractions import Fraction
from pathlib import Path


def main():
    p=argparse.ArgumentParser(description=__doc__); sub=p.add_subparsers(dest='command',required=True)
    tr=sub.add_parser('train'); tr.add_argument('--manifest',type=Path,required=True); tr.add_argument('--output',type=Path,required=True)
    tr.add_argument('--epochs',type=int,default=3); tr.add_argument('--batch-size',type=int,default=32)
    tr.add_argument('--width',type=int,default=256); tr.add_argument('--layers',type=int,default=4)
    tr.add_argument('--device',default='cuda'); tr.add_argument('--seed',type=int,default=20261028)
    tr.add_argument('--usage-profile',choices=('commercial-compatible','research-noncommercial'),default='commercial-compatible')
    gen=sub.add_parser('generate'); gen.add_argument('--checkpoint',type=Path,required=True); gen.add_argument('--output',type=Path,required=True)
    gen.add_argument('--source',required=True); gen.add_argument('--style',required=True); gen.add_argument('--drums',action='store_true')
    gen.add_argument('--program',type=int,default=0); gen.add_argument('--bars',type=int,default=8); gen.add_argument('--bpm',type=int,default=100)
    gen.add_argument('--seed',type=int,default=1); gen.add_argument('--device',default='cpu')
    gen.add_argument('--allow-research-model',action='store_true'); gen.add_argument('--track-role',default='unknown')
    gen.add_argument('--audio-key',default='unknown'); gen.add_argument('--chord',default='unknown')
    mix=sub.add_parser('apply-rhythm'); mix.add_argument('--checkpoint',type=Path,required=True); mix.add_argument('--composition',type=Path,required=True)
    mix.add_argument('--style',required=True); mix.add_argument('--output',type=Path,required=True); mix.add_argument('--seed',type=int,default=1)
    mix.add_argument('--device',default='cpu')
    mix.add_argument('--allow-research-model',action='store_true')
    args=p.parse_args()
    if args.command=='train':
        from .train import train
        report=train(args.manifest,args.output,epochs=args.epochs,batch_size=args.batch_size,width=args.width,layers=args.layers,device=args.device,seed=args.seed,usage_profile=args.usage_profile)
        print(json.dumps({k:report[k] for k in ('usage_profile','parameters','steps','coverage','test','checkpoint_sha256')},ensure_ascii=False)); return
    import torch
    from .train import load_checkpoint,source_hashes
    from .generate import sample_part_bar
    from omr.genres.contracts import Composition,ScoreEvent,Chord
    from omr.genres.plans import build_plan
    from omr.genres.export import musicxml,write_midi
    if args.device=='cpu': torch.set_num_threads(1)
    model,tok,identity=load_checkpoint(args.checkpoint,args.device,allow_research=args.allow_research_model)
    if args.command=='apply-rhythm':
        original=Composition.from_dict(json.loads(args.composition.read_text(encoding='utf-8')))
        plan=original.plan; source='gmd'; drum=True; program=0
        if 'drums' not in plan.parts: raise ValueError('composition has no drum part')
        events=[e for e in original.events if e.part!='drums']; metadata=dict(original.metadata)
    else:
        if not 4<=args.bars<=128: raise ValueError('bars must be 4..128')
        plan=build_plan('Actual-source style experiment',genre='pop',bars=args.bars,seed=args.seed)
        drum=args.drums; source=args.source; program=args.program
        role='drums' if drum else 'piano_rh'
        plan=replace(plan,bpm=args.bpm,parts=(role,),instruments={role:'drumkit' if drum else f'gm_program_{program}'})
        if args.audio_key in ('cmajor','aminor'):
            tonic,quality=(0,'major') if args.audio_key=='cmajor' else (9,'minor')
            plan=replace(plan,chords=(Chord(tonic,quality),)*plan.bars)
        events=[]; metadata={}
    reports=[]
    control_key=json.dumps([source,args.style,drum,program],separators=(',',':'))
    if control_key not in identity['trained_control_counts']:
        raise ValueError('requested source/style/instrument has no training examples; inspect result.json trained_control_counts')
    for bar in range(plan.bars):
        control={'source':source,'style':args.style,'meter':[4,4],'bpm':plan.bpm,'drum':drum,'program':program}
        if args.command=='generate': control.update(track_role=args.track_role,audio_key=args.audio_key,chord=args.chord)
        row,report=sample_part_bar(model,tok,control,seed=args.seed+bar*104729,max_events=48 if drum else 40)
        role='drums' if drum else 'piano_rh'
        events.extend(ScoreEvent(bar=bar,onset=Fraction(n[0],12),duration=Fraction(n[1],12),part=role,pitch=n[2],velocity=n[3],unpitched=drum) for n in row['notes'])
        reports.append(report)
    metadata.update({'real_source_training':True,'actual_source':source,'actual_source_style':args.style,
                     'usage_profile':identity['usage_profile'],'research_only':identity['research_only'],
                     'research_context':{k:getattr(args,k,'unknown') for k in ('track_role','audio_key','chord')},
                     'checkpoint_sha256':hashlib.sha256(args.checkpoint.read_bytes()).hexdigest(),
                     'training_manifest_sha256':identity['manifest_sha256'],'generation':reports,'production_ready':False,
                     'generation_source_hashes':source_hashes(),
                     'real_genre_training':{'drums':drum,'pitched':not drum,'kpop_melody':False},
                     'note_source':'real-source conditional Transformer; finite grammar',
                     'limitations':'No learned scene or lyric semantics; product genre bridge is explicit. Part-bar model.'})
    if args.command=='apply-rhythm':
        metadata['unchanged_parts_source']=original.metadata.get('note_source','input composition')
        metadata['note_source']='real-source GMD rhythm applied to input arrangement'
        metadata['product_to_source_style_bridge']={'product_genre':plan.genre,'source_style':args.style}
    composition=Composition(plan,tuple(events),metadata)
    args.output.mkdir(parents=True,exist_ok=True)
    (args.output/'composition.json').write_text(json.dumps(composition.to_dict(),ensure_ascii=False,indent=2),encoding='utf-8')
    (args.output/'score.musicxml').write_text(musicxml(composition,title=args.style),encoding='utf-8')
    write_midi(composition,args.output/'score.mid')
    (args.output/'provenance.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'output':str(args.output),'notes':len(events),'style':args.style,'source':source}))


if __name__=='__main__': main()
