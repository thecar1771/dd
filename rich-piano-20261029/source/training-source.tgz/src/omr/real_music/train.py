"""Full-coverage fresh-weight training on manifested actual music."""
from __future__ import annotations

import hashlib
import json
import random
import platform
import time
from collections import Counter, defaultdict
from dataclasses import asdict
from pathlib import Path

import torch
from torch import nn

from omr.models.melody_transformer import MelodyTransformer, MelodyTransformerConfig
from .tokenizer import RealTokenizer, FORMAT

CHECKPOINT_FORMAT='omr-real-music-v2'
COMMERCIAL_SOURCES={'gmd','mutopia','openscore-lieder'}
RESEARCH_SOURCES={'commu'}


def collate(sequences,device):
    """Build masks on CPU and transfer twice, rather than copying every target to CUDA."""
    size=max(len(ids) for ids,_ in sequences)
    batch=torch.zeros((len(sequences),size),dtype=torch.long)
    targets=torch.full((len(sequences),size-1),-100,dtype=torch.long)
    for row,(ids,mask) in enumerate(sequences):
        tokens=torch.tensor(ids,dtype=torch.long)
        batch[row,:len(ids)]=tokens
        labels=tokens[1:].clone()
        labels[~torch.tensor(mask[1:],dtype=torch.bool)]=-100
        targets[row,:len(ids)-1]=labels
    return batch[:,:-1].to(device),targets.to(device)


def source_hashes():
    root=Path(__file__).parents[1]
    files=list(Path(__file__).parent.glob('*.py'))+[root/'models'/'melody_transformer.py']
    return {str(p.relative_to(root)).replace('\\','/'):hashlib.sha256(p.read_text(encoding='utf-8').replace('\r\n','\n').encode()).hexdigest() for p in sorted(files)}


def compatibility_hashes(tokenizer_format=FORMAT):
    names={'real_music/tokenizer.py','models/melody_transformer.py'}
    if tokenizer_format=='omr-real-partbar-research-v1': names.add('real_music/research_tokenizer.py')
    return {k:v for k,v in source_hashes().items() if k in names}


@torch.inference_mode()
def evaluate(model,sequences,device,batch_size=32):
    model.eval(); total=count=correct=0
    for start in range(0,len(sequences),batch_size):
        x,y=collate(sequences[start:start+batch_size],device)
        logits=model(x)
        loss=nn.functional.cross_entropy(logits.flatten(0,1),y.flatten(),ignore_index=-100,reduction='sum')
        total+=float(loss); count+=int((y!=-100).sum())
        correct+=int(((logits.argmax(-1)==y)&(y!=-100)).sum())
    if count==0: raise ValueError('empty evaluation split')
    return {'loss':total/count,'next_token_accuracy':correct/count,'target_count':count,'sequences':len(sequences)}


def train(manifest,output,*,epochs=3,batch_size=32,width=256,layers=4,device='cuda',seed=20261028,usage_profile='commercial-compatible'):
    manifest=Path(manifest); output=Path(output)
    if epochs<1 or batch_size<1: raise ValueError('positive epochs and batch size required')
    if output.exists() and any(output.iterdir()): raise FileExistsError('preserve existing run: '+str(output))
    output.mkdir(parents=True,exist_ok=True)
    torch.manual_seed(seed); random.seed(seed)
    if device.startswith('cuda') and not torch.cuda.is_available(): raise RuntimeError('requested CUDA unavailable')
    torch.set_num_threads(8 if device.startswith('cuda') else 1)
    if device.startswith('cuda'):
        torch.backends.cuda.matmul.allow_tf32=True
        torch.backends.cudnn.allow_tf32=True
    rows=[json.loads(line) for line in manifest.read_text(encoding='utf-8').splitlines() if line.strip()]
    sources={r['source'] for r in rows}
    if sources-(COMMERCIAL_SOURCES|RESEARCH_SOURCES): raise ValueError('unreviewed data source')
    if usage_profile not in ('commercial-compatible','research-noncommercial'): raise ValueError('unknown usage profile')
    restricted=bool(sources&RESEARCH_SOURCES) or any(r.get('usage_profile')=='research-noncommercial' or 'NC-' in r.get('license','') for r in rows)
    if restricted and usage_profile!='research-noncommercial': raise ValueError('research-only source cannot enter commercial-compatible weights')
    if usage_profile=='research-noncommercial':
        from .research_tokenizer import ResearchTokenizer
        tok=ResearchTokenizer(styles=[r['style'] for r in rows],sources=sources,
                              roles=[r.get('track_role','unknown') for r in rows],keys=[r.get('audio_key','unknown') for r in rows],
                              chords=[r.get('chord','unknown') for r in rows])
    else:
        tok=RealTokenizer(styles=[r['style'] for r in rows],sources=sources)
    sequences=[tok.encode(r) for r in rows]
    if any(len(ids)>512 for ids,_ in sequences): raise ValueError('sequence exceeds context')
    groups=defaultdict(set)
    for row in rows: groups[row.get('group',row['file_id'])].add(row['split'])
    if any(len(s)>1 for s in groups.values()): raise ValueError('work group split leakage')
    splits={s:[i for i,r in enumerate(rows) if r['split']==s] for s in ('train','validation','test')}
    if any(not v for v in splits.values()): raise ValueError('three nonempty splits required')
    config=MelodyTransformerConfig(vocab_size=len(tok.tokens),d_model=width,nhead=4,num_layers=layers,
                                  dim_feedforward=width*3,dropout=.1,max_sequence_length=512)
    model=MelodyTransformer(config).to(device)
    optimizer=torch.optim.AdamW(model.parameters(),lr=3e-4,weight_decay=.01)
    manifest_sha=hashlib.sha256(manifest.read_bytes()).hexdigest()
    validation=[sequences[i] for i in splits['validation']]
    # Full held-out evaluations are deterministic and never optimize model weights.
    initial=evaluate(model,validation,device,batch_size)
    visited=set(); files=set(); history=[]; started=time.time(); steps=0
    for epoch in range(epochs):
        order=list(splits['train']); random.Random(seed+epoch).shuffle(order)
        batches=[]
        # Random macro-buckets reduce padding without dropping a single sequence.
        for offset in range(0,len(order),batch_size*32):
            bucket=sorted(order[offset:offset+batch_size*32],key=lambda i:len(sequences[i][0]))
            batches.extend(bucket[i:i+batch_size] for i in range(0,len(bucket),batch_size))
        random.Random(seed+epoch+7).shuffle(batches)
        model.train(); total=count=0
        for batch in batches:
            x,y=collate([sequences[i] for i in batch],device)
            optimizer.zero_grad(set_to_none=True)
            if device.startswith('cuda'):
                with torch.autocast('cuda',dtype=torch.bfloat16):
                    logits=model(x); loss=nn.functional.cross_entropy(logits.flatten(0,1),y.flatten(),ignore_index=-100)
            else:
                logits=model(x); loss=nn.functional.cross_entropy(logits.flatten(0,1),y.flatten(),ignore_index=-100)
            if not torch.isfinite(loss): raise RuntimeError('nonfinite training loss')
            loss.backward(); nn.utils.clip_grad_norm_(model.parameters(),1.0); optimizer.step()
            n=int((y!=-100).sum()); total+=float(loss.detach())*n; count+=n; steps+=1
            visited.update(batch); files.update(rows[i]['file_id'] for i in batch)
            if steps%100==0: print(json.dumps({'step':steps,'epoch':epoch+1,'loss':total/count,'elapsed':time.time()-started}),flush=True)
        metrics=evaluate(model,validation,device,batch_size)
        history.append({'epoch':epoch+1,'train_loss':total/count,'validation':metrics,'steps':steps})
        print(json.dumps(history[-1]),flush=True)
    test=[sequences[i] for i in splits['test']]
    final=evaluate(model,test,device,batch_size)
    by_source={}
    for source in tok.sources:
        seq=[sequences[i] for i in splits['test'] if rows[i]['source']==source]
        if seq: by_source[source]=evaluate(model,seq,device,batch_size)
    by_style={}
    for style in tok.styles:
        seq=[sequences[i] for i in splits['test'] if rows[i]['style']==style]
        if seq: by_style[style]=evaluate(model,seq,device,batch_size)
    # Source-stratified style permutation keeps all targets unchanged.
    ablated=[]
    source_styles={s:sorted({r['style'] for r in rows if r['source']==s}) for s in tok.sources}
    for i in splits['test']:
        ids,mask=sequences[i]; ids=list(ids)
        candidates=source_styles[rows[i]['source']]
        if len(candidates)>1:
            replacement=candidates[(candidates.index(rows[i]['style'])+1)%len(candidates)]
            ids[2]=tok.ids['STYLE_'+replacement]
        ablated.append((ids,mask))
    ablation=evaluate(model,ablated,device,batch_size)
    context_ablation=None
    if tok.prefix_length==11:
        neutral=[]
        for i in splits['test']:
            if rows[i]['source']!='commu': continue
            ids,mask=sequences[i]; ids=list(ids)
            ids[8:11]=[tok.ids['ROLE_unknown'],tok.ids['KEY_unknown'],tok.ids['CHORD_unknown']]
            neutral.append((ids,mask))
        if neutral: context_ablation=evaluate(model,neutral,device,batch_size)
    report={'format':CHECKPOINT_FORMAT,'real_source_training':True,'fresh_weights':True,'synthetic_sequences':0,
            'usage_profile':usage_profile,'research_only':usage_profile=='research-noncommercial',
            'usage_restriction':'noncommercial research only; includes ComMU CC-BY-NC-SA-4.0' if restricted else 'commercial-compatible source policy; individual source attribution applies',
            'runtime':{'python':platform.python_version(),'torch':str(torch.__version__),'cuda':torch.version.cuda,
                       'device':device,'gpu':torch.cuda.get_device_name(0) if device.startswith('cuda') else None},
            'manifest_sha256':manifest_sha,'model_config':asdict(config),'parameters':sum(p.numel() for p in model.parameters()),
            'source_hashes':source_hashes(),'compatibility_hashes':compatibility_hashes(tok.to_dict()['format']),'seed':seed,'elapsed_seconds':time.time()-started,'steps':steps,
            'initial_validation':initial,'history':history,'test':final,'test_by_source':by_source,'test_by_style':by_style,
            'permuted_style_test':ablation,'style_ablation_description':'same weights, source-stratified style prefix permutation; targets unchanged',
            'commu_neutral_context_test':context_ablation,
            'coverage':{'complete_epochs':epochs,'unique_train_sequences_seen':len(visited),'unique_train_files_seen':len(files),
                        'train_sequences':len(splits['train']),'all_splits':{s:len(v) for s,v in splits.items()},
                        'train_sequence_presentations':epochs*len(splits['train'])},
            'source_counts':dict(Counter(r['source'] for r in rows)), 'style_counts':dict(Counter(r['style'] for r in rows)),
            'train_source_counts':dict(Counter(rows[i]['source'] for i in splits['train'])),
            'train_source_style_counts':dict(Counter(rows[i]['source']+'/'+rows[i]['style'] for i in splits['train'])),
            'trained_control_counts':dict(Counter(json.dumps([rows[i]['source'],rows[i]['style'],rows[i]['drum'],rows[i]['program']],separators=(',',':')) for i in splits['train'])),
            'trained_context_counts':dict(Counter(json.dumps([rows[i]['source'],rows[i]['style'],rows[i]['program'],rows[i].get('track_role','unknown'),rows[i].get('audio_key','unknown'),rows[i].get('chord','unknown')],separators=(',',':')) for i in splits['train'])),
            'limitations':['part-bar modeling; missing instruments are not ground-truth empty parts',
                           'style labels are original source styles, not proof of real K-pop melody training',
                           '12 ticks/quarter quantization; raw MIDI and transformation reports retained',
                           'no lyrics or scene-semantic training in this checkpoint']}
    torch.save({'format':CHECKPOINT_FORMAT,'config':asdict(config),'state_dict':model.state_dict(),
                'tokenizer':tok.to_dict(),'identity':report},output/'real-final.pt')
    report['checkpoint_sha256']=hashlib.sha256((output/'real-final.pt').read_bytes()).hexdigest()
    (output/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    (output/'vocabulary.json').write_text(json.dumps(tok.to_dict(),ensure_ascii=False,indent=2),encoding='utf-8')
    return report


def load_checkpoint(path,device='cpu',*,allow_research=False):
    payload=torch.load(Path(path),map_location=device,weights_only=True)
    if payload.get('format') not in ('omr-real-music-v1',CHECKPOINT_FORMAT): raise ValueError('not an actual-music checkpoint')
    td=payload['tokenizer']
    identity=dict(payload['identity'])
    profile=identity.get('usage_profile')
    if profile is None and set(td['sources']).issubset(COMMERCIAL_SOURCES): profile='commercial-compatible'
    if profile not in ('commercial-compatible','research-noncommercial'): raise ValueError('unknown checkpoint usage profile')
    if set(td['sources'])-(COMMERCIAL_SOURCES|RESEARCH_SOURCES): raise ValueError('unreviewed checkpoint source')
    if set(td['sources'])&RESEARCH_SOURCES and profile!='research-noncommercial': raise ValueError('research source/profile mismatch')
    if profile=='research-noncommercial' and not allow_research: raise ValueError('research-only checkpoint requires explicit allow_research=True / --allow-research-model')
    identity.update(usage_profile=profile,research_only=profile=='research-noncommercial')
    if td['format']==FORMAT:
        tok=RealTokenizer(styles=td['styles'],sources=td['sources'])
    elif td['format']=='omr-real-partbar-research-v1':
        from .research_tokenizer import ResearchTokenizer
        tok=ResearchTokenizer(**{k:td[k] for k in ('styles','sources','roles','keys','chords')})
    else: raise ValueError('tokenizer format mismatch')
    if tok.tokens!=td['tokens']: raise ValueError('vocabulary mismatch')
    if identity['compatibility_hashes']!=compatibility_hashes(td['format']): raise ValueError('tokenizer/model source hash mismatch')
    config=MelodyTransformerConfig(**payload['config'])
    if config.vocab_size!=len(tok.tokens): raise ValueError('vocabulary size mismatch')
    model=MelodyTransformer(config).to(device); model.load_state_dict(payload['state_dict'],strict=True); model.eval()
    return model,tok,identity
