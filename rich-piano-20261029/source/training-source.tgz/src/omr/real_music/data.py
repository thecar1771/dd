"""Auditable MIDI conversion. Raw files remain the authoritative source."""
from __future__ import annotations

import bisect
import hashlib
import json
import math
from collections import defaultdict, deque
from pathlib import Path

TICKS = 12
DRUM_MAP = {36:36,38:38,40:38,37:38,48:50,50:50,45:47,47:47,43:43,58:43,
            46:46,26:46,42:42,22:42,44:42,49:49,55:49,57:49,52:49,51:51,59:51,53:51}


def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()


def canonical_notes(events):
    """One physical part cannot hold a MIDI key twice: merge unisons, clip retriggers.

    Quantization and simplified percussion mapping can make separate source hits
    coincide. Keep longest duration/loudest velocity and count every change.
    """
    by_pitch=defaultdict(dict); collapsed=trimmed=0
    for onset,duration,pitch,velocity in events:
        prior=by_pitch[pitch].get(onset)
        if prior is None: by_pitch[pitch][onset]=[onset,duration,pitch,velocity]
        else:
            prior[1]=max(prior[1],duration); prior[3]=max(prior[3],velocity); collapsed+=1
    result=[]
    for pitch,positions in by_pitch.items():
        ordered=[positions[o] for o in sorted(positions)]
        for i,note in enumerate(ordered):
            if i+1<len(ordered) and note[0]+note[1]>ordered[i+1][0]:
                note[1]=ordered[i+1][0]-note[0]; trimmed+=1
            result.append(note)
    return sorted(result),{'simultaneous_unisons_collapsed':collapsed,'same_pitch_retriggers_trimmed':trimmed}


def read_midi_bars(path: Path, *, source: str, style: str):
    import mido
    mid=mido.MidiFile(str(path))
    if mid.type==2:
        raise ValueError('asynchronous type-2 MIDI is unsupported')
    if mid.ticks_per_beat<=0:
        raise ValueError('SMPTE MIDI is unsupported')
    programs=defaultdict(int); active=defaultdict(deque); notes=[]
    meters={0:(4,4)}; tempos={0:120}; clock=0
    report={'raw_notes':0,'unmatched_off':0,'unmatched_on':0,'zero_duration':0,
            'sustain_messages_ignored':0,'quantization_abs_tick_error':0.,'quantization_max_tick_error':0.,
            'grid_ticks_per_quarter':TICKS,'velocity_policy':'original 1..127',
            'sustain_policy':'key-held durations; pedal/controller data retained in raw MIDI only'}
    def quant(t):
        exact=t*TICKS/mid.ticks_per_beat
        value=int(math.floor(exact+.5)); error=abs(value-exact)
        report['quantization_abs_tick_error']+=error
        report['quantization_max_tick_error']=max(report['quantization_max_tick_error'],error)
        return value
    timed=[]
    for track_index,track in enumerate(mid.tracks):
        clock=0
        for event_index,msg in enumerate(track):
            clock+=msg.time; timed.append((clock,track_index,event_index,msg))
    timed.sort(key=lambda item:item[:3])
    for clock,track_index,event_index,msg in timed:
        if msg.type=='time_signature':
            meters[quant(clock)]=(msg.numerator,msg.denominator)
        elif msg.type=='set_tempo':
            tempos[quant(clock)]=max(20,min(300,round(mido.tempo2bpm(msg.tempo))))
        elif msg.type=='program_change':
            programs[msg.channel]=msg.program
        elif msg.type=='control_change' and msg.control==64:
            report['sustain_messages_ignored']+=1
        elif msg.type=='note_on' and msg.velocity>0:
            active[(track_index,msg.channel,msg.note)].append((clock,msg.velocity,programs[msg.channel]))
        elif msg.type in ('note_on','note_off'):
            queue=active[(track_index,msg.channel,msg.note)]
            if not queue:
                report['unmatched_off']+=1; continue
            start,velocity,program=queue.popleft()
            onset,end=quant(start),quant(clock)
            if end<=onset:
                if clock<=start:
                    report['zero_duration']+=1; continue
                end=onset+1
            pitch=DRUM_MAP.get(msg.note,msg.note) if source=='gmd' else msg.note
            notes.append((onset,end,pitch,velocity,program,msg.channel==9,msg.channel,track_index))
    report['unmatched_on']=sum(map(len,active.values()))
    if report['unmatched_on'] or report['unmatched_off']:
        raise ValueError('unmatched MIDI notes: '+str(report))
    if not notes:
        raise ValueError('no positive-duration notes')
    report['raw_notes']=len(notes)
    parts=defaultdict(list)
    for onset,offset,pitch,velocity,program,drum,channel,track in notes:
        parts[(program,drum,channel,track)].append([onset,offset-onset,pitch,velocity])
    notes=[]
    report['simultaneous_unisons_collapsed']=report['same_pitch_retriggers_trimmed']=0
    for (program,drum,channel,track),events in parts.items():
        cleaned,changes=canonical_notes(events)
        for key,value in changes.items(): report[key]+=value
        notes.extend((o,o+d,p,v,program,drum,channel,track) for o,d,p,v in cleaned)
    report['canonical_notes']=len(notes)
    end=max(n[1] for n in notes)
    changes=sorted(meters)
    starts=[]; lengths=[]; signatures=[]; partials=[]; position=0
    while position<end:
        index=bisect.bisect_right(changes,position)-1
        num,den=meters[changes[index]]
        length=num*4*TICKS/den
        if not length.is_integer() or not 1<=length<=384:
            raise ValueError('unrepresentable or oversized meter')
        length=int(length)
        partial=False
        if index+1<len(changes) and position<changes[index+1]<position+length:
            length=changes[index+1]-position; partial=True
        partials.append(partial)
        starts.append(position); lengths.append(length); signatures.append([num,den]); position+=length
    groups=defaultdict(list)
    for onset,offset,pitch,velocity,program,drum,channel,track in notes:
        bar=bisect.bisect_right(starts,onset)-1
        while onset<offset and bar<len(starts):
            boundary=starts[bar]+lengths[bar]
            stop=min(offset,boundary)
            groups[(bar,program,drum,channel,track)].append([onset-starts[bar],stop-onset,pitch,velocity])
            onset=stop; bar+=1
    tempo_times=sorted(tempos); rows=[]
    for (bar,program,drum,channel,track),events in sorted(groups.items()):
        events.sort()
        base={'source':source,'style':style.strip().lower() or 'unknown','bar':bar,
              'meter':signatures[bar],'bar_ticks':lengths[bar],
              'bpm':tempos[tempo_times[bisect.bisect_right(tempo_times,starts[bar])-1]],
              'program':program,'drum':drum,'channel':channel,'track':track,'partial':partials[bar]}
        # Dense bars are chunked, never truncated. Continuations retain absolute bar positions.
        for index in range(0,len(events),112):
            rows.append(dict(base,notes=events[index:index+112],continuation=index>0))
    report['split_notes']=sum(len(r['notes']) for r in rows)
    report['bar_sequences']=len(rows)
    report['measures']=len(starts)
    report['tempo_changes']=len(tempos)-1
    report['meter_changes']=len(meters)-1
    report['partial_measures']=sum(partials)
    report['bar_alignment_policy']='MIDI tick0; each explicit meter change starts a measure; undeclared pickup phase cannot be inferred from MIDI'
    report['content_sha256']=digest({'notes':sorted(n[:6] for n in notes),'meters':sorted(meters.items())})
    return rows,report


def assign_splits(records):
    """Union identical content AND all movements/arrangements of a source work.

    Conflicts resolve conservatively toward test, then validation: no held-out
    work is moved into training. The caller records those promotions.
    """
    parents=list(range(len(records)))
    def find(i):
        while parents[i]!=i:
            parents[i]=parents[parents[i]]; i=parents[i]
        return i
    seen={}
    for i,row in enumerate(records):
        for key in (('work',row['work']),('content',row['content_sha256'])):
            if key in seen:
                a,b=find(i),find(seen[key]); parents[max(a,b)]=min(a,b)
            else: seen[key]=i
    ranks={'train':0,'validation':1,'test':2}
    splits={}
    for i,row in enumerate(records):
        group=find(i); old=splits.get(group,'train')
        splits[group]=max((old,row['split']),key=lambda s:ranks[s])
    return [dict(row,split=splits[find(i)],group=str(find(i))) for i,row in enumerate(records)]
