"""Real-source symbolic music training, separate from synthetic bootstrap weights."""
