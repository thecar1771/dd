"""Finite event grammar for real-source style-conditioned note generation."""
from __future__ import annotations

import torch

from .data import DRUM_MAP


@torch.inference_mode()
def sample_part_bar(model,tok,control,*,seed=0,temperature=.85,max_events=64):
    if not 0<temperature<=3 or not 1<=max_events<=112: raise ValueError('invalid sampling bounds')
    device=next(model.parameters()).device; model.eval()
    rng=torch.Generator(device=device).manual_seed(seed)
    sequence=tok.prefix(dict(control,continuation=False)); events=[]; current=[]; last_onset=0; done=False
    length=control.get('bar_ticks',control['meter'][0]*48//control['meter'][1])
    if not 1<=length<=384: raise ValueError('unsupported meter')
    pitches=sorted(set(DRUM_MAP.values())) if control['drum'] else list(range(36,97))
    monophonic=not control['drum'] and (control['program']==73 or control.get('track_role')=='bass')
    polyphony=control.get('max_polyphony',1 if monophonic else len(pitches))
    if not isinstance(polyphony,int) or not 1<=polyphony<=128: raise ValueError('invalid maximum polyphony')
    def available(onset):
        active=[n for n in events if n[0]<=onset<n[0]+n[1]]
        if len(active)>=polyphony: return []
        occupied={n[2] for n in active}
        return [p for p in pitches if p not in occupied]
    while not done:
        field=len(current)
        if field==0:
            allowed=[tok.ids[f'POS_{i}'] for i in range(last_onset,length) if available(i)]
            if events: allowed.append(tok.ids['EOS'])
            if len(events)>=max_events: allowed=[tok.ids['EOS']]
        elif field==1:
            allowed=[tok.ids[f'DUR_{i}'] for i in range(1,length-current[0]+1)]
        elif field==2:
            allowed=[tok.ids[f'P_{i}'] for i in available(current[0])]
        else:
            allowed=[tok.ids[f'V_{i}'] for i in range(1,128)]
        if len(sequence)>=model.config.max_sequence_length: raise RuntimeError('generation context exhausted')
        if len(allowed)==1: choice=allowed[0]
        else:
            logits=model(torch.tensor([sequence],device=device))[0,-1].float()
            candidates=torch.tensor(allowed,device=device)
            probs=torch.softmax(logits[candidates]/temperature,dim=-1)
            if not torch.isfinite(probs).all(): raise RuntimeError('nonfinite probabilities')
            choice=candidates[torch.multinomial(probs,1,generator=rng)].item()
        sequence.append(choice)
        if choice==tok.ids['EOS']: done=True; continue
        current.append(int(tok.tokens[choice].split('_')[1]))
        if len(current)==4:
            events.append(current); last_onset=current[0]; current=[]
    row=tok.decode(sequence)
    return row,{'terminated':True,'events':len(events),'tokens':len(sequence),'seed':seed,
                'max_polyphony':polyphony,
                'constraints':'nondecreasing onset, bar bounds, max events; GM drum set or pitched range 36..96'}
