"""Integrate reviewed corpora, conservatively holding out composer families.

Mutopia composer codes and OpenScore surname-first paths provide shared family
names. Holding out a whole family also groups different composers with the same
surname: conservative over-grouping is intentional. Official GMD performance
splits remain in force, with exact-copy conflicts promoted toward held-out.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import random
import unicodedata
from collections import Counter,defaultdict
from pathlib import Path,PurePosixPath

from .data import assign_splits,canonical_notes
from .tokenizer import RealTokenizer


def composer_family(row):
    if row['source']=='openscore-lieder':
        parts=PurePosixPath(row['path']).parts
        value=parts[1] if len(parts)>1 and parts[0]=='scores' else ''
    else: value=row.get('attribution',{}).get('composer','')
    value=unicodedata.normalize('NFKD',value).encode('ascii','ignore').decode().strip()
    match=re.match(r'(?:van|von)?([A-Z][a-z]+)',value)
    family=match.group(1).lower() if match else 'unknown'
    return {'hensel':'mendelssohn'}.get(family,family)


def read_rows(path):
    with Path(path).open(encoding='utf-8') as source:
        for line in source:
            if line.strip(): yield json.loads(line)


def stratify_composers(records,seed=20261028):
    """Deterministic label/count-only stratification; never splits a composer family.

    Favor train/validation/test coverage when enough independent families exist.
    A style supplied by only one family stays in training and is explicitly not
    an independently evaluated style. Labels/counts are used, never note content.
    """
    weights=defaultdict(Counter)
    for row in records:
        if row['source']=='gmd': continue
        count=row.get('bar_sequences',row.get('conversion',{}).get('bar_sequences',1))
        weights[row['work']][row['source']+'/'+row['style']]+=count
    groups=sorted(weights); totals=Counter(); members=defaultdict(set)
    for group,values in weights.items():
        totals.update(values)
        for style in values: members[style].add(group)
    forced={next(iter(values)) for values in members.values() if len(values)==1}
    splits=('train','validation','test'); targets=(.8,.1,.1)
    def counts_for(mapping):
        result={s:Counter() for s in splits}
        for group,split in mapping.items(): result[split].update(weights[group])
        return result
    def score(counts):
        value=0.
        for style,total in totals.items():
            n=len(members[style])
            if not counts['train'][style]: value+=10000
            if n>=2 and not counts['test'][style]: value+=100
            if n>=3 and not counts['validation'][style]: value+=60
            value+=sum(abs(counts[s][style]/total-target) for s,target in zip(splits,targets))
        all_total=sum(totals.values())
        if all_total: value+=3*sum(abs(sum(counts[s].values())/all_total-target) for s,target in zip(splits,targets))
        return value
    rng=random.Random(seed); best=None; best_score=float('inf')
    for attempt in range(512):
        mapping={g:'train' if g in forced else rng.choices(splits,weights=targets)[0] for g in groups}
        value=score(counts_for(mapping))
        if value<best_score: best,best_score=mapping,value
    if best is None: return {}
    counts=counts_for(best)
    for iteration in range(4):
        changed=False
        for group in groups:
            if group in forced: continue
            old=best[group]; choice=old
            for split in splits:
                if split==old: continue
                counts[old].subtract(weights[group]); counts[split].update(weights[group])
                value=score(counts)
                if value+1e-12<best_score: choice=split; best_score=value
                counts[split].subtract(weights[group]); counts[old].update(weights[group])
            if choice!=old:
                best[group]=choice; counts[old].subtract(weights[group]); counts[choice].update(weights[group]); changed=True
        if not changed: break
    return best


def integrate(midi_root,lieder_root,output):
    midi_root=Path(midi_root); lieder_root=Path(lieder_root); output=Path(output)
    if output.exists() and any(output.iterdir()): raise FileExistsError('preserve existing integrated dataset')
    output.mkdir(parents=True,exist_ok=True)
    records=list(read_rows(midi_root/'accepted.jsonl'))+list(read_rows(lieder_root/'accepted.jsonl'))
    families=defaultdict(set)
    for row in records:
        row['original_split']=row['split']; row['original_work']=row['work']
        if row['source']!='gmd':
            family=composer_family(row)
            row['work']='composer-family:'+family
            fraction=int(hashlib.sha256(row['work'].encode()).hexdigest()[:8],16)%100
            row['split']='test' if fraction<10 else 'validation' if fraction<20 else 'train'
            families[family].add(row['attribution'].get('composer',''))
    stratified=stratify_composers(records)
    for row in records:
        if row['source']!='gmd': row['split']=stratified[row['work']]
    assigned=assign_splits(records); kept={}; duplicates=[]; seen=set()
    for row in assigned:
        if row['content_sha256'] in seen: duplicates.append(row); continue
        seen.add(row['content_sha256']); kept[row['id']]=row
    counts=Counter(); styles=Counter(); trained_styles=Counter(); style_splits=Counter(); transforms=Counter(); notes=0; total=0; groups=defaultdict(set)
    tokenizer=RealTokenizer(styles=[r['style'] for r in assigned],sources=[r['source'] for r in assigned])
    with (output/'bars.jsonl').open('w',encoding='utf-8',newline='\n') as target:
        for parent in (midi_root,lieder_root):
            for row in read_rows(parent/'bars.jsonl'):
                meta=kept.get(row['file_id'])
                if meta is None: continue
                row.update(id=str(total),group=meta['group'],split=meta['split'])
                row['notes'],changes=canonical_notes(row['notes'])
                transforms.update(changes)
                ids,mask=tokenizer.encode(row)
                if len(ids)>512: raise ValueError('oversize sequence')
                target.write(json.dumps(row,ensure_ascii=False,separators=(',',':'))+'\n')
                counts[(row['source'],row['split'])]+=1; styles[row['style']]+=1
                style_splits[(row['source'],row['style'],row['split'])]+=1
                if row['split']=='train': trained_styles[(row['source'],row['style'])]+=1
                notes+=len(row['notes']); total+=1; groups[row['group']].add(row['split'])
    if any(len(v)>1 for v in groups.values()): raise ValueError('group leakage')
    files=list(kept.values())
    for name,rows in [('accepted.jsonl',files),('duplicates.jsonl',duplicates)]:
        (output/name).write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
    (output/'composer-families.json').write_text(json.dumps({k:sorted(v) for k,v in families.items()},ensure_ascii=False,indent=2),encoding='utf-8')
    inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for root in (midi_root,lieder_root) for p in (root/'bars.jsonl',root/'accepted.jsonl')}
    report={'actual_source_files':len(files),'files_by_source':dict(Counter(r['source'] for r in files)),
            'source_catalog_pieces_used':len({r['id'].rsplit('-',1)[0] for r in files if r['source']=='mutopia'}),
            'bar_sequences':total,'notes':notes,'synthetic_sequences':0,'duplicate_files_excluded_in_merge':len(duplicates),
            'sequences_by_source_split':{f'{a}/{b}':v for (a,b),v in counts.items()},
            'styles_all_splits':dict(styles),'trained_source_styles':{f'{a}/{b}':v for (a,b),v in trained_styles.items()},
            'composer_families':len(families),'group_split_leaks':sum(len(v)>1 for v in groups.values()),
            'integration_canonicalization_counts':dict(transforms),
            'split_policy':'label/count-stratified composer-family heldout across pitched corpora (surname grouping, Hensel=Mendelssohn); GMD official performance splits; duplicate unions promote heldout',
            'source_style_split_sequences':{f'{s}/{g}/{p}':v for (s,g,p),v in style_splits.items()},
            'source_styles_without_test':[f'{s}/{g}' for s,g in trained_styles if not style_splits[(s,g,'test')]],
            'limitations':['surname grouping is conservative and merges namesakes; composer alias mapping retained for review',
                           'source counts are score files or performance clips, not all independent complete songs',
                           'each sequence is an observed instrument part-bar; no fabricated missing parts or lyrics'],
            'input_sha256':inputs,'manifest_sha256':hashlib.sha256((output/'bars.jsonl').read_bytes()).hexdigest()}
    (output/'summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False),flush=True)
    return report


if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--midi-root',required=True); p.add_argument('--lieder-root',required=True); p.add_argument('--output',required=True)
    args=p.parse_args(); integrate(args.midi_root,args.lieder_root,args.output)
