"""Exact MusicXML 4.0 and Standard MIDI export for five-part genre compositions (stdlib only)."""
from __future__ import annotations

import struct
import xml.etree.ElementTree as ET
from collections import defaultdict
from fractions import Fraction
from math import lcm
from pathlib import Path
from typing import Dict, List, Tuple

from omr.genres.contracts import Composition, ScoreEvent
from omr.genres.synthetic import infer_tonic

GRID = Fraction(1, 12)
BAR = Fraction(4)
# Single-note values in twelfths of a quarter: (type, dots, is_triplet).
NOTE_VALUES = {48: ('whole', 0, False), 36: ('half', 1, False), 24: ('half', 0, False),
               18: ('quarter', 1, False), 16: ('half', 0, True), 12: ('quarter', 0, False),
               9: ('eighth', 1, False), 8: ('quarter', 0, True), 6: ('eighth', 0, False),
               4: ('eighth', 0, True), 3: ('16th', 0, False), 2: ('16th', 0, True), 1: ('32nd', 0, True)}
SHARP_NAMES = (('C', 0), ('C', 1), ('D', 0), ('D', 1), ('E', 0), ('F', 0),
               ('F', 1), ('G', 0), ('G', 1), ('A', 0), ('A', 1), ('B', 0))
FLAT_NAMES = (('C', 0), ('D', -1), ('D', 0), ('E', -1), ('E', 0), ('F', 0),
              ('G', -1), ('G', 0), ('A', -1), ('A', 0), ('B', -1), ('B', 0))
KEY_FIFTHS = {0: 0, 7: 1, 2: 2, 9: 3, 4: 4, 11: 5, 6: 6, 1: -5, 8: -4, 3: -3, 10: -2, 5: -1}
CLEFS = {'vocal': ('G', 2), 'piano_rh': ('G', 2), 'piano_lh': ('F', 4), 'bass': ('F', 4), 'drums': ('percussion', 2)}
PART_LABELS = {'vocal': 'Vocal', 'piano_rh': 'Piano RH', 'piano_lh': 'Piano LH', 'bass': 'Bass', 'drums': 'Drums'}
# GM percussion key -> (display step, display octave, notehead, name)
DRUM_DISPLAY = {35: ('F', 4, 'normal', 'Acoustic Bass Drum'), 36: ('F', 4, 'normal', 'Bass Drum'),
                37: ('C', 5, 'x', 'Side Stick'), 38: ('C', 5, 'normal', 'Snare'), 39: ('C', 5, 'x', 'Hand Clap'),
                40: ('C', 5, 'normal', 'Electric Snare'), 42: ('G', 5, 'x', 'Closed Hi-Hat'),
                44: ('D', 4, 'x', 'Pedal Hi-Hat'), 46: ('G', 5, 'circle-x', 'Open Hi-Hat'),
                43: ('A', 4, 'normal', 'High Floor Tom'), 47: ('D', 5, 'normal', 'Low-Mid Tom'),
                50: ('E', 5, 'normal', 'High Tom'),
                49: ('A', 5, 'x', 'Crash Cymbal'), 51: ('F', 5, 'x', 'Ride Cymbal'), 54: ('E', 5, 'x', 'Tambourine'),
                56: ('E', 5, 'triangle', 'Cowbell'), 70: ('E', 5, 'x', 'Maracas'), 75: ('B', 4, 'x', 'Claves')}
RAP_DISPLAY = ('B', 4)
# MIDI: 0-based channels/programs. Drums use channel index 9 (= GM channel 10).
CHANNELS = {'vocal': 0, 'piano_rh': 1, 'piano_lh': 2, 'bass': 3, 'drums': 9}
RAP_GUIDE_CHANNEL, RAP_GUIDE_PROGRAM, RAP_GUIDE_KEY = 5, 115, 76  # woodblock click
RAP_GUIDE_NAME = 'vocal rap rhythm guide (woodblock click, not sung)'
PROGRAMS = {'lead_voice': 53, 'rap_voice': 53, 'acoustic_piano': 0, 'electric_piano': 4, 'acoustic_bass': 32,
            'electric_bass': 33, 'synth_bass': 38}
DEFAULT_PROGRAMS = {'vocal': 53, 'piano_rh': 0, 'piano_lh': 0, 'bass': 33, 'drums': 0}
TPQ = 480
# 'korean' (default): Hangul-only words are displayed as one syllable per note without Western
# inter-syllable hyphens; 'western': emit each event's begin/middle/end marker (legacy hyphenated display).
LYRIC_STYLES = ('korean', 'western')


def _validate(composition: Composition) -> None:
    if not composition.events:
        raise ValueError('composition has no events to export')
    present = {e.part for e in composition.events}
    missing = [p for p in composition.plan.parts if p not in present]
    if missing:
        raise ValueError('plan part(s) without events: %s' % ', '.join(missing))
    for e in composition.events:
        if (e.onset / GRID).denominator != 1 or (e.duration / GRID).denominator != 1:
            raise ValueError('event at bar %d onset %s duration %s is off the supported 1/12-quarter grid'
                             % (e.bar, e.onset, e.duration))
        if e.part == 'drums' and e.pitch is None:
            raise ValueError('drum event at bar %d has no GM percussion key' % e.bar)


def _is_hangul(text: str) -> bool:
    return bool(text) and all('가' <= ch <= '힣' for ch in text)


def _lyric_words(events: List[ScoreEvent]) -> List[List[ScoreEvent]]:
    """Vocal lyric events grouped into the words their begin/middle/end markers describe, in time order."""
    words: List[List[ScoreEvent]] = []
    open_word = False
    for e in sorted((e for e in events if e.part == 'vocal' and e.lyric), key=lambda e: (e.bar, e.onset)):
        if open_word and e.syllabic in ('middle', 'end'):
            words[-1].append(e)
        else:
            words.append([e])
        open_word = e.syllabic in ('begin', 'middle')
    return words


def display_syllabic(composition: Composition, lyric_style: str = 'korean') -> Dict[int, str]:
    """MusicXML <syllabic> per lyric event (keyed by id); events keep their original word markers."""
    if lyric_style not in LYRIC_STYLES:
        raise ValueError('lyric_style must be one of %s' % ', '.join(LYRIC_STYLES))
    marks = {}
    for word in _lyric_words(list(composition.events)):
        hangul = lyric_style == 'korean' and all(_is_hangul(e.lyric) for e in word)
        for e in word:
            marks[id(e)] = 'single' if hangul else e.syllabic
    return marks


def _pieces(value: Fraction, divisions: int) -> List[int]:
    """Exact decomposition of a grid duration into single notatable values (twelfths)."""
    remaining = int(value / GRID)
    allowed = [k for k in sorted(NOTE_VALUES, reverse=True) if k * divisions % 12 == 0]
    out = []
    while remaining:
        piece = next(k for k in allowed if k <= remaining)
        out.append(piece)
        remaining -= piece
    return out


def _voices(events: List[ScoreEvent]) -> List[List[Tuple[Fraction, Fraction, List[ScoreEvent]]]]:
    """Group same-onset/same-duration events into chords; split overlapping chords into voices."""
    groups: Dict[Tuple[Fraction, Fraction], List[ScoreEvent]] = defaultdict(list)
    for e in events:
        groups[(e.onset, e.duration)].append(e)
    voices: List[List] = []
    for (onset, duration), members in sorted(groups.items()):
        members.sort(key=lambda e: (e.pitch if e.pitch is not None else -1))
        for voice in voices:
            if voice[-1][0] + voice[-1][1] <= onset:
                voice.append((onset, duration, members))
                break
        else:
            voices.append([(onset, duration, members)])
    return voices


class _XmlWriter:
    def __init__(self, composition: Composition, divisions: int, lyric_style: str = 'korean'):
        self.c, self.div = composition, divisions
        self.syllabic = display_syllabic(composition, lyric_style)
        tonic = infer_tonic(composition.plan.chords)
        self.fifths = KEY_FIFTHS[tonic]
        self.names = FLAT_NAMES if self.fifths < 0 else SHARP_NAMES
        self.pids = {part: 'P%d' % i for i, part in enumerate(composition.plan.parts, start=1)}

    def ticks(self, value: Fraction) -> int:
        t = value * self.div
        assert t.denominator == 1
        return t.numerator

    def note(self, measure, part, twelfths, voice, event=None, chord=False, tie=(), lyric=None):
        n = ET.SubElement(measure, 'note')
        if chord:
            ET.SubElement(n, 'chord')
        notehead = None
        if event is None or (event.pitch is None and not event.unpitched):
            ET.SubElement(n, 'rest')
        elif event.pitch is not None and not event.unpitched:
            p = ET.SubElement(n, 'pitch')
            step, alter = self.names[event.pitch % 12]
            ET.SubElement(p, 'step').text = step
            if alter:
                ET.SubElement(p, 'alter').text = str(alter)
            ET.SubElement(p, 'octave').text = str(event.pitch // 12 - 1)
        else:
            if part == 'drums':
                step, octave, notehead, _ = DRUM_DISPLAY.get(event.pitch, ('E', 5, 'x', ''))
            else:
                (step, octave), notehead = RAP_DISPLAY, 'x'
            u = ET.SubElement(n, 'unpitched')
            ET.SubElement(u, 'display-step').text = step
            ET.SubElement(u, 'display-octave').text = str(octave)
        ET.SubElement(n, 'duration').text = str(self.ticks(Fraction(twelfths, 12)))
        for kind in tie:
            ET.SubElement(n, 'tie', type=kind)
        if part == 'drums' and event is not None:
            ET.SubElement(n, 'instrument', id='%s-I%d' % (self.pids[part], event.pitch))
        ET.SubElement(n, 'voice').text = str(voice)
        kind, dots, triplet = NOTE_VALUES[twelfths]
        ET.SubElement(n, 'type').text = kind
        for _ in range(dots):
            ET.SubElement(n, 'dot')
        if triplet:
            tm = ET.SubElement(n, 'time-modification')
            ET.SubElement(tm, 'actual-notes').text = '3'
            ET.SubElement(tm, 'normal-notes').text = '2'
        if notehead and notehead != 'normal':
            ET.SubElement(n, 'notehead').text = notehead
        if tie:
            notations = ET.SubElement(n, 'notations')
            for kind in tie:
                ET.SubElement(notations, 'tied', type=kind)
        if lyric:
            ly = ET.SubElement(n, 'lyric', number='1')
            ET.SubElement(ly, 'syllabic').text = self.syllabic.get(id(event), 'single')
            ET.SubElement(ly, 'text').text = lyric
        return n

    def rests(self, measure, part, length: Fraction, voice: int):
        for piece in _pieces(length, self.div):
            self.note(measure, part, piece, voice)

    def measure(self, part_el, part: str, bar: int, events: List[ScoreEvent]):
        plan = self.c.plan
        m = ET.SubElement(part_el, 'measure', number=str(bar + 1))
        if bar == 0:
            attrs = ET.SubElement(m, 'attributes')
            ET.SubElement(attrs, 'divisions').text = str(self.div)
            if part != 'drums':
                key = ET.SubElement(attrs, 'key')
                ET.SubElement(key, 'fifths').text = str(self.fifths)
            time = ET.SubElement(attrs, 'time')
            ET.SubElement(time, 'beats').text = '4'
            ET.SubElement(time, 'beat-type').text = '4'
            sign, line = CLEFS[part]
            clef = ET.SubElement(attrs, 'clef')
            ET.SubElement(clef, 'sign').text = sign
            ET.SubElement(clef, 'line').text = str(line)
            if part == plan.parts[0]:
                d = ET.SubElement(m, 'direction', placement='above')
                metronome = ET.SubElement(ET.SubElement(d, 'direction-type'), 'metronome')
                ET.SubElement(metronome, 'beat-unit').text = 'quarter'
                ET.SubElement(metronome, 'per-minute').text = str(plan.bpm)
                ET.SubElement(d, 'sound', tempo=str(plan.bpm))
        if part == plan.parts[0]:
            section = plan.section_at(bar)
            if section.start_bar == bar:
                d = ET.SubElement(m, 'direction', placement='above')
                ET.SubElement(ET.SubElement(d, 'direction-type'), 'rehearsal').text = section.role
        voices = _voices(events)
        if not voices:
            n = ET.SubElement(m, 'note')
            ET.SubElement(n, 'rest', measure='yes')
            ET.SubElement(n, 'duration').text = str(self.ticks(BAR))
            ET.SubElement(n, 'voice').text = '1'
            return
        for number, voice in enumerate(voices, start=1):
            if number > 1:
                ET.SubElement(ET.SubElement(m, 'backup'), 'duration').text = str(self.ticks(BAR))
            cursor = Fraction(0)
            for onset, duration, members in voice:
                if onset > cursor:
                    self.rests(m, part, onset - cursor, number)
                pieces = _pieces(duration, self.div)
                for i, piece in enumerate(pieces):
                    tie = (('stop',) if i else ()) + (('start',) if i < len(pieces) - 1 else ())
                    for j, event in enumerate(members):
                        self.note(m, part, piece, number, event, chord=j > 0, tie=tie,
                                  lyric=event.lyric if i == 0 else None)
                cursor = onset + duration
            if cursor < BAR:
                self.rests(m, part, BAR - cursor, number)

    def score_part(self, part_list, index: int, part: str, events: List[ScoreEvent]):
        pid = 'P%d' % index
        sp = ET.SubElement(part_list, 'score-part', id=pid)
        ET.SubElement(sp, 'part-name').text = part
        ET.SubElement(sp, 'part-abbreviation').text = PART_LABELS[part]
        channel = CHANNELS[part] + 1
        if part == 'drums':
            keys = sorted({e.pitch for e in events})
            for key in keys:
                si = ET.SubElement(sp, 'score-instrument', id='%s-I%d' % (pid, key))
                ET.SubElement(si, 'instrument-name').text = DRUM_DISPLAY.get(key, ('', 0, '', 'GM %d' % key))[3]
            for key in keys:
                mi = ET.SubElement(sp, 'midi-instrument', id='%s-I%d' % (pid, key))
                ET.SubElement(mi, 'midi-channel').text = str(channel)
                ET.SubElement(mi, 'midi-unpitched').text = str(key + 1)
        else:
            si = ET.SubElement(sp, 'score-instrument', id='%s-I1' % pid)
            ET.SubElement(si, 'instrument-name').text = self.c.plan.instruments.get(part, part)
            mi = ET.SubElement(sp, 'midi-instrument', id='%s-I1' % pid)
            ET.SubElement(mi, 'midi-channel').text = str(channel)
            ET.SubElement(mi, 'midi-program').text = str(_program(self.c, part) + 1)


def _program(composition: Composition, part: str) -> int:
    name=composition.plan.instruments.get(part,'')
    if name.startswith('gm_program_'):
        suffix=name[len('gm_program_'):]
        if not suffix.isdigit() or not 0<=int(suffix)<=127:
            raise ValueError('GM program must be in 0..127')
        return int(suffix)
    return PROGRAMS.get(name, DEFAULT_PROGRAMS[part])


def musicxml(composition: Composition, title: str = 'Scene Song', lyric_style: str = 'korean') -> str:
    """Return MusicXML 4.0 text with one part per plan role, exact integer divisions and full measures.

    ``lyric_style`` only changes lyric display (see LYRIC_STYLES); notes, timing and lyric text are identical.
    """
    _validate(composition)
    divisions = 1
    for e in composition.events:
        divisions = lcm(divisions, e.onset.denominator, e.duration.denominator)
    writer = _XmlWriter(composition, divisions, lyric_style)
    by_part_bar: Dict[str, Dict[int, List[ScoreEvent]]] = defaultdict(lambda: defaultdict(list))
    for e in composition.events:
        by_part_bar[e.part][e.bar].append(e)

    root = ET.Element('score-partwise', version='4.0')
    ET.SubElement(ET.SubElement(root, 'work'), 'work-title').text = title
    ident = ET.SubElement(root, 'identification')
    encoding = ET.SubElement(ident, 'encoding')
    ET.SubElement(encoding, 'software').text = 'omr.genres.export'
    misc = ET.SubElement(ident, 'miscellaneous')
    for key in ('synthetic', 'project_original', 'real_genre_training', 'production_ready', 'generator',
                'template_family'):
        if key in composition.metadata:
            value = composition.metadata[key]
            text = str(value).lower() if isinstance(value, bool) else str(value)
            ET.SubElement(misc, 'miscellaneous-field', name=key).text = text
    for key in ('genre', 'mood', 'groove', 'texture'):
        ET.SubElement(misc, 'miscellaneous-field', name=key).text = str(getattr(composition.plan, key))
    words = _lyric_words(list(composition.events))
    if words:
        # Original word boundaries stay recoverable from the XML even when display drops hyphens.
        ET.SubElement(misc, 'miscellaneous-field', name='lyric_style').text = lyric_style
        ET.SubElement(misc, 'miscellaneous-field', name='lyric_words').text = ' '.join(
            ''.join(e.lyric for e in word) for word in words)
    part_list = ET.SubElement(root, 'part-list')
    for index, part in enumerate(composition.plan.parts, start=1):
        events = [e for e in composition.events if e.part == part]
        writer.score_part(part_list, index, part, events)
    for index, part in enumerate(composition.plan.parts, start=1):
        part_el = ET.SubElement(root, 'part', id='P%d' % index)
        for bar in range(composition.plan.bars):
            writer.measure(part_el, part, bar, by_part_bar[part][bar])
    return '<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(root, encoding='unicode')


# ---------------------------------------------------------------- MIDI

def _vlq(value: int) -> bytes:
    out = [value & 0x7F]
    value >>= 7
    while value:
        out.append(0x80 | (value & 0x7F))
        value >>= 7
    return bytes(reversed(out))


def _meta(kind: int, payload: bytes) -> bytes:
    return bytes((0xFF, kind)) + _vlq(len(payload)) + payload


def _track(name: str, messages: List[Tuple[int, int, bytes]], end_tick: int) -> bytes:
    """``messages`` are (tick, order, bytes); order 0 note-off, 1 meta/program, 2 note-on at equal ticks."""
    body = bytearray(b'\x00' + _meta(0x03, name.encode('utf-8')))
    tick = 0
    for at, _, data in sorted(messages, key=lambda m: (m[0], m[1])):
        body += _vlq(at - tick) + data
        tick = at
    body += _vlq(end_tick - tick) + _meta(0x2F, b'')
    return b'MTrk' + struct.pack('>I', len(body)) + bytes(body)


def _tick(value: Fraction) -> int:
    t = value * TPQ
    if t.denominator != 1:
        raise ValueError('time %s is off the supported 1/12-quarter grid for %d PPQ' % (value, TPQ))
    return t.numerator


def _note_messages(notes: List[Tuple[int, int, int, int]], channel: int, label: str) -> List[Tuple[int, int, bytes]]:
    """notes: (start, end, key, velocity). Rejects same-key overlaps that MIDI cannot represent."""
    last_end: Dict[int, int] = {}
    messages = []
    for start, end, key, velocity in sorted(notes):
        if key in last_end and start < last_end[key]:
            raise ValueError('%s has an overlap on MIDI key %d at tick %d' % (label, key, start))
        last_end[key] = end
        messages.append((start, 2, bytes((0x90 | channel, key, velocity))))
        messages.append((end, 0, bytes((0x80 | channel, key, 0))))
    return messages


def write_midi(composition: Composition, path: Path) -> None:
    """Write a type-1 SMF: conductor + one track per plan part (+ a rap rhythm-guide track when needed)."""
    _validate(composition)
    plan = composition.plan
    end_tick = plan.bars * 4 * TPQ
    conductor = [(0, 1, _meta(0x51, (60_000_000 // plan.bpm).to_bytes(3, 'big'))),
                 (0, 1, _meta(0x58, bytes((4, 2, 24, 8))))]
    tracks = [_track('conductor: %s %s' % (plan.genre, 'synthetic' if composition.metadata.get('synthetic')
                                            else 'composition'), conductor, end_tick)]
    guide_notes, guide_lyrics = [], []
    for part in plan.parts:
        channel = CHANNELS[part]
        notes, extra = [], [(0, 1, bytes((0xC0 | channel, _program(composition, part))))]
        for e in composition.events:
            if e.part != part:
                continue
            if e.pitch is None and not e.unpitched:
                continue  # an explicit rest advances no MIDI note; track end still uses plan duration
            start = _tick(e.bar * BAR + e.onset)
            end = start + _tick(e.duration)
            if part == 'vocal' and e.pitch is None:
                guide_notes.append((start, end, RAP_GUIDE_KEY, e.velocity))
                if e.lyric:
                    guide_lyrics.append((start, 1, _meta(0x05, e.lyric.encode('utf-8'))))
                continue
            notes.append((start, end, e.pitch, e.velocity))
            if e.lyric:
                extra.append((start, 1, _meta(0x05, e.lyric.encode('utf-8'))))
        tracks.append(_track(part, extra + _note_messages(notes, channel, part), end_tick))
    if guide_notes:
        program = [(0, 1, bytes((0xC0 | RAP_GUIDE_CHANNEL, RAP_GUIDE_PROGRAM)))]
        messages = program + guide_lyrics + _note_messages(guide_notes, RAP_GUIDE_CHANNEL, 'rap guide')
        tracks.append(_track(RAP_GUIDE_NAME, messages, end_tick))
    header = b'MThd' + struct.pack('>IHHH', 6, 1, len(tracks), TPQ)
    Path(path).write_bytes(header + b''.join(tracks))
