"""Exact-time multi-part composition contracts, independent of model vocabulary."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from fractions import Fraction
from typing import Any, Dict, Optional, Tuple

GENRES = ('kpop_dance', 'kpop_acoustic', 'pop', 'rap', 'ballad', 'rnb')
PARTS = ('vocal', 'piano_rh', 'piano_lh', 'bass', 'drums')
SECTION_ROLES = ('intro', 'verse', 'prechorus', 'chorus', 'rap', 'bridge', 'outro')


@dataclass(frozen=True)
class Chord:
    root: int
    quality: str = 'major'

    def __post_init__(self):
        if type(self.root) is not int or not 0 <= self.root < 12 or self.quality not in ('major', 'minor'):
            raise ValueError('chord requires root 0..11 and major/minor quality')

    def pitches(self, octave: int = 4) -> Tuple[int, int, int]:
        root = 12 * (octave + 1) + self.root
        return root, root + (3 if self.quality == 'minor' else 4), root + 7


@dataclass(frozen=True)
class Section:
    role: str
    start_bar: int
    bars: int
    energy: int = 2
    vocal_mode: str = 'sung'
    motif: str = 'a'

    def __post_init__(self):
        if self.role not in SECTION_ROLES or self.start_bar < 0 or self.bars <= 0:
            raise ValueError('invalid section role or bar range')
        if self.energy not in (1, 2, 3) or self.vocal_mode not in ('sung', 'rap', 'spoken'):
            raise ValueError('invalid section energy or vocal mode')


@dataclass(frozen=True)
class SongPlan:
    genre: str
    description: str
    mood: str
    language: str
    bpm: int
    bars: int
    seed: int
    sections: Tuple[Section, ...]
    chords: Tuple[Chord, ...]
    parts: Tuple[str, ...] = PARTS
    groove: str = 'straight'
    texture: str = 'block'
    density: int = 2
    instruments: Dict[str, str] = field(default_factory=dict)

    def __post_init__(self):
        if self.genre not in GENRES:
            raise ValueError('unsupported genre')
        if not self.description.strip() or self.language != 'ko':
            raise ValueError('nonempty description and Korean language required for this pilot')
        if type(self.bpm) is not int or not 40 <= self.bpm <= 200:
            raise ValueError('bpm must be an integer in 40..200')
        if type(self.bars) is not int or not 4 <= self.bars <= 128:
            raise ValueError('bars must be in 4..128')
        if len(self.chords) != self.bars:
            raise ValueError('one chord per bar required')
        if not self.parts or len(set(self.parts)) != len(self.parts) or set(self.parts) - set(PARTS):
            raise ValueError('unknown or duplicate parts')
        cursor = 0
        for section in self.sections:
            if section.start_bar != cursor:
                raise ValueError('section coverage must be contiguous without gaps')
            cursor += section.bars
        if cursor != self.bars:
            raise ValueError('section coverage must equal plan bars')
        if self.groove not in ('straight', 'backbeat', 'halftime', 'swing'):
            raise ValueError('unsupported groove')
        if self.texture not in ('block', 'arpeggio', 'syncopated', 'sparse') or self.density not in (1, 2, 3):
            raise ValueError('unsupported texture or density')

    def section_at(self, bar: int) -> Section:
        if not 0 <= bar < self.bars:
            raise ValueError('bar outside plan')
        return next(s for s in self.sections if s.start_bar <= bar < s.start_bar + s.bars)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> 'SongPlan':
        values = dict(data)
        values['sections'] = tuple(Section(**s) for s in data['sections'])
        values['chords'] = tuple(Chord(**c) for c in data['chords'])
        if 'parts' in values:
            values['parts'] = tuple(values['parts'])
        return cls(**values)


@dataclass(frozen=True)
class ScoreEvent:
    bar: int
    onset: Fraction
    duration: Fraction
    part: str
    pitch: Optional[int]
    velocity: int = 80
    lyric: Optional[str] = None
    unpitched: bool = False
    syllabic: str = 'single'

    def __post_init__(self):
        object.__setattr__(self, 'onset', Fraction(self.onset))
        object.__setattr__(self, 'duration', Fraction(self.duration))
        if self.duration <= 0:
            raise ValueError('duration must be positive')
        if self.bar < 0 or self.onset < 0 or self.onset + self.duration > 4:
            raise ValueError('event outside 4/4 bar boundary')
        if self.part not in PARTS:
            raise ValueError('unsupported part')
        if self.pitch is not None and (type(self.pitch) is not int or not 0 <= self.pitch <= 127):
            raise ValueError('pitch must be MIDI 0..127 or None')
        if type(self.velocity) is not int or not 1 <= self.velocity <= 127:
            raise ValueError('velocity outside MIDI range')
        if self.part == 'drums' and not self.unpitched:
            raise ValueError('drums require unpitched events')
        if self.lyric and self.part != 'vocal':
            raise ValueError('lyrics belong to vocal part')
        if self.syllabic not in ('single','begin','middle','end'):
            raise ValueError('invalid lyric syllabic marker')

    def to_dict(self) -> dict:
        values = asdict(self)
        values.update(onset=str(self.onset), duration=str(self.duration))
        return values

    @classmethod
    def from_dict(cls, values: dict) -> 'ScoreEvent':
        return cls(**values)


@dataclass(frozen=True)
class Composition:
    plan: SongPlan
    events: Tuple[ScoreEvent, ...]
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        for event in self.events:
            if event.bar >= self.plan.bars:
                raise ValueError('event bar exceeds song plan')
            if event.part not in self.plan.parts:
                raise ValueError('event part absent from plan')

    def to_dict(self) -> dict:
        return {'format': 'omr-genre-composition-v1', 'plan': self.plan.to_dict(),
                'events': [e.to_dict() for e in self.events], 'metadata': self.metadata}

    @classmethod
    def from_dict(cls, values: dict) -> 'Composition':
        if values.get('format') != 'omr-genre-composition-v1':
            raise ValueError('incompatible composition format')
        return cls(SongPlan.from_dict(values['plan']), tuple(ScoreEvent.from_dict(e) for e in values['events']),
                   dict(values.get('metadata', {})))
