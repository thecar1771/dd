"""Bounded fresh-weight training on disclosed, family-grouped synthetic scores."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import random
import time
from dataclasses import asdict
from pathlib import Path

import torch
from torch import nn

from omr.models.melody_transformer import MelodyTransformer, MelodyTransformerConfig
from .contracts import Composition, GENRES
from .tokenizer import FORMAT, GenreTokenizer

try:
    import tomllib
except ModuleNotFoundError:
    import tomli as tomllib

CHECKPOINT_FORMAT = 'omr-genre-bootstrap-v1'


def source_hashes():
    files=list(Path(__file__).parent.glob('*.py'))+[Path(__file__).parents[1]/'models'/'melody_transformer.py']
    return {str(p.relative_to(Path(__file__).parents[1])).replace('\\','/'):
            hashlib.sha256(p.read_text(encoding='utf-8').replace('\r\n','\n').encode('utf-8')).hexdigest()
            for p in sorted(files)}


def canonical_hash(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')).hexdigest()


def collate(sequences, device):
    size = max(len(ids) for ids, _ in sequences)
    batch = torch.zeros((len(sequences), size), dtype=torch.long, device=device)
    targets = torch.full((len(sequences), size-1), -100, dtype=torch.long, device=device)
    for row, (ids, mask) in enumerate(sequences):
        batch[row, :len(ids)] = torch.tensor(ids, device=device)
        for index in range(1, len(ids)):
            if mask[index]:
                targets[row, index-1] = ids[index]
    return batch[:, :-1], targets


def neutralized(sequences, tokenizer):
    """Input ablation only; not a separately trained genre-free model."""
    defaults = ['BPM_100', 'SECTION_verse', 'ENERGY_2', 'MODE_sung', 'ROOT_0', 'QUALITY_major',
                'GROOVE_straight', 'TEXTURE_block', 'DENSITY_2', 'PHASE_0']
    result = []
    for ids, mask in sequences:
        changed = list(ids)
        changed[2:12] = [tokenizer.ids[t] for t in defaults]
        result.append((changed, mask))
    return result


@torch.inference_mode()
def evaluate(model, sequences, device, batch_size=16):
    model.eval()
    total, count, correct = 0.0, 0, 0
    for start in range(0, len(sequences), batch_size):
        x, y = collate(sequences[start:start+batch_size], device)
        logits = model(x)
        loss = nn.functional.cross_entropy(logits.flatten(0, 1), y.flatten(), ignore_index=-100, reduction='sum')
        total += float(loss)
        count += int((y != -100).sum())
        correct += int(((logits.argmax(-1) == y) & (y != -100)).sum())
    if not count or not math.isfinite(total):
        raise ValueError('evaluation requires finite, loss-bearing targets')
    return {'loss': total/count, 'target_count': count, 'next_token_accuracy': correct/count}


def _fingerprint(composition):
    """Detect literal and transposed vocal-template copies across split groups."""
    vocal = sorted((e for e in composition.events if e.part == 'vocal'), key=lambda e: (e.bar, e.onset))
    first = next((e.pitch for e in vocal if e.pitch is not None), 0)
    return canonical_hash([(e.bar, str(e.onset), str(e.duration), None if e.pitch is None else e.pitch-first, e.unpitched) for e in vocal])


def build_dataset(output: Path, families=60, bars=32, seed=20261028):
    from .plans import build_plan
    from .synthetic import make_composition
    if families < 3:
        raise ValueError('at least3 template families required')
    raw = []
    parents = {}

    def find(value):
        parents.setdefault(value, value)
        while parents[value] != value:
            value = parents[value]
        return value

    fingerprints = {}
    for template in range(families):
        for genre in GENRES:
            p = build_plan('따뜻한 골목을 함께 걸으며 내일을 기대하는 장면', genre=genre, bars=bars, seed=seed+template)
            c = make_composition(p, template_id=template)
            if c.metadata.get('synthetic') is not True:
                raise ValueError('procedural author must explicitly mark synthetic examples')
            family = str(c.metadata.get('template_family_id', c.metadata.get('template_family', template)))
            find(family)
            fingerprint = _fingerprint(c)
            if fingerprint in fingerprints:
                a, b = find(family), find(fingerprints[fingerprint])
                parents[max(a,b)] = min(a,b)
            else:
                fingerprints[fingerprint] = family
            raw.append((family, c))
    groups = sorted({find(family) for family, _ in raw})
    if len(groups) < 3:
        raise ValueError('fewer than3 independent template groups after copy detection')
    random.Random(seed).shuffle(groups)
    heldout = max(1, len(groups)//10)
    mapping = {g: ('test' if i < heldout else 'validation' if i < 2*heldout else 'train') for i,g in enumerate(groups)}
    rows = []
    for family, c in raw:
        group = find(family)
        payload = c.to_dict()
        rows.append({'source': 'project-original-procedural-v1', 'family_id': group, 'declared_family_id': family,
                     'split': mapping[group], 'sha256': canonical_hash(payload), 'composition': payload})
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        raise FileExistsError(f'preserve existing manifest: {output}')
    output.write_text(''.join(json.dumps(row, ensure_ascii=False, sort_keys=True)+'\n' for row in rows), encoding='utf-8')
    summary = {'songs': len(rows), 'effective_template_groups': len(groups),
               'split_groups': {s: sorted(g for g in groups if mapping[g] == s) for s in ('train','validation','test')},
               'manifest_sha256': hashlib.sha256(output.read_bytes()).hexdigest(), 'synthetic': True,
               'real_genre_training': False, 'copy_groups_merged': len(parents)-len(groups)}
    output.with_suffix('.summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
    return summary


def train_records(records, output_dir: Path, *, steps=1200, batch_size=16, seed=20261028,
                  d_model=128, layers=3, max_length=512, device='auto', learning_rate=0.0006,
                  max_seconds=1800, manifest_sha256=None):
    if not 1 <= steps <= 2000 or batch_size < 1 or max_seconds <= 0 or max_seconds > 1800:
        raise ValueError('first experiment requires1..2000 steps and at most1800 seconds')
    if not math.isfinite(learning_rate) or learning_rate <= 0:
        raise ValueError('learning rate must be finite and positive')
    tokenizer = GenreTokenizer()
    if manifest_sha256 is None:
        manifest_sha256=canonical_hash(records)
    splits = {s: [] for s in ('train', 'validation', 'test')}
    groups = {s: set() for s in splits}
    observed_fingerprints = {}
    for row in records:
        if row['split'] not in splits:
            raise ValueError('unknown split')
        c = Composition.from_dict(row['composition'])
        if c.metadata.get('synthetic') is not True:
            raise ValueError('this trainer accepts only disclosed synthetic bootstrap data')
        if 'sha256' in row and row['sha256'] != canonical_hash(row['composition']):
            raise ValueError('composition checksum mismatch')
        fingerprint = _fingerprint(c)
        if fingerprint in observed_fingerprints and observed_fingerprints[fingerprint] != row['split']:
            raise ValueError('vocal template fingerprint occurs across split families')
        observed_fingerprints[fingerprint] = row['split']
        groups[row['split']].add(str(row['family_id']))
        for bar in range(c.plan.bars):
            sequence = tokenizer.encode_bar(c, bar)
            if len(sequence[0])-1 > max_length:
                raise ValueError('bar exceeds model context; reduce procedural event count')
            splits[row['split']].append(sequence)
    if any(groups[a] & groups[b] for a,b in (('train','validation'),('train','test'),('validation','test'))):
        raise ValueError('template family occurs in multiple splits')
    if any(not value for value in splits.values()):
        raise ValueError('all3 splits require nonempty grouped data')
    output_dir = Path(output_dir)
    if (output_dir/'genre-final.pt').exists() or (output_dir/'result.json').exists():
        raise FileExistsError('existing training evidence must not be overwritten')
    output_dir.mkdir(parents=True, exist_ok=True)
    if device == 'auto':
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
    actual_device = torch.device(device)
    if actual_device.type == 'cuda' and not torch.cuda.is_available():
        raise RuntimeError('CUDA required but unavailable')
    if actual_device.type == 'cpu':
        torch.set_num_threads(1)
    rng = random.Random(seed)
    torch.manual_seed(seed)
    if actual_device.type == 'cuda':
        torch.cuda.manual_seed_all(seed)
    config = MelodyTransformerConfig(tokenizer.vocab_size, d_model=d_model, nhead=4, num_layers=layers,
                                    dim_feedforward=d_model*3, dropout=0.0, max_sequence_length=max_length)
    model = MelodyTransformer(config).to(actual_device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate)
    # Equal fixed-size length buckets avoid very short rows paying for long padding.
    ordered = sorted(range(len(splits['train'])), key=lambda i: len(splits['train'][i][0]))
    buckets = [ordered[i:i+batch_size] for i in range(0, len(ordered), batch_size)]
    start = time.perf_counter()
    initial = evaluate(model, splits['train'], actual_device, batch_size)
    losses, completed, seen_indices = [], 0, set()
    with (output_dir/'train-log.jsonl').open('w', encoding='utf-8') as log:
        for step in range(steps):
            if time.perf_counter()-start >= max_seconds:
                break
            indices = rng.choice(buckets)
            seen_indices.update(indices)
            x,y = collate([splits['train'][i] for i in indices], actual_device)
            model.train(); optimizer.zero_grad(set_to_none=True)
            with torch.autocast('cuda', dtype=torch.bfloat16, enabled=actual_device.type == 'cuda'):
                logits=model(x)
                loss=nn.functional.cross_entropy(logits.flatten(0,1),y.flatten(),ignore_index=-100)
            value=float(loss.detach())
            if not math.isfinite(value):
                raise RuntimeError('nonfinite training loss')
            loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0); optimizer.step()
            losses.append(value); completed += 1
            if completed == 1 or completed % 50 == 0 or completed == steps:
                entry={'step':completed,'loss':value,'elapsed_seconds':time.perf_counter()-start}
                log.write(json.dumps(entry)+'\n'); log.flush(); print(json.dumps(entry),flush=True)
    if not completed:
        raise RuntimeError('training budget expired before first optimizer update')
    training = evaluate(model,splits['train'],actual_device,batch_size)
    validation = evaluate(model,splits['validation'],actual_device,batch_size)
    test = evaluate(model,splits['test'],actual_device,batch_size)
    ablated = evaluate(model,neutralized(splits['test'],tokenizer),actual_device,batch_size)
    split_groups={s:sorted(g) for s,g in groups.items()}
    identity={'manifest_sha256':manifest_sha256,'split_groups':split_groups,
              'split_sha256':canonical_hash(split_groups),'sequence_counts':{s:len(v) for s,v in splits.items()},
              'synthetic':True,'real_genre_training':False,'production_ready':False,
              'lyric_semantics_learned':False,'scene_planner_learned':False,'v2_weights_reused':False}
    identity['source_files_sha256']=source_hashes()
    identity['train_sequences_seen']=len(seen_indices)
    checkpoint={'format':CHECKPOINT_FORMAT,'tokenizer_format':FORMAT,'tokens':tokenizer.tokens,
                'model_config':asdict(config),'model_state':model.state_dict(),'optimizer_state':optimizer.state_dict(),
                'seed':seed,'steps_completed':completed,'identity':identity}
    path=output_dir/'genre-final.pt'; torch.save(checkpoint,path)
    result={**identity,'format':CHECKPOINT_FORMAT,'seed':seed,'steps_requested':steps,'steps_completed':completed,
            'device':actual_device.type,'torch_version':str(torch.__version__),
            'gpu':torch.cuda.get_device_name(0) if actual_device.type=='cuda' else None,
            'parameter_count':sum(p.numel() for p in model.parameters()),'model_config':asdict(config),
            'initial_train':initial,'final_train':training,'validation':validation,'test':test,
            'neutralized_condition_test':ablated,'ablation_kind':'same final weights, neutralized control inputs; not separate training',
            'train_groups':split_groups['train'],'runtime_seconds':time.perf_counter()-start,
            'checkpoint_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'selection':'fixed final step; no heldout checkpoint selection','last_batch_loss':losses[-1]}
    (output_dir/'result.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8')
    return result


def load_checkpoint(path: Path, device: torch.device):
    checkpoint=torch.load(path,map_location=device,weights_only=True)
    tokenizer=GenreTokenizer()
    if checkpoint.get('format') != CHECKPOINT_FORMAT or checkpoint.get('tokenizer_format') != FORMAT:
        raise ValueError('checkpoint format mismatch')
    if checkpoint.get('tokens') != tokenizer.tokens:
        raise ValueError('checkpoint vocabulary mismatch')
    identity=checkpoint.get('identity',{})
    required_flags={'synthetic':True,'real_genre_training':False,'production_ready':False,
                    'v2_weights_reused':False,'lyric_semantics_learned':False,'scene_planner_learned':False}
    if any(identity.get(key) is not value for key,value in required_flags.items()):
        raise ValueError('checkpoint provenance identity is incompatible with synthetic bootstrap')
    groups=identity.get('split_groups',{})
    if (set(groups)!= {'train','validation','test'} or any(not values for values in groups.values())
            or identity.get('split_sha256') != canonical_hash(groups)
            or any(set(groups[a]) & set(groups[b]) for a,b in (('train','validation'),('train','test'),('validation','test')))):
        raise ValueError('checkpoint split identity is invalid')
    digest=identity.get('manifest_sha256','')
    if len(digest)!=64 or any(ch not in '0123456789abcdef' for ch in digest):
        raise ValueError('checkpoint data identity hash is invalid')
    current=source_hashes(); saved=identity.get('source_files_sha256',{})
    for key in ('genres/contracts.py','genres/tokenizer.py','models/melody_transformer.py'):
        if saved.get(key)!=current.get(key):
            raise ValueError('checkpoint incompatible source identity: '+key)
    config=MelodyTransformerConfig(**checkpoint['model_config'])
    if config.vocab_size != tokenizer.vocab_size or config.pad_id != tokenizer.pad_id:
        raise ValueError('checkpoint model/vocabulary identity mismatch')
    model=MelodyTransformer(config).to(device)
    model.load_state_dict(checkpoint['model_state'],strict=True)
    if any(not torch.isfinite(value).all() for value in model.state_dict().values()):
        raise ValueError('checkpoint contains nonfinite weights')
    model.eval()
    return model,tokenizer,identity


def train(config_path: Path):
    config_path=Path(config_path).resolve()
    with config_path.open('rb') as stream:
        payload=tomllib.load(stream)
    values=dict(payload['training']); model_values=payload.get('model',{})
    manifest=(config_path.parent/values.pop('manifest')).resolve()
    output=(config_path.parent/values.pop('output_dir')).resolve()
    records=[json.loads(line) for line in manifest.read_text(encoding='utf-8').splitlines() if line.strip()]
    return train_records(records,output,manifest_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest(),**values,**model_values)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('config',type=Path,nargs='?')
    parser.add_argument('--build-dataset',type=Path)
    parser.add_argument('--families',type=int,default=60)
    args=parser.parse_args()
    if args.build_dataset:
        result=build_dataset(args.build_dataset,families=args.families)
    elif args.config:
        result=train(args.config)
    else:
        parser.error('provide config or --build-dataset')
    print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)


if __name__=='__main__':
    main()
