"""Original procedural five-part arrangements on an exact 1/12-quarter grid.

All material (rhythm cells, contours, lyric lines) is written for this project. Template families are
derived only from ``template_id``; the id belongs in metadata for grouped splits, never in model input.
"""
from __future__ import annotations

import hashlib
import math
import random
from fractions import Fraction
from typing import Dict, List, Sequence, Tuple

from omr.genres.contracts import Chord, Composition, ScoreEvent, Section, SongPlan

GENERATOR = 'omr.genres.synthetic/v1'
TICKS = 12  # grid units per quarter note; every onset/duration below is an integer number of twelfths
BAR = 4 * TICKS
MAJOR = (0, 2, 4, 5, 7, 9, 11)
NOTATABLE = {48, 36, 24, 18, 16, 12, 9, 8, 6, 4, 3, 2, 1}

Cell = Tuple[Tuple[int, int], ...]

SUNG_CELLS: Tuple[Cell, ...] = (
    ((0, 12), (12, 12), (24, 12), (36, 12)),
    ((0, 6), (6, 6), (12, 6), (18, 6), (24, 12), (36, 12)),
    ((0, 6), (6, 12), (18, 6), (24, 6), (30, 18)),
    ((6, 6), (12, 6), (18, 6), (24, 12), (36, 6), (42, 6)),
    ((0, 4), (4, 4), (8, 4), (12, 12), (24, 8), (32, 8), (40, 8)),
    ((0, 9), (9, 3), (12, 6), (18, 6), (24, 9), (33, 3), (36, 12)),
    ((0, 18), (18, 6), (24, 12), (36, 12)),
    ((0, 6), (6, 3), (9, 3), (12, 6), (18, 6), (24, 6), (30, 6), (36, 6), (42, 6)),
    ((0, 12), (12, 6), (18, 6), (24, 6), (30, 6), (36, 6), (42, 6)),
    ((6, 6), (12, 9), (21, 3), (24, 6), (30, 6), (36, 12)),
)
END_CELLS: Tuple[Cell, ...] = (
    ((0, 6), (6, 6), (12, 12), (24, 18)),
    ((0, 12), (12, 6), (18, 6), (24, 24)),
    ((0, 6), (6, 6), (12, 6), (18, 18)),
    ((0, 4), (4, 4), (8, 4), (12, 12), (24, 12)),
)
RAP_CELLS: Tuple[Cell, ...] = (
    ((0, 6), (6, 3), (9, 3), (12, 6), (18, 6), (24, 6), (30, 3), (33, 3), (36, 6)),
    ((0, 4), (4, 4), (8, 4), (12, 4), (16, 4), (20, 4), (24, 6), (30, 6), (36, 12)),
    ((3, 3), (6, 6), (12, 3), (15, 3), (18, 6), (24, 6), (30, 6), (36, 3), (39, 3)),
    ((0, 9), (9, 3), (12, 6), (18, 6), (24, 9), (33, 3), (36, 6), (42, 6)),
    ((0, 6), (6, 6), (12, 6), (18, 6), (24, 6), (30, 6), (36, 6)),
    ((0, 3), (3, 3), (6, 6), (12, 4), (16, 4), (20, 4), (24, 12), (36, 6)),
)
RAP_END: Cell = ((0, 6), (6, 6), (12, 6), (18, 6), (24, 12))
CONTOURS = ('arch', 'rise', 'fall', 'wave', 'valley')

# Accompaniment rhythms: texture -> density -> variants of (onset, duration) hits.
RH_PATTERNS = {
    'block': {1: (((0, 24), (24, 24)), ((0, 36), (36, 12))),
              2: (((0, 12), (12, 12), (24, 12), (36, 12)), ((0, 24), (24, 12), (36, 12))),
              3: (((0, 6), (6, 12), (18, 6), (24, 12), (36, 12)), ((0, 12), (12, 6), (18, 18), (36, 12)))},
    'syncopated': {1: (((0, 18), (18, 30)),),
                   2: (((0, 9), (9, 15), (24, 9), (33, 15)), ((0, 18), (18, 18), (36, 12))),
                   3: (((0, 6), (9, 9), (18, 6), (30, 6), (42, 6)), ((0, 9), (9, 9), (24, 6), (30, 12), (42, 6)))},
    'sparse': {1: (((0, 24), (24, 24)),),
               2: (((0, 9), (18, 6), (24, 9)), ((0, 36), (36, 12))),
               3: (((0, 6), (18, 6), (24, 6), (42, 6)), ((0, 9), (18, 6), (24, 9)))},
    'arpeggio': {1: (tuple((i * 6, 6) for i in range(8)), ((0, 12), (12, 6), (18, 6), (24, 12), (36, 6), (42, 6))),
                 2: (tuple((i * 6, 6) for i in range(8)), tuple((i * 4, 4) for i in range(12))),
                 3: (tuple((i * 4, 4) for i in range(12)), tuple((i * 6, 6) for i in range(8)))},
}
SWING_RH = (((0, 8), (8, 16), (24, 8), (32, 16)), ((0, 16), (16, 8), (24, 16), (40, 8)))
ARP_ORDERS = ((0, 1, 2, 3, 2, 1), (0, 2, 1, 3, 1, 2), (0, 1, 2, 1))
LH_PATTERNS = {1: (((0, 48, 'dyad'),),),
               2: (((0, 24, 'root'), (24, 24, 'fifth')), ((0, 36, 'dyad'),)),
               3: (((0, 12, 'root'), (12, 12, 'fifth'), (24, 12, 'octave'), (36, 12, 'fifth')),
                   ((0, 24, 'dyad'), (24, 24, 'dyad')))}
SWING_LH = ((0, 24, 'root'), (24, 16, 'fifth'), (40, 8, 'octave'))
# Bass: groove -> variants of (onset, duration, degree offset in semitones).
BASS_PATTERNS = {
    'straight': (((0, 36, 0), (36, 12, 7)), ((0, 24, 0), (24, 24, 7))),
    'backbeat': (((0, 18, 0), (18, 6, 0), (24, 12, 7), (36, 12, 0)),
                 ((0, 12, 0), (18, 6, 0), (24, 18, 7), (42, 6, 12))),
    'backbeat3': (tuple((i * 6, 6, 12 if i % 2 else 0) for i in range(8)),
                  ((0, 9, 0), (9, 9, 0), (18, 6, 12), (24, 9, 0), (33, 9, 7), (42, 6, 12))),
    'halftime': (((0, 18, 0), (18, 6, 0), (30, 6, 7), (36, 12, 0)), ((0, 30, 0), (30, 6, 12), (42, 6, 7))),
    'swing': (((0, 16, 0), (16, 8, 7), (24, 12, 0), (36, 8, 7), (44, 4, 11)),
              ((0, 24, 0), (32, 8, 12), (40, 8, 7))),
}
KICK, SIDE, SNARE, CLAP, CHH, PEDAL, OHH, CRASH, RIDE, TAMB, SHAKER = 36, 37, 38, 39, 42, 44, 46, 49, 51, 54, 70

LYRICS = {
    'warm': ('오늘도 작은 빛이 창가에 내려앉아', '익숙한 길 위에서 너의 이름 불러',
             '천천히 걸어가도 괜찮다고 말해', '손끝에 남은 온도 아직도 따뜻해'),
    'bright': ('햇살이 쏟아지는 거리 위를 달려', '웃음이 번져가는 우리만의 계절',
               '가벼운 발걸음에 노래가 피어나', '하늘색 바람 속에 마음을 띄워'),
    'sad': ('비 내린 골목 끝에 혼자 남겨져', '지워진 발자국을 하나씩 세어봐',
            '말하지 못한 말이 가슴에 고여', '희미한 불빛 아래 너를 그려봐'),
    'calm': ('조용한 새벽 공기 숨을 고르고', '느리게 흐르는 시간 위에 앉아',
             '창밖의 나무처럼 가만히 서서', '작은 숨결 하나도 소중히 담아'),
    'energetic': ('멈추지 마 지금 이 순간을 달려', '심장이 뛰는 소리 크게 울려봐',
                  '모두 함께 손을 들고 소리쳐', '눈부신 무대 위로 뛰어올라'),
    'dreamy': ('별빛이 내려오는 밤하늘 아래', '꿈결 같은 노래가 귓가에 맴돌아',
               '달빛을 따라 걷는 조용한 여행', '구름 위를 걷듯이 가볍게 날아'),
}
HOOKS = {
    'warm': ('따뜻한 너의 곁에 머물러', '오늘의 노래를 함께 불러'),
    'bright': ('반짝이는 하루를 노래해', '너와 나 같은 하늘 아래'),
    'sad': ('잊지 못할 너의 목소리', '다시 한번 그 이름 불러'),
    'calm': ('괜찮아 천천히 쉬어가', '고요한 이 밤을 안아줘'),
    'energetic': ('지금 여기 우리 함께 뛰어', '멈추지 마 끝까지 달려'),
    'dreamy': ('꿈속에서 너를 만나', '별빛 따라 날아올라'),
}
PRECHORUS = ('조금만 더 가까이 와 줘', '숨을 크게 쉬고 하나 둘 셋', '마음이 먼저 너에게 닿아')
BRIDGE = ('다시 처음처럼 너를 부를게', '멀리 돌아와도 여기 있을게', '흔들려도 나는 괜찮아')
RAP = ('한 걸음 또 한 걸음 내 박자에 맞춰 걸어', '바쁜 도시 소음 속 내 목소리를 꺼내',
       '어제의 나보다 조금 더 앞으로 가', '리듬 위에 올라탄 내 이야기를 들어봐',
       '작은 방 불빛 아래 써 내려간 내 문장', '느려도 멈추지 않아 이건 나만의 속도')


def _syllables(lines: Sequence[str]) -> List[str]:
    return [ch for line in lines for ch in line if 0xAC00 <= ord(ch) <= 0xD7A3]


def _mutate(cell: Cell, rng: random.Random) -> Cell:
    """Split or merge one note while staying on notatable grid durations and 4..10 notes."""
    notes = [list(n) for n in cell]
    if rng.random() < 0.5 and len(notes) < 10:
        options = [i for i, (_, d) in enumerate(notes) if d % 2 == 0 and d // 2 in NOTATABLE and d >= 6]
        if options:
            i = rng.choice(options)
            on, d = notes[i]
            notes[i:i + 1] = [[on, d // 2], [on + d // 2, d // 2]]
    elif len(notes) > 4:
        options = [i for i in range(len(notes) - 1) if notes[i][0] + notes[i][1] == notes[i + 1][0]
                   and notes[i][1] + notes[i + 1][1] in NOTATABLE]
        if options:
            i = rng.choice(options)
            notes[i:i + 2] = [[notes[i][0], notes[i][1] + notes[i + 1][1]]]
    return tuple(tuple(n) for n in notes)


def template_family(template_id: int) -> Dict:
    """Deterministic family parameters for one template id (shared by every genre and seed)."""
    if type(template_id) is not int or template_id < 0:
        raise ValueError('template_id must be a nonnegative integer')
    rng = random.Random('family|%d' % template_id)
    pick = lambda pool, k=1: [pool[i] for i in rng.sample(range(len(pool)), k)]  # noqa: E731
    family = {
        'verse': [_mutate(c, rng) for c in pick(SUNG_CELLS, 2)],
        'pre': _mutate(pick(SUNG_CELLS)[0], rng),
        'hook': [_mutate(c, rng) for c in pick(SUNG_CELLS, 2)],
        'bridge': _mutate(pick(SUNG_CELLS)[0], rng),
        'ends': pick(END_CELLS, 2),
        'rap': [_mutate(c, rng) for c in pick(RAP_CELLS, 2)],
        'contour': rng.choice(CONTOURS),
        'hook_contour': rng.choice(CONTOURS),
        'center': rng.choice((62, 64, 65, 67, 69)),
        'leap': rng.choice((0.1, 0.25, 0.4)),
        'arp_order': rng.randrange(len(ARP_ORDERS)),
        'rh': rng.randrange(2), 'lh': rng.randrange(2), 'bass': rng.randrange(2),
        'fill': rng.random() < 0.6, 'kick_push': rng.random() < 0.5,
    }
    family['signature'] = hashlib.sha1(repr(sorted(family.items())).encode()).hexdigest()[:16]
    return family


def infer_tonic(chords: Sequence[Chord]) -> int:
    """Major-key tonic whose diatonic triads explain the most chords (ties: closest to first root)."""
    def fit(tonic):
        hits = 0
        for c in chords:
            degree = (c.root - tonic) % 12
            hits += (degree in (0, 5, 7) and c.quality == 'major') or (degree in (2, 4, 9) and c.quality == 'minor')
        return hits
    first = chords[0].root if chords[0].quality == 'major' else (chords[0].root + 3) % 12
    return max(range(12), key=lambda t: (fit(t), -((t - first) % 12)))


def _contour(name: str, t: float) -> float:
    return {'arch': -0.6 + 1.6 * math.sin(math.pi * t), 'rise': -1 + 2 * t, 'fall': 1 - 2 * t,
            'wave': math.sin(2 * math.pi * t), 'valley': 0.6 - 1.6 * math.sin(math.pi * t)}[name]


class _Arranger:
    def __init__(self, plan: SongPlan, template_id: int):
        self.plan, self.family = plan, template_family(template_id)
        self.rng = random.Random('arr|%s|%d|%d' % (plan.genre, plan.seed, template_id))
        self.tonic = infer_tonic(plan.chords)
        center = self.family['center']
        self.scale = [p for p in range(center - 9, center + 10) if (p - self.tonic) % 12 in MAJOR]
        self.events: List[ScoreEvent] = []
        self.prev_pitch = center
        self.hook: Dict[int, List[Tuple[int, int, int, str]]] = {}
        self.lyric_cursor: Dict[str, int] = {}
        self.voicing = None
        self.template_id = template_id

    # ---- helpers
    def add(self, bar, on, dur, part, pitch, velocity, lyric=None, unpitched=False):
        velocity = max(1, min(127, velocity))
        self.events.append(ScoreEvent(bar, Fraction(on, TICKS), Fraction(dur, TICKS), part, pitch, velocity,
                                      lyric, unpitched))

    def density(self, section: Section) -> int:
        return max(1, min(3, self.plan.density + (section.energy == 3) - (section.energy == 1)))

    def take_lyrics(self, key: str, lines: Sequence[str], count: int, restart: bool = False) -> List[str]:
        """Next ``count`` original syllables of a lyric stream; ``restart`` rewinds it (repeated hooks)."""
        syllables = _syllables(lines)
        start = 0 if restart else self.lyric_cursor.get(key, 0)
        self.lyric_cursor[key] = start + count
        return [syllables[(start + i) % len(syllables)] for i in range(count)]

    # ---- vocal
    def melody(self, cell: Cell, chord: Chord, contour: str, phrase_pos: int, cadence: bool) -> List[int]:
        center, span = self.family['center'], 6
        chord_pcs = {p % 12 for p in chord.pitches()}
        chord_tones = [p for p in self.scale if p % 12 in chord_pcs]
        pitches = []
        for i, (on, dur) in enumerate(cell):
            t = (phrase_pos * BAR + on) / (4 * BAR)
            target = center + span * _contour(contour, t)
            strong = (on % 24 == 0) or dur >= 12
            last = cadence and i == len(cell) - 1
            if last:
                pool = [p for p in chord_tones if (p - chord.root) % 12 in (0, 3, 4)] or chord_tones
                target = center - 2
            else:
                pool = chord_tones if strong else self.scale
            repeat = 2.0 + (3.0 if len(pitches) > 1 and pitches[-1] == pitches[-2] else 0.0)
            scored = sorted(pool, key=lambda p: (abs(p - target) + 0.6 * abs(p - self.prev_pitch)
                                                 + (repeat if p == self.prev_pitch else 0) + self.rng.random() * 0.8, p))
            choice = scored[1] if len(scored) > 1 and not last and self.rng.random() < self.family['leap'] else scored[0]
            pitches.append(choice)
            self.prev_pitch = choice
        return pitches

    def vocal_section(self, section: Section):
        plan, fam, role = self.plan, self.family, section.role
        mood = plan.mood
        if role == 'intro':
            return
        if role == 'outro':
            for k in range(min(2, section.bars)):
                for on, dur, pitch, lyric in self.hook.get(k, ()):
                    self.add(section.start_bar + k, on, dur, 'vocal', pitch, 76, lyric)
            return
        for k in range(section.bars):
            bar, pos = section.start_bar + k, k % 4
            chord = plan.chords[bar]
            if role == 'chorus' and k % 8 in self.hook:
                for on, dur, pitch, lyric in self.hook[k % 8]:
                    self.add(bar, on, dur, 'vocal', pitch, 96, lyric)
                continue
            if role == 'chorus' and k % 8 in (4, 5) and (k % 8 - 4) in self.hook:
                self.hook[k % 8] = list(self.hook[k % 8 - 4])  # recall the opening hook within the chorus
                for on, dur, pitch, lyric in self.hook[k % 8]:
                    self.add(bar, on, dur, 'vocal', pitch, 96, lyric)
                continue
            if role == 'rap':
                cell = RAP_END if pos == 3 else fam['rap'][pos % 2]
                for (on, dur), syl in zip(cell, self.take_lyrics('rap', RAP, len(cell))):
                    self.add(bar, on, dur, 'vocal', None, 92 if on % 12 == 0 else 80, syl, unpitched=True)
                continue
            if role == 'chorus':
                cell = fam['ends'][1] if pos == 3 else fam['hook'][pos % 2]
                lines, contour, key = HOOKS[mood], fam['hook_contour'], 'hook'
            elif role == 'prechorus':
                cell, lines, contour, key = fam['ends'][1] if pos == 3 else fam['pre'], PRECHORUS, 'rise', 'pre'
            elif role == 'bridge':
                cell, lines, contour, key = fam['ends'][0] if pos == 3 else fam['bridge'], BRIDGE, 'valley', 'bridge'
            else:
                cell = fam['ends'][0] if pos == 3 else fam['verse'][pos % 2]
                lines, contour, key = LYRICS[mood], fam['contour'], 'verse'
            restart = role == 'chorus' and k == 0
            syllables = self.take_lyrics(key, lines, len(cell), restart=restart)
            pitches = self.melody(cell, chord, contour, pos, cadence=pos == 3)
            notes = [(on, dur, p, s) for (on, dur), p, s in zip(cell, pitches, syllables)]
            if role == 'chorus':
                self.hook[k % 8] = notes
            for on, dur, p, s in notes:
                self.add(bar, on, dur, 'vocal', p, 88 if on % 12 == 0 else 78, s)

    # ---- accompaniment
    def voice_chord(self, chord: Chord) -> List[int]:
        r, t, f = chord.pitches(4)
        options = ([r, t, f], [t, f, r + 12], [f, r + 12, t + 12])
        if self.voicing is None:
            best = min(options, key=lambda v: abs(sum(v) / 3 - 67))
        else:
            best = min(options, key=lambda v: (sum(abs(a - b) for a, b in zip(v, self.voicing)), v))
        if best[0] > 69:
            best = [p - 12 for p in best]
        self.voicing = best
        return best

    def piano_bar(self, bar: int, section: Section):
        plan, fam = self.plan, self.family
        chord, d = plan.chords[bar], self.density(section)
        voicing = self.voice_chord(chord)
        velocity = 58 + 8 * section.energy
        if plan.texture == 'arpeggio':
            variants = RH_PATTERNS['arpeggio'][d]
            hits = variants[fam['rh'] % len(variants)]
            if plan.groove == 'swing':
                hits = tuple((i * 4, 4) for i in range(12))
            tones = voicing + [voicing[0] + 12]
            order = ARP_ORDERS[fam['arp_order']]
            for i, (on, dur) in enumerate(hits):
                self.add(bar, on, dur, 'piano_rh', tones[order[i % len(order)]],
                         velocity + (6 if on % 12 == 0 else 0))
        else:
            variants = SWING_RH if plan.groove == 'swing' else RH_PATTERNS[plan.texture][d]
            for on, dur in variants[fam['rh'] % len(variants)]:
                for p in voicing:
                    self.add(bar, on, dur, 'piano_rh', p, velocity)
        root = 36 + chord.root if chord.root >= 4 else 48 + chord.root
        lh = {'root': [root], 'fifth': [root + 7], 'octave': [root + 12], 'dyad': [root, root + 7]}
        variants = (SWING_LH,) if plan.groove == 'swing' else LH_PATTERNS[d]
        for on, dur, kind in variants[fam['lh'] % len(variants)]:
            for p in lh[kind]:
                self.add(bar, on, dur, 'piano_lh', p, velocity - 6)

    def bass_bar(self, bar: int, section: Section):
        plan = self.plan
        key = 'backbeat3' if plan.groove == 'backbeat' and self.density(section) == 3 else plan.groove
        variants = BASS_PATTERNS[key]
        root = 28 + (plan.chords[bar].root + 8) % 12  # E1..D#2 keeps octave/fifth jumps within 28..52
        for on, dur, offset in variants[self.family['bass'] % len(variants)]:
            self.add(bar, on, dur, 'bass', root + offset, 84 + 4 * (section.energy - 2))

    def drum_bar(self, bar: int, section: Section, fill: bool, crash: bool):
        plan, fam, d = self.plan, self.family, self.density(section)
        if plan.density == 1 and section.role in ('intro', 'outro'):
            return
        hits: List[Tuple[int, int]] = []  # (onset, pitch)
        groove = plan.groove
        if groove == 'swing':
            hits += [(0, KICK), (32, KICK), (12, SNARE), (36, SNARE)]
            hits += [(on, RIDE) for on in (0, 8, 12, 20, 24, 32, 36, 44)]
            body = 24
        elif groove == 'halftime':
            hits += [(0, KICK), (18, KICK), (30, KICK), (24, CLAP)]
            hits += [(i * 6, CHH) for i in range(7)] + [(39, CHH), (42, CHH), (45, CHH)]
            body = 24
        elif groove == 'backbeat' and d == 3:
            hits += [(i * 12, KICK) for i in range(4)] + [(12, CLAP), (36, CLAP)]
            hits += [(i * 6, OHH if i % 2 else CHH) for i in range(8)]
            if fam['kick_push']:
                hits.append((33, KICK))
            body = 24
        elif groove == 'backbeat':
            hits += [(0, KICK), (18, KICK), (24, KICK), (12, SNARE), (36, SNARE)]
            hits += [(i * 6, CHH) for i in range(8)]
            body = 24
        else:  # straight: sparse acoustic kit
            hits += [(0, KICK), (24, KICK), (12, SIDE), (36, SIDE)]
            step = 6 if d >= 2 else 12
            hits += [(on, SHAKER) for on in range(0, BAR, step)]
            body = 24
        if fill:
            step = 4 if groove == 'swing' else 3
            hits = [(on, p) for on, p in hits if on < body] + [(on, SNARE) for on in range(body, BAR, step)]
        if crash:
            hits.append((0, CRASH))
        dur = 4 if groove == 'swing' else 3
        accent = {KICK: 104, SNARE: 98, CLAP: 98, SIDE: 80, CRASH: 100}
        for on, pitch in sorted(set(hits)):
            self.add(bar, on, dur, 'drums', pitch, accent.get(pitch, 72 if on % 12 == 0 else 60) + 4 * (section.energy - 2),
                     unpitched=True)

    def build(self) -> Composition:
        plan = self.plan
        sections = plan.sections
        for index, section in enumerate(sections):
            self.vocal_section(section)
            next_role = sections[index + 1].role if index + 1 < len(sections) else None
            for k in range(section.bars):
                bar = section.start_bar + k
                last = k == section.bars - 1
                self.piano_bar(bar, section)
                self.bass_bar(bar, section)
                fill = last and next_role == 'chorus' and self.family['fill']
                crash = k == 0 and section.role == 'chorus'
                self.drum_bar(bar, section, fill, crash)
        events = tuple(sorted(self.events, key=lambda e: (e.bar, e.onset, e.part, e.pitch if e.pitch is not None else -1)))
        meta = {'synthetic': True, 'project_original': True, 'real_genre_training': False,
                'production_ready': False, 'generator': GENERATOR, 'template_id': self.template_id,
                'template_family': 'tf%04d' % self.template_id, 'family_signature': self.family['signature'],
                'key_tonic': self.tonic, 'grid': '1/12 quarter',
                'notes': 'rule-based original procedural arrangement; lyrics are original project text; '
                         'genre is a control preset, not a learned or verified genre label'}
        return Composition(plan, events, meta)


def make_composition(plan: SongPlan, template_id: int = 0) -> Composition:
    """Deterministically arrange ``plan`` into five exact-time parts using template family ``template_id``."""
    from .lyrics import with_phrase_lyrics
    return with_phrase_lyrics(_Arranger(plan, template_id).build())
