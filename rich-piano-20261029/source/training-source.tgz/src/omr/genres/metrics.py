"""Descriptive, automatically computable metrics for genre compositions (no musical-quality claim)."""
from __future__ import annotations

from collections import Counter, defaultdict
from fractions import Fraction
from statistics import mean
from typing import Dict, List

from omr.genres.contracts import PARTS, Composition
from omr.genres.synthetic import MAJOR, infer_tonic

GRID = Fraction(1, 12)
PROVENANCE_KEYS = ('synthetic', 'project_original', 'real_genre_training', 'production_ready', 'generator',
                   'template_id', 'template_family', 'family_signature')


def _vocal_bar(composition: Composition, bar: int) -> List[tuple]:
    return sorted((e.onset, e.duration, e.pitch, e.lyric) for e in composition.events
                  if e.part == 'vocal' and e.bar == bar)


def _chorus_repeat_ratio(composition: Composition):
    """Share of later-chorus vocal bars identical (rhythm, pitch, lyric) to the first chorus bar at that offset."""
    choruses = [s for s in composition.plan.sections if s.role == 'chorus']
    if len(choruses) < 2:
        return None
    first = choruses[0]
    matches = compared = 0
    for section in choruses[1:]:
        for k in range(min(first.bars, section.bars)):
            compared += 1
            matches += _vocal_bar(composition, first.start_bar + k) == _vocal_bar(composition, section.start_bar + k)
    return matches / compared if compared else None


def composition_metrics(composition: Composition) -> Dict:
    plan, events = composition.plan, composition.events
    per_bar: Dict[str, Counter] = defaultdict(Counter)
    simultaneous: Dict[str, Counter] = defaultdict(Counter)
    for e in events:
        per_bar[e.part][e.bar] += 1
        simultaneous[e.part][(e.bar, e.onset)] += 1
    events_per_bar = {}
    for part in PARTS:
        counts = list(per_bar[part].values())
        events_per_bar[part] = {'active_bars': len(counts), 'min': min(counts, default=0),
                                'max': max(counts, default=0), 'mean': round(mean(counts), 3) if counts else 0.0}
    offbeat, ranges = {}, {}
    for part in PARTS:
        part_events = [e for e in events if e.part == part]
        offbeat[part] = (round(sum(e.onset.denominator != 1 for e in part_events) / len(part_events), 3)
                         if part_events else 0.0)
        pitches = [e.pitch for e in part_events if e.pitch is not None and not e.unpitched]
        ranges[part] = [min(pitches), max(pitches)] if pitches else None
    tonic = infer_tonic(plan.chords)
    tonal = [e for e in events if e.part != 'drums' and e.pitch is not None and not e.unpitched]
    in_key = sum((e.pitch - tonic) % 12 in MAJOR for e in tonal)
    vocal = [e for e in events if e.part == 'vocal']
    strong = [e for e in vocal if e.pitch is not None and e.onset in (0, 2)]
    chord_tone = sum(e.pitch % 12 in {p % 12 for p in plan.chords[e.bar].pitches()} for e in strong)
    rhythms = {tuple((e.onset, e.duration) for e in sorted(vocal, key=lambda v: v.onset) if e.bar == bar)
               for bar in per_bar['vocal']}
    return {
        'genre': plan.genre, 'mood': plan.mood, 'bpm': plan.bpm, 'bars': plan.bars,
        'seconds': plan.bars * 4 * 60 / plan.bpm,
        'groove': plan.groove, 'texture': plan.texture, 'density': plan.density,
        'sections': [[s.role, s.bars, s.vocal_mode] for s in plan.sections],
        'event_count': {part: sum(per_bar[part].values()) for part in PARTS},
        'events_per_bar': events_per_bar,
        'max_simultaneous': {part: max(simultaneous[part].values(), default=0) for part in PARTS},
        'offbeat_ratio': offbeat,
        'pitch_range': ranges,
        'off_grid_events': sum((e.onset / GRID).denominator != 1 or (e.duration / GRID).denominator != 1
                               for e in events),
        'lyric_coverage': round(sum(bool(e.lyric) for e in vocal) / len(vocal), 4) if vocal else 0.0,
        'unpitched_vocal_ratio': round(sum(e.unpitched for e in vocal) / len(vocal), 4) if vocal else 0.0,
        'in_key_ratio': round(in_key / len(tonal), 4) if tonal else 0.0,
        'vocal_strong_beat_chord_tone_ratio': round(chord_tone / len(strong), 4) if strong else None,
        'distinct_vocal_bar_rhythms': len(rhythms),
        'chorus_repeat_ratio': _chorus_repeat_ratio(composition),
        'provenance': {k: composition.metadata[k] for k in PROVENANCE_KEYS if k in composition.metadata},
    }
