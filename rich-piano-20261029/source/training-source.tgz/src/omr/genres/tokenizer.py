"""Versioned bar/part scopes and finite exact-time generation constraints."""
from __future__ import annotations

from fractions import Fraction
from typing import List, Tuple

from .contracts import Composition, PARTS, SECTION_ROLES, ScoreEvent, SongPlan

FORMAT = 'omr-genre-bar-v1'
TICKS = 12  # exact quarters, eighths, sixteenths and triplets; unsupported rationals fail
DURATIONS = (3, 4, 6, 8, 9, 12, 15, 16, 18, 24, 30, 36, 48)


class GenreTokenizer:
    prefix_length = 14

    def __init__(self):
        self.tokens = ['PAD', 'BOS', 'EOS', FORMAT, 'END_PART', 'X', 'REST']
        groups = [
            [f'PART_{p}' for p in PARTS], [f'BPM_{i}' for i in range(40, 201)],
            [f'SECTION_{s}' for s in SECTION_ROLES], [f'ENERGY_{i}' for i in (1, 2, 3)],
            [f'MODE_{s}' for s in ('sung', 'rap', 'spoken')],
            [f'ROOT_{i}' for i in range(12)], ['QUALITY_major', 'QUALITY_minor'],
            [f'GROOVE_{s}' for s in ('straight', 'backbeat', 'halftime', 'swing')],
            [f'TEXTURE_{s}' for s in ('block', 'arpeggio', 'syncopated', 'sparse')],
            [f'DENSITY_{i}' for i in (1, 2, 3)], [f'PHASE_{i}' for i in range(4)],
            [f'SYLLABLES_{i}' for i in range(25)], ['LAST_none'] + [f'LAST_{i}' for i in range(128)],
            [f'POS_{i}' for i in range(48)], [f'DUR_{i}' for i in range(1, 49)],
            [f'P_{i}' for i in range(128)], [f'V_{i}' for i in range(1, 128)],
        ]
        for group in groups:
            self.tokens.extend(group)
        self.ids = {token: index for index, token in enumerate(self.tokens)}
        self.pad_id = 0

    @property
    def vocab_size(self):
        return len(self.tokens)

    def prefix(self, plan: SongPlan, bar: int, syllables: int, previous_pitch=None) -> List[int]:
        if not 0 <= syllables <= 24:
            raise ValueError('syllable count outside codec maximum')
        section, chord = plan.section_at(bar), plan.chords[bar]
        tokens = ['BOS', FORMAT, f'BPM_{plan.bpm}', f'SECTION_{section.role}', f'ENERGY_{section.energy}',
                  f'MODE_{section.vocal_mode}', f'ROOT_{chord.root}', f'QUALITY_{chord.quality}',
                  f'GROOVE_{plan.groove}', f'TEXTURE_{plan.texture}', f'DENSITY_{plan.density}',
                  f'PHASE_{(bar-section.start_bar)%4}', f'SYLLABLES_{syllables}',
                  f'LAST_{previous_pitch if previous_pitch is not None else "none"}']
        return [self.ids[token] for token in tokens]

    @staticmethod
    def ticks(value: Fraction) -> int:
        ticks = Fraction(value) * TICKS
        if ticks.denominator != 1:
            raise ValueError('time cannot be represented on exact 1/12-quarter grid')
        return int(ticks)

    def encode_bar(self, composition: Composition, bar: int) -> Tuple[List[int], List[bool]]:
        notes = [e for e in composition.events if e.bar == bar]
        syllables = sum(e.part == 'vocal' and (e.pitch is not None or e.unpitched) for e in notes)
        previous = [e for e in composition.events if e.bar < bar and e.part == 'vocal' and e.pitch is not None]
        previous_pitch = max(previous, key=lambda e: (e.bar, e.onset)).pitch if previous else None
        ids = self.prefix(composition.plan, bar, syllables, previous_pitch)
        for part in composition.plan.parts:
            ids.append(self.ids[f'PART_{part}'])
            for event in sorted((e for e in notes if e.part == part), key=lambda e: (e.onset, e.pitch if e.pitch is not None else -1)):
                onset, duration = self.ticks(event.onset), self.ticks(event.duration)
                pitch = 'X' if event.unpitched and event.pitch is None else 'REST' if event.pitch is None else f'P_{event.pitch}'
                ids.extend(self.ids[t] for t in (f'POS_{onset}', f'DUR_{duration}', pitch, f'V_{event.velocity}'))
            ids.append(self.ids['END_PART'])
        ids.append(self.ids['EOS'])
        return ids, [False] * self.prefix_length + [True] * (len(ids) - self.prefix_length)

    def decode_bar(self, token_ids: List[int], plan: SongPlan, bar: int) -> List[ScoreEvent]:
        if not token_ids or token_ids[-1] != self.ids['EOS']:
            raise ValueError('bar is not terminated by EOS')
        try:
            names = [self.tokens[i] for i in token_ids]
            if names[:2] != ['BOS', FORMAT]:
                raise ValueError('bar format mismatch')
            cursor = self.prefix_length
            events = []
            for part in plan.parts:
                if names[cursor] != f'PART_{part}':
                    raise ValueError('missing or out-of-order part')
                cursor += 1
                last_onset = -1
                while names[cursor] != 'END_PART':
                    pos, dur, pitch, velocity = names[cursor:cursor+4]
                    if not pos.startswith('POS_') or not dur.startswith('DUR_') or not velocity.startswith('V_'):
                        raise ValueError('malformed event field order')
                    onset = int(pos[4:])
                    if onset < last_onset:
                        raise ValueError('event onset is not monotonic within part')
                    last_onset = onset
                    if pitch not in ('X', 'REST') and not pitch.startswith('P_'):
                        raise ValueError('malformed pitch token')
                    events.append(ScoreEvent(bar, Fraction(onset, TICKS), Fraction(int(dur[4:]), TICKS), part,
                                             None if pitch in ('X', 'REST') else int(pitch[2:]), int(velocity[2:]),
                                             unpitched=(part == 'drums' or pitch == 'X')))
                    cursor += 4
                cursor += 1
            if names[cursor:] != ['EOS']:
                raise ValueError('unexpected tokens after final part')
            return events
        except (IndexError, TypeError) as exc:
            raise ValueError('truncated or invalid bar sequence') from exc


class BarGrammar:
    """Finite grammar. Validity/ranges come from constraints, music choices from logits."""
    def __init__(self, tokenizer: GenreTokenizer, plan: SongPlan, bar: int, syllables: int):
        if not 0 <= syllables <= 16:
            raise ValueError('generation supports at most16 vocal syllables per bar')
        self.t, self.plan, self.bar, self.syllables = tokenizer, plan, bar, syllables
        self.part_index, self.stage, self.count = 0, 'part', 0
        self.last_onset, self.last_end, self.simultaneous = -1, 0, 0
        self.onset, self.duration, self.done = 0, 0, False
        self.same_pitches, self.current_pitch = [], None

    @property
    def part(self):
        return self.plan.parts[self.part_index]

    def allowed(self) -> List[int]:
        if self.done:
            return []
        ids = self.t.ids
        if self.stage == 'eos':
            return [ids['EOS']]
        if self.stage == 'part':
            return [ids[f'PART_{self.part}']]
        if self.stage == 'pos':
            if self.part == 'drums' and self.plan.density == 1 and self.plan.section_at(self.bar).role in ('intro','outro'):
                return [ids['END_PART']]
            required = self.syllables if self.part == 'vocal' else 1
            values = ['END_PART'] if self.count >= required else []
            if self.count >= (self.syllables if self.part == 'vocal' else 24):
                return [ids[s] for s in values]
            polyphonic = self.part in ('piano_rh', 'piano_lh', 'drums')
            minimum = self.last_end
            if polyphonic and self.simultaneous < 3 and self.last_onset >= 0:
                minimum = self.last_onset
            remaining = self.syllables - self.count if self.part == 'vocal' else 1
            maximum = 48 - 3 * remaining
            for tick in range(maximum + 1):
                if tick < minimum or (tick % 3 and tick % 4):
                    continue
                if polyphonic and tick > self.last_onset and tick < self.last_end:
                    continue
                values.append(f'POS_{tick}')
            return [ids[s] for s in values]
        if self.stage == 'duration':
            remaining = max(0, self.syllables - self.count - 1) if self.part == 'vocal' else 0
            return [ids[f'DUR_{d}'] for d in DURATIONS if d <= 48 - self.onset - 3 * remaining]
        if self.stage == 'pitch':
            if self.part == 'vocal' and self.plan.section_at(self.bar).vocal_mode != 'sung':
                return [ids['X']]
            if self.part == 'drums':
                pitches = (36, 37, 38, 39, 42, 44, 46, 49, 51, 54, 70)
            else:
                lower, upper = {'vocal': (57, 79), 'piano_rh': (60, 84), 'piano_lh': (36, 60), 'bass': (28, 55)}[self.part]
                if self.part == 'vocal':
                    pcs = {p % 12 for c in self.plan.chords for p in c.pitches()}
                else:
                    pcs = {p % 12 for p in self.plan.chords[self.bar].pitches()}
                pitches = [p for p in range(lower, upper+1) if p % 12 in pcs]
            already = self.same_pitches if self.onset == self.last_onset else []
            pitches = [p for p in pitches if p not in already]
            if self.part in ('piano_rh','piano_lh') and already:
                pitches = [p for p in pitches if max(already+[p])-min(already+[p]) <= 12]
            return [ids[f'P_{p}'] for p in pitches]
        if self.stage == 'velocity':
            return [ids[f'V_{v}'] for v in range(40, 113)]
        raise RuntimeError('unknown grammar stage')

    def advance(self, token: int):
        if token not in self.allowed():
            raise ValueError('token violates bar grammar')
        name = self.t.tokens[token]
        if self.stage == 'eos':
            self.done = True
        elif self.stage == 'part':
            self.stage = 'pos'
        elif self.stage == 'pos' and name == 'END_PART':
            self.part_index += 1
            self.stage = 'eos' if self.part_index == len(self.plan.parts) else 'part'
            self.count, self.last_onset, self.last_end, self.simultaneous = 0, -1, 0, 0
            self.same_pitches = []
        elif self.stage == 'pos':
            self.onset, self.stage = int(name[4:]), 'duration'
        elif self.stage == 'duration':
            self.duration, self.stage = int(name[4:]), 'pitch'
        elif self.stage == 'pitch':
            self.current_pitch = int(name[2:]) if name.startswith('P_') else None
            self.stage = 'velocity'
        else:
            self.same_pitches = self.same_pitches + [self.current_pitch] if self.onset == self.last_onset else [self.current_pitch]
            self.simultaneous = self.simultaneous + 1 if self.onset == self.last_onset else 1
            self.last_onset = self.onset
            self.last_end = max(self.last_end, self.onset + self.duration)
            self.count += 1
            self.stage = 'pos'
