"""Create a song plan, baseline or learned score and per-part MIDI artifacts."""
from __future__ import annotations

import argparse
from dataclasses import replace
import json
from pathlib import Path

from .contracts import Composition, GENRES


def write_outputs(composition: Composition, folder: Path, title='Scene Song'):
    from .export import musicxml, write_midi
    from .metrics import composition_metrics
    folder=Path(folder)
    if folder.exists() and any(folder.iterdir()):
        raise FileExistsError(f'output folder must be empty to preserve existing scores: {folder}')
    xml=musicxml(composition,title=title)
    # Reparse the actual payload before publishing any score files.
    from xml.etree import ElementTree as ET
    ET.fromstring(xml)
    folder.mkdir(parents=True,exist_ok=True)
    (folder/'score.musicxml').write_text(xml,encoding='utf-8')
    write_midi(composition,folder/'score.mid')
    for part in composition.plan.parts:
        subset=Composition(replace(composition.plan,parts=(part,)),tuple(e for e in composition.events if e.part==part),composition.metadata)
        write_midi(subset,folder/(part+'.mid'))
    (folder/'composition.json').write_text(json.dumps(composition.to_dict(),ensure_ascii=False,indent=2),encoding='utf-8')
    (folder/'plan.json').write_text(json.dumps(composition.plan.to_dict(),ensure_ascii=False,indent=2),encoding='utf-8')
    metrics=composition_metrics(composition)
    (folder/'metrics.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2),encoding='utf-8')
    lines=[]
    if composition.metadata.get('lyric_lines'):
        previous=None
        for line in composition.metadata['lyric_lines']:
            if line['section_index']!=previous:
                lines.append('['+line['section']+']'); previous=line['section_index']
            lines.append(line['text'])
        (folder/'lyrics.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
        return metrics
    for section in composition.plan.sections:
        lines.append(f'[{section.role}]')
        for bar in range(section.start_bar,section.start_bar+section.bars):
            lyric=''.join(e.lyric or '' for e in sorted(composition.events,key=lambda e:e.onset) if e.bar==bar and e.part=='vocal')
            if lyric:
                lines.append(lyric)
    (folder/'lyrics.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    return metrics


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='command',required=True)
    compose=sub.add_parser('compose',help='generate a complete editable multi-part score')
    compose.add_argument('--description',required=True)
    compose.add_argument('--genre',choices=('auto',)+GENRES,default='auto')
    compose.add_argument('--mood',default='auto')
    compose.add_argument('--bars',type=int,default=32)
    compose.add_argument('--bpm',type=int)
    compose.add_argument('--seed',type=int,default=20261028)
    compose.add_argument('--template-id',type=int,default=0)
    compose.add_argument('--title',default='Scene Song')
    compose.add_argument('--output-dir',type=Path,required=True)
    compose.add_argument('--device',choices=('auto','cpu','cuda'),default='auto')
    modes=compose.add_mutually_exclusive_group(required=True)
    modes.add_argument('--checkpoint',type=Path)
    modes.add_argument('--baseline',action='store_true',help='explicit authored rule baseline; no model claim')
    args=parser.parse_args()
    from .plans import build_plan
    plan=build_plan(args.description,genre=args.genre,mood=args.mood,bars=args.bars,seed=args.seed,bpm=args.bpm)
    if args.baseline:
        from .synthetic import make_composition
        c=make_composition(plan,template_id=args.template_id)
        c=replace(c,metadata={**c.metadata,'generation_mode':'rule_baseline','real_genre_training':False})
    else:
        from .generate import generate_composition
        c=generate_composition(args.checkpoint,plan,seed=args.seed,template_id=args.template_id,device=args.device)
        c=replace(c,metadata={**c.metadata,'generation_mode':'learned_synthetic_control'})
    metrics=write_outputs(c,args.output_dir,args.title)
    print(json.dumps({'output_dir':str(args.output_dir),'genre_preset':plan.genre,'synthetic':True,
                      'real_genre_training':False,'metrics':metrics},ensure_ascii=True))


if __name__=='__main__':
    main()
