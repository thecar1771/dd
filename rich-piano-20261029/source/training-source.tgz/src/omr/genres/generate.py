"""Finite constrained sampling; plans/lyrics and explicit hook reuse stay external."""
from __future__ import annotations

from dataclasses import replace
from pathlib import Path

import torch

from .contracts import Composition
from .tokenizer import BarGrammar
from .train import load_checkpoint


@torch.inference_mode()
def sample_bar(model, tokenizer, plan, bar, syllables, *, previous_pitch=None, seed=0, temperature=0.8, fixed_vocal=None):
    if not 0 < temperature <= 3:
        raise ValueError('temperature must be in (0,3]')
    device=next(model.parameters()).device
    model.eval()
    rng=torch.Generator(device=device).manual_seed(seed)
    sequence=tokenizer.prefix(plan,bar,syllables,previous_pitch)
    grammar=BarGrammar(tokenizer,plan,bar,syllables)
    supplied=[]
    if fixed_vocal is not None:
        if plan.parts[0]!='vocal' or any(e.part!='vocal' for e in fixed_vocal) or len(fixed_vocal)!=syllables:
            raise ValueError('cached hook must match leading vocal part and supplied syllable count')
        encoded,_=tokenizer.encode_bar(Composition(plan,tuple(replace(e,bar=bar) for e in fixed_vocal)),bar)
        body=encoded[tokenizer.prefix_length:]
        supplied=body[:body.index(tokenizer.ids['END_PART'])+1]
    supplied_index=0
    sampled=forced=0
    while not grammar.done:
        if len(sequence) >= model.config.max_sequence_length:
            raise RuntimeError('bar cannot finish within checkpoint context; no partial score returned')
        allowed=grammar.allowed()
        if not allowed:
            raise RuntimeError('bar grammar reached a dead end')
        if supplied_index<len(supplied):
            choice=supplied[supplied_index]; supplied_index+=1
        elif len(allowed)==1:
            choice=allowed[0]; forced+=1
        else:
            inputs=torch.tensor([sequence],dtype=torch.long,device=device)
            logits=model(inputs)[0,-1].float()
            choices=torch.tensor(allowed,device=device)
            probabilities=torch.softmax(logits[choices]/temperature,dim=-1)
            if not torch.isfinite(probabilities).all():
                raise RuntimeError('nonfinite sampling probabilities')
            choice=choices[torch.multinomial(probabilities,1,generator=rng)].item()
            sampled+=1
        grammar.advance(choice); sequence.append(choice)
    events=tokenizer.decode_bar(sequence,plan,bar)
    return events,{'terminated':True,'generated_tokens':len(sequence)-tokenizer.prefix_length,
                   'sampled_choices':sampled,'forced_grammar_tokens':forced,'supplied_hook_tokens':supplied_index}


def generate_composition(checkpoint: Path, plan, *, seed=0, template_id=0, device='auto', temperature=0.8):
    """Generate notes, preserving original prewritten syllables from the plan baseline.

    The bootstrap does NOT learn scene interpretation or lyric meaning. Repeated
    chorus vocal bars are deliberately reused under the supplied motif plan.
    """
    from .synthetic import make_composition
    if device=='auto':
        device='cuda' if torch.cuda.is_available() else 'cpu'
    actual_device=torch.device(device)
    if actual_device.type=='cpu':
        torch.set_num_threads(1)
    model,tokenizer,identity=load_checkpoint(Path(checkpoint),actual_device)
    authored=make_composition(plan,template_id=template_id)
    events=[]; reports=[]; hooks={}; reused=0; previous_pitch=None
    for bar in range(plan.bars):
        source_vocal=sorted((e for e in authored.events if e.bar==bar and e.part=='vocal'),key=lambda e:e.onset)
        source_vocal=[e for e in source_vocal if e.pitch is not None or e.unpitched]
        lyrics=[e.lyric for e in source_vocal]
        if any(not lyric for lyric in lyrics):
            raise ValueError('prewritten vocal syllables required; no truncation fallback')
        section=plan.section_at(bar)
        hook_key=(section.motif,(bar-section.start_bar)%4,plan.chords[bar].root,plan.chords[bar].quality,len(lyrics))
        cached=hooks.get(hook_key) if section.role=='chorus' else None
        fixed=tuple(replace(e,bar=bar) for e in cached) if cached is not None else None
        sampled,report=sample_bar(model,tokenizer,plan,bar,len(lyrics),previous_pitch=previous_pitch,
                                  seed=seed+bar*104729,temperature=temperature,fixed_vocal=fixed)
        vocal=[e for e in sampled if e.part=='vocal' and (e.pitch is not None or e.unpitched)]
        if len(vocal)!=len(lyrics):
            raise RuntimeError('generated vocal slots differ from supplied syllables')
        vocal=[replace(e,lyric=source.lyric,syllabic=source.syllabic) for e,source in zip(vocal,source_vocal)]
        if section.role=='chorus':
            if cached is not None:
                reused+=1
            else:
                hooks[hook_key]=vocal
        events.extend(vocal); events.extend(e for e in sampled if e.part!='vocal')
        if vocal and vocal[-1].pitch is not None:
            previous_pitch=vocal[-1].pitch
        reports.append({'bar':bar,**report})
    metadata={'synthetic':True,'production_ready':False,'real_genre_training':False,
              'note_source':'fresh conditional Transformer with finite bar grammar',
              'plan_source':'explicit rule/scene-keyword plan; not learned here',
              'lyric_source':'project-original procedural lyrics supplied before sampling',
              'hook_source':'explicit motif-plan reuse of previously generated chorus vocal bars',
              'reused_hook_bars':reused,'seed':seed,'checkpoint_identity':identity,
              'generation':reports,'lyric_syllables_preserved':True}
    metadata.update({k:authored.metadata[k] for k in ('lyric_lines','original_line_bank','lyrics_strategy') if k in authored.metadata})
    return Composition(plan,tuple(events),metadata)
