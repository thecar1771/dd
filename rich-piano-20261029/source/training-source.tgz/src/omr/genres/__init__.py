"""Experimental, explicitly synthetic, genre-control music composition."""
