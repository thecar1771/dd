"""Fit complete project-original Korean lines; never slice a word to fill notes."""
from dataclasses import replace

SHORT_LINES = (
    '아', '우리', '걸어가', '함께 가자', '오늘도 함께', '너와 함께 걸어',
    '작은 빛을 따라가', '우리 함께 걸어가자', '오늘의 온기를 기억해',
    '우리의 내일을 노래하자', '너와 나의 발걸음을 맞춰가',
    '햇살 속에서 너와 함께 걸어가', '따뜻한 오늘을 우리 함께 기억해',
)


def _syllable_marks(line):
    values=[]
    for word in line.split():
        if not all('\uac00' <= ch <= '\ud7a3' for ch in word):
            raise ValueError('original line bank must contain Korean words only')
        for i,ch in enumerate(word):
            mark='single' if len(word)==1 else 'begin' if i==0 else 'end' if i==len(word)-1 else 'middle'
            values.append((ch,mark))
    return values


def _complete_lines(count, bank):
    # Fewest whole lines, preferring substantial phrases over one-syllable fillers.
    options=[(line,_syllable_marks(line)) for line in bank]
    best={0:(0,[])}
    for n in range(1,count+1):
        choices=[]
        for index,(line,marks) in enumerate(options):
            k=len(marks)
            if k<=n and n-k in best:
                penalty,lines=best[n-k]
                choices.append((penalty+100+(40 if k==1 else 0)+index/1000,lines+[line]))
        if choices:
            best[n]=min(choices,key=lambda x:x[0])
    if count not in best:
        raise ValueError('no complete original lines fit vocal syllable budget')
    return best[count][1]


def with_phrase_lyrics(composition):
    from .synthetic import LYRICS, HOOKS, RAP, BRIDGE, PRECHORUS
    mood=composition.plan.mood
    mood_lines=LYRICS.get(mood,LYRICS['warm'])
    bank=list(dict.fromkeys(tuple(mood_lines)+tuple(HOOKS.get(mood,HOOKS['warm']))+SHORT_LINES))
    events=list(composition.events); record=[]; hook_cache={}
    for section_index,section in enumerate(composition.plan.sections):
        role_bank=list(RAP if section.role=='rap' else BRIDGE if section.role=='bridge' else PRECHORUS if section.role=='prechorus' else ())
        choices=list(dict.fromkeys(role_bank+bank))
        for start in range(section.start_bar,section.start_bar+section.bars,2):
            end=min(start+2,section.start_bar+section.bars)
            indices=sorted((i for i,e in enumerate(events) if e.part=='vocal' and start<=e.bar<end and (e.pitch is not None or e.unpitched)),
                           key=lambda i:(events[i].bar,events[i].onset))
            if not indices:
                continue
            counts=tuple(sum(events[i].bar==b for i in indices) for b in range(start,end))
            key=(((start-section.start_bar)//2)%2,counts)
            if section.role in ('chorus','outro') and key in hook_cache:
                lines=hook_cache[key]
            else:
                lines=_complete_lines(len(indices),choices)
                if section.role=='chorus':
                    hook_cache[key]=lines
            marks=[item for line in lines for item in _syllable_marks(line)]
            assert len(marks)==len(indices)
            for i,(syllable,mark) in zip(indices,marks):
                events[i]=replace(events[i],lyric=syllable,syllabic=mark)
            cursor=0
            for line in lines:
                n=len(_syllable_marks(line))
                record.append({'section_index':section_index,'section':section.role,'start_bar':start,'end_bar':end,
                               'text':line,'syllables':n,'first_note_in_group':cursor})
                cursor+=n
            bank=list(dict.fromkeys(bank+role_bank))
    return replace(composition,events=tuple(events),metadata={**composition.metadata,'lyric_lines':record,
                    'original_line_bank':bank,'lyrics_strategy':'complete_original_lines_before_sampling'})
