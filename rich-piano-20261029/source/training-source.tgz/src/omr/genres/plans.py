"""Rule-based SongPlan presets for six style controls (supplied plans, not a learned planner)."""
from __future__ import annotations

import random
from typing import List, Optional, Tuple

from omr.genres.contracts import GENRES, Chord, Section, SongPlan

MOODS = ('warm', 'bright', 'sad', 'calm', 'energetic', 'dreamy')

# Ordered keyword rules: the first rule with the most hits wins, so ties are deterministic.
GENRE_KEYWORDS = (
    ('rap', ('랩', '힙합', '래퍼', 'rap', 'hiphop', 'hip-hop', '비트', '라임')),
    ('kpop_dance', ('댄스', '춤', '클럽', '파티', '무대', '축제', 'dance', '신나')),
    ('kpop_acoustic', ('어쿠스틱', '기타', '카페', '통기타', 'acoustic', '소풍')),
    ('ballad', ('발라드', '이별', '눈물', '그리움', '추억', 'ballad', '편지')),
    ('rnb', ('알앤비', 'r&b', 'rnb', '그루브', '새벽', '네온', '소울')),
    ('pop', ('팝', 'pop', '도시', '여행', '햇살')),
)
MOOD_KEYWORDS = (
    ('sad', ('슬픔', '슬픈', '눈물', '이별', '그리움', '외로', '비 오는', '쓸쓸')),
    ('energetic', ('신나', '파티', '달려', '춤', '댄스', '에너지', '축제', '뛰')),
    ('bright', ('밝', '햇살', '여름', '설렘', '웃', '봄', '맑')),
    ('calm', ('잔잔', '조용', '고요', '평온', '새벽', '쉼', '느리')),
    ('dreamy', ('꿈', '별', '밤하늘', '몽환', '달빛', '우주')),
    ('warm', ('따뜻', '온기', '포근', '햇볕', '가족', '친구')),
)

# Style presets. bpm ranges are inclusive; ``cycle`` is a list of 4-bar blocks repeated to fill
# the body, ``break_role`` is the contrasting block placed before the final chorus.
STYLES = {
    'kpop_dance': dict(bpm=(112, 128), groove='backbeat', texture='syncopated', density=3,
                       cycle=('verse', 'prechorus', 'chorus', 'chorus'), break_role='rap',
                       second_cycle_verse='rap', intro=True,
                       progressions=('IV-V-iii-vi', 'vi-IV-I-V', 'I-V-vi-IV'),
                       instruments=dict(vocal='lead_voice', piano_rh='electric_piano', piano_lh='electric_piano',
                                        bass='synth_bass', drums='dance_kit')),
    'kpop_acoustic': dict(bpm=(76, 92), groove='straight', texture='arpeggio', density=1,
                          cycle=('verse', 'verse', 'chorus', 'chorus'), break_role='bridge',
                          second_cycle_verse=None, intro=True,
                          progressions=('I-V-vi-IV', 'I-iii-IV-V', 'IV-V-iii-vi'),
                          instruments=dict(vocal='lead_voice', piano_rh='acoustic_piano',
                                           piano_lh='acoustic_piano', bass='acoustic_bass', drums='brush_kit')),
    'pop': dict(bpm=(96, 116), groove='backbeat', texture='block', density=2,
                cycle=('verse', 'prechorus', 'chorus', 'chorus'), break_role='bridge',
                second_cycle_verse=None, intro=True,
                progressions=('I-V-vi-IV', 'vi-IV-I-V', 'I-vi-IV-V'),
                instruments=dict(vocal='lead_voice', piano_rh='acoustic_piano', piano_lh='acoustic_piano',
                                 bass='electric_bass', drums='pop_kit')),
    'rap': dict(bpm=(84, 98), groove='halftime', texture='sparse', density=2,
                cycle=('rap', 'rap', 'chorus'), break_role='rap',
                second_cycle_verse=None, intro=True,
                progressions=('vi-IV-I-V', 'vi-V-IV-V', 'ii-V-I-vi'),
                instruments=dict(vocal='rap_voice', piano_rh='electric_piano', piano_lh='electric_piano',
                                 bass='synth_bass', drums='hiphop_kit')),
    'ballad': dict(bpm=(64, 78), groove='straight', texture='block', density=1,
                   cycle=('verse', 'verse', 'chorus', 'chorus'), break_role='bridge',
                   second_cycle_verse=None, intro=True,
                   progressions=('I-V-vi-IV', 'I-iii-IV-V', 'vi-IV-I-V'),
                   instruments=dict(vocal='lead_voice', piano_rh='acoustic_piano', piano_lh='acoustic_piano',
                                    bass='acoustic_bass', drums='brush_kit')),
    'rnb': dict(bpm=(70, 90), groove='swing', texture='syncopated', density=2,
                cycle=('verse', 'prechorus', 'chorus', 'chorus'), break_role='bridge',
                second_cycle_verse=None, intro=True,
                progressions=('ii-V-I-vi', 'IV-V-iii-vi', 'vi-ii-V-I'),
                instruments=dict(vocal='lead_voice', piano_rh='electric_piano', piano_lh='electric_piano',
                                 bass='electric_bass', drums='rnb_kit')),
}

DEGREES = {'I': (0, 'major'), 'ii': (2, 'minor'), 'iii': (4, 'minor'), 'IV': (5, 'major'),
           'V': (7, 'major'), 'vi': (9, 'minor')}
SAD_PROGRESSIONS = ('vi-IV-I-V', 'vi-ii-V-I', 'vi-V-IV-V')
ROLE_ENERGY = {'intro': 1, 'verse': 1, 'prechorus': 2, 'chorus': 3, 'rap': 2, 'bridge': 2, 'outro': 1}
ROLE_MOTIF = {'intro': 'i', 'verse': 'a', 'prechorus': 'b', 'chorus': 'hook', 'rap': 'r', 'bridge': 'c',
              'outro': 'o'}
MOOD_BPM = {'energetic': 6, 'bright': 3, 'sad': -6, 'calm': -6, 'dreamy': -3, 'warm': 0}


def _rank_keywords(description: str, rules) -> Tuple[Optional[str], List[str]]:
    text = description.lower()
    best, best_hits = None, []
    for label, words in rules:
        hits = [w for w in words if w in text]
        if len(hits) > len(best_hits):
            best, best_hits = label, hits
    return best, best_hits


def infer_genre(description: str) -> Tuple[str, str]:
    """Keyword heuristic for ``genre='auto'``; returns (genre, human-readable reason)."""
    genre, hits = _rank_keywords(description, GENRE_KEYWORDS)
    if genre is None:
        return 'pop', 'no genre keyword matched; default pop'
    return genre, 'keywords: ' + ', '.join(hits)


def infer_mood(description: str) -> Tuple[str, str]:
    """Keyword heuristic for ``mood='auto'``; returns (mood, human-readable reason)."""
    mood, hits = _rank_keywords(description, MOOD_KEYWORDS)
    if mood is None:
        return 'warm', 'no mood keyword matched; default warm'
    return mood, 'keywords: ' + ', '.join(hits)


def _block_roles(style: dict, blocks: int) -> List[str]:
    """Role per 4-bar block: optional intro/outro frame around repeated cycles and a break."""
    framed = blocks >= 6
    body_blocks = blocks - 2 if framed else blocks
    cycle = list(style['cycle'])
    body: List[str] = []
    while body_blocks - len(body) >= len(cycle):
        current = list(cycle)
        if body and style['second_cycle_verse']:
            current = [style['second_cycle_verse'] if r == 'verse' else r for r in current]
        body += current
    rest = body_blocks - len(body)
    if not body:
        body = cycle[-rest:]
    elif rest == 1:
        body.append('chorus')
    elif rest >= 2:
        body += [style['break_role']] + ['chorus'] * (rest - 1)
    return (['intro'] + body + ['outro']) if framed else body


def _sections(style: dict, bars: int) -> Tuple[Section, ...]:
    blocks = max(1, bars // 4)
    roles = _block_roles(style, blocks)
    merged: List[List] = []
    for role in roles:
        if merged and merged[-1][0] == role:
            merged[-1][1] += 4
        else:
            merged.append([role, 4])
    merged[-1][1] += bars - 4 * blocks
    sections, start = [], 0
    for index, (role, length) in enumerate(merged):
        energy = ROLE_ENERGY[role]
        if role == 'verse' and index > 2:
            energy = 2
        mode = 'rap' if role == 'rap' else 'sung'
        sections.append(Section(role, start, length, energy, mode, ROLE_MOTIF[role]))
        start += length
    return tuple(sections)


def _progression(name: str, tonic: int) -> Tuple[Chord, ...]:
    return tuple(Chord((tonic + DEGREES[d][0]) % 12, DEGREES[d][1]) for d in name.split('-'))


def build_plan(description: str, genre: str = 'auto', mood: str = 'warm', bars: int = 32, seed: int = 0,
               bpm: Optional[int] = None) -> SongPlan:
    """Return a deterministic supplied SongPlan; an explicit genre always overrides keyword inference."""
    if not isinstance(description, str) or not description.strip():
        raise ValueError('description must be a nonempty string')
    if genre == 'auto':
        genre = infer_genre(description)[0]
    if genre not in GENRES:
        raise ValueError('unsupported genre %r; choose auto or one of %s' % (genre, ', '.join(GENRES)))
    if mood == 'auto':
        mood = infer_mood(description)[0]
    if mood not in MOODS:
        raise ValueError('unsupported mood %r; choose auto or one of %s' % (mood, ', '.join(MOODS)))
    if type(bars) is not int or not 4 <= bars <= 128:
        raise ValueError('bars must be an integer in 4..128')
    style = STYLES[genre]
    rng = random.Random('plan|%s|%s|%d' % (genre, mood, seed))
    if bpm is None:
        low, high = style['bpm']
        bpm = max(40, min(200, rng.randint(low, high) + MOOD_BPM[mood]))
    tonic = rng.choice((0, 2, 5, 7, 9, 10, 3))
    pool = style['progressions']
    if mood == 'sad':
        pool = tuple(p for p in pool if p.startswith('vi')) or SAD_PROGRESSIONS
    names = [rng.choice(pool) for _ in range(3)]  # verse-ish, chorus, break
    by_role = {'intro': names[1], 'verse': names[0], 'rap': names[0], 'prechorus': names[2],
               'chorus': names[1], 'bridge': names[2], 'outro': names[1]}
    sections = _sections(style, bars)
    chords = []
    for section in sections:
        loop = _progression(by_role[section.role], tonic)
        chords += [loop[k % len(loop)] for k in range(section.bars)]
    density = style['density'] + (1 if mood == 'energetic' else -1 if mood in ('calm', 'sad') else 0)
    return SongPlan(genre=genre, description=description, mood=mood, language='ko', bpm=bpm, bars=bars,
                    seed=seed, sections=sections, chords=tuple(chords), groove=style['groove'],
                    texture=style['texture'], density=max(1, min(3, density)),
                    instruments=dict(style['instruments']))
