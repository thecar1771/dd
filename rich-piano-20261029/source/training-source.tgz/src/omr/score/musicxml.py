"""Minimal MusicXML 4.0 exporter for canonical OMR song examples."""

from __future__ import annotations

import xml.etree.ElementTree as ET
from fractions import Fraction
from math import lcm

from omr.schema import SongExample


PITCH_NAMES = (
    ("C", 0), ("C", 1), ("D", 0), ("D", 1), ("E", 0), ("F", 0),
    ("F", 1), ("G", 0), ("G", 1), ("A", 0), ("A", 1), ("B", 0),
)

NOTE_TYPES = {
    Fraction(8): "breve",
    Fraction(4): "whole",
    Fraction(2): "half",
    Fraction(1): "quarter",
    Fraction(1, 2): "eighth",
    Fraction(1, 4): "16th",
    Fraction(1, 8): "32nd",
    Fraction(1, 16): "64th",
}
MAX_DIVISIONS = 960


def _quarter_fraction(value: float) -> Fraction:
    fraction = Fraction(str(value)).limit_denominator(MAX_DIVISIONS)
    if abs(float(fraction) - value) > 1e-8:
        raise ValueError("score timing cannot be represented in MusicXML divisions")
    return fraction


def _duration_ticks(value: Fraction, divisions: int) -> int:
    ticks = value * divisions
    if ticks.denominator != 1 or ticks <= 0:
        raise ValueError("score timing cannot be represented in MusicXML divisions")
    return ticks.numerator


def _add_pitch(note_element: ET.Element, midi_pitch: int) -> None:
    pitch = ET.SubElement(note_element, "pitch")
    step, alter = PITCH_NAMES[midi_pitch % 12]
    ET.SubElement(pitch, "step").text = step
    if alter:
        ET.SubElement(pitch, "alter").text = str(alter)
    ET.SubElement(pitch, "octave").text = str(midi_pitch // 12 - 1)


def song_to_musicxml(song: SongExample, title: str = "OMR Song") -> str:
    measure_duration = Fraction(
        song.meter_numerator * 4, song.meter_denominator
    )
    divisions = measure_duration.denominator
    timed_notes = []
    previous_end = Fraction(0)
    for event in song.notes:
        start = _quarter_fraction(event.start)
        duration = _quarter_fraction(event.duration)
        if start < previous_end:
            raise ValueError("MusicXML exporter supports only non-overlapping notes")
        measure_index = int(start // measure_duration)
        position = start - measure_index * measure_duration
        if position + duration > measure_duration:
            raise ValueError("note crosses a measure boundary without an explicit tie")
        divisions = lcm(divisions, start.denominator, duration.denominator)
        if divisions > MAX_DIVISIONS:
            raise ValueError("score timing requires too many MusicXML divisions")
        timed_notes.append((measure_index + 1, start, duration, event))
        previous_end = start + duration

    root = ET.Element("score-partwise", version="4.0")
    work = ET.SubElement(root, "work")
    ET.SubElement(work, "work-title").text = title
    part_list = ET.SubElement(root, "part-list")
    score_part = ET.SubElement(part_list, "score-part", id="P1")
    ET.SubElement(score_part, "part-name").text = "Voice"
    part = ET.SubElement(root, "part", id="P1")

    notes_by_measure = {}
    for measure_number, start, duration, event in timed_notes:
        notes_by_measure.setdefault(measure_number, []).append((start, duration, event))
    measure_count = max(notes_by_measure, default=1)
    for measure_number in range(1, measure_count + 1):
        measure = ET.SubElement(part, "measure", number=str(measure_number))
        if measure_number == 1:
            attributes = ET.SubElement(measure, "attributes")
            ET.SubElement(attributes, "divisions").text = str(divisions)
            key = ET.SubElement(attributes, "key")
            ET.SubElement(key, "fifths").text = "0"
            ET.SubElement(key, "mode").text = song.mode
            time = ET.SubElement(attributes, "time")
            ET.SubElement(time, "beats").text = str(song.meter_numerator)
            ET.SubElement(time, "beat-type").text = str(song.meter_denominator)
            clef = ET.SubElement(attributes, "clef")
            ET.SubElement(clef, "sign").text = "G"
            ET.SubElement(clef, "line").text = "2"
            direction = ET.SubElement(measure, "direction", placement="above")
            direction_type = ET.SubElement(direction, "direction-type")
            metronome = ET.SubElement(direction_type, "metronome")
            ET.SubElement(metronome, "beat-unit").text = "quarter"
            ET.SubElement(metronome, "per-minute").text = str(song.tempo_bpm)
            ET.SubElement(direction, "sound", tempo=str(song.tempo_bpm))
        measure_start = (measure_number - 1) * measure_duration
        current = measure_start
        for start, duration, event in notes_by_measure.get(measure_number, []):
            if start > current:
                forward = ET.SubElement(measure, "forward")
                ET.SubElement(forward, "duration").text = str(
                    _duration_ticks(start - current, divisions)
                )
            note = ET.SubElement(measure, "note")
            if event.pitch is None:
                ET.SubElement(note, "rest")
            else:
                _add_pitch(note, event.pitch)
            ET.SubElement(note, "duration").text = str(
                _duration_ticks(duration, divisions)
            )
            ET.SubElement(note, "voice").text = "1"
            note_type = NOTE_TYPES.get(duration)
            if note_type is not None:
                ET.SubElement(note, "type").text = note_type
            if event.syllable_index is not None:
                lyric = ET.SubElement(note, "lyric", number="1")
                ET.SubElement(lyric, "syllabic").text = "single"
                ET.SubElement(lyric, "text").text = song.lyrics[event.syllable_index].surface
            current = start + duration

    ET.indent(root, space="  ")
    return ET.tostring(root, encoding="unicode", xml_declaration=True)
