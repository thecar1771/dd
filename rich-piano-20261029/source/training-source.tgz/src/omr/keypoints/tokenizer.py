"""UTF-8 byte tokenizer with an atomic scene-keyword mask token."""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Sequence

import torch
from torch import Tensor


@dataclass(frozen=True)
class EncodedBatch:
    input_ids: Tensor
    attention_mask: Tensor


class ByteSceneTokenizer:
    pad_id = 0
    bos_id = 1
    mask_id = 2
    byte_offset = 3
    vocab_size = 259

    def __init__(self, max_length: int = 128):
        if max_length < 2:
            raise ValueError("max_length must be at least 2")
        self.max_length = max_length

    def encode(self, text: str) -> List[int]:
        tokens = [self.bos_id]
        pieces = text.split("<mask>")
        for index, piece in enumerate(pieces):
            tokens.extend(self.byte_offset + value for value in piece.encode("utf-8"))
            if index < len(pieces) - 1:
                tokens.append(self.mask_id)
        if len(tokens) > self.max_length:
            raise ValueError("encoded scene exceeds max_length")
        return tokens

    def decode(self, tokens: Sequence[int]) -> str:
        result: List[str] = []
        buffer = bytearray()

        def flush() -> None:
            if buffer:
                result.append(buffer.decode("utf-8"))
                buffer.clear()

        for token in tokens:
            if token in {self.pad_id, self.bos_id}:
                continue
            if token == self.mask_id:
                flush()
                result.append("<mask>")
            elif self.byte_offset <= token < self.vocab_size:
                buffer.append(token - self.byte_offset)
            else:
                raise ValueError(f"unknown token id: {token}")
        flush()
        return "".join(result)

    def batch_encode(self, texts: Sequence[str], device: torch.device | None = None) -> EncodedBatch:
        if not texts:
            raise ValueError("text batch is empty")
        sequences = [self.encode(text) for text in texts]
        width = max(len(sequence) for sequence in sequences)
        input_ids = torch.full((len(sequences), width), self.pad_id, dtype=torch.long, device=device)
        attention_mask = torch.zeros((len(sequences), width), dtype=torch.bool, device=device)
        for row, sequence in enumerate(sequences):
            input_ids[row, :len(sequence)] = torch.tensor(sequence, dtype=torch.long, device=device)
            attention_mask[row, :len(sequence)] = True
        return EncodedBatch(input_ids=input_ids, attention_mask=attention_mask)
