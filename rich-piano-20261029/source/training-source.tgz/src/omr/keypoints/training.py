"""Train and safely reload the masked scene keypoint model."""

from __future__ import annotations

import argparse
import json
import math
import random
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, List

import torch
from torch import nn
from torch.nn import functional as F

try:
    import tomllib
except ModuleNotFoundError:
    import tomli as tomllib

from omr.keypoints.data import CONCEPTS, EMOTIONS, generate_scene_records, mask_scene_record
from omr.keypoints.model import SceneKeypointConfig, SceneKeypointModel
from omr.keypoints.tokenizer import ByteSceneTokenizer


@dataclass(frozen=True)
class KeypointTrainingResult:
    final_losses: Dict[str, float]
    initial_total_loss: float
    sample_count: int
    seen_sample_count: int
    steps: int
    device: str
    checkpoint_path: Path
    runtime_seconds: float
    seed: int

    def json_dict(self) -> Dict[str, Any]:
        payload = asdict(self)
        payload["checkpoint_path"] = str(self.checkpoint_path)
        return payload


@dataclass(frozen=True)
class LoadedKeypointCheckpoint:
    model: SceneKeypointModel
    tokenizer: ByteSceneTokenizer
    metadata: Dict[str, Any]


def _read_config(path: Path) -> Dict[str, Any]:
    with path.open("rb") as handle:
        payload = tomllib.load(handle)
    if "training" not in payload or "model" not in payload:
        raise ValueError("config requires [training] and [model] sections")
    return payload


def _resolve_path(config_path: Path, value: str) -> Path:
    path = Path(value)
    return path.resolve() if path.is_absolute() else (config_path.parent / path).resolve()


def _select_device(requested: str) -> torch.device:
    if requested == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if requested == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was required but is unavailable")
    if requested not in {"cpu", "cuda"}:
        raise ValueError("device must be one of: auto, cpu, cuda")
    return torch.device(requested)


def _targets(records, pairs, device):
    keyword_targets = torch.zeros((len(records), len(CONCEPTS)), dtype=torch.float32, device=device)
    for row, record in enumerate(records):
        for concept in record.keywords:
            keyword_targets[row, CONCEPTS.index(concept)] = 1.0
    emotion_targets = torch.tensor([EMOTIONS.index(record.primary_emotion) for record in records], dtype=torch.long, device=device)
    masked_targets = torch.tensor([CONCEPTS.index(pair.masked_keyword) for pair in pairs], dtype=torch.long, device=device)
    return keyword_targets, emotion_targets, masked_targets


def train_keypoints(config_path: Path) -> KeypointTrainingResult:
    config_path = config_path.resolve()
    payload = _read_config(config_path)
    training = payload["training"]
    model_values = payload["model"]
    seed = int(training["seed"])
    sample_count = int(training["sample_count"])
    steps = int(training["steps"])
    batch_size = int(training["batch_size"])
    learning_rate = float(training["learning_rate"])
    if min(sample_count, steps, batch_size) <= 0 or learning_rate <= 0:
        raise ValueError("sample_count, steps, batch_size, and learning_rate must be positive")
    random.seed(seed)
    torch.manual_seed(seed)
    device = _select_device(str(training.get("device", "auto")))
    if device.type == "cuda":
        torch.cuda.manual_seed_all(seed)
    else:
        torch.set_num_threads(int(training.get("cpu_threads", 1)))

    max_length = int(model_values["max_length"])
    tokenizer = ByteSceneTokenizer(max_length=max_length)
    config = SceneKeypointConfig(
        vocab_size=tokenizer.vocab_size, max_length=max_length,
        d_model=int(model_values["d_model"]), nhead=int(model_values["nhead"]),
        num_layers=int(model_values["num_layers"]), dim_feedforward=int(model_values["dim_feedforward"]),
        dropout=float(model_values["dropout"]), keyword_count=len(CONCEPTS), emotion_count=len(EMOTIONS),
    )
    model = SceneKeypointModel(config).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate)
    records = generate_scene_records(sample_count, seed)
    pairs = [mask_scene_record(record, seed + index) for index, record in enumerate(records)]
    consistency_weight = float(model_values.get("consistency_weight", 0.25))
    history: Dict[str, List[float]] = {name: [] for name in ("total", "keywords", "emotion", "masked", "consistency")}
    seen_indices = set()
    started = time.perf_counter()
    model.train()
    for step in range(steps):
        indices = [(step * batch_size + offset) % sample_count for offset in range(batch_size)]
        seen_indices.update(indices)
        batch_records = [records[index] for index in indices]
        batch_pairs = [pairs[index] for index in indices]
        original = tokenizer.batch_encode([record.description for record in batch_records], device)
        masked = tokenizer.batch_encode([pair.masked_description for pair in batch_pairs], device)
        keyword_targets, emotion_targets, masked_targets = _targets(batch_records, batch_pairs, device)
        optimizer.zero_grad(set_to_none=True)
        original_output = model(original.input_ids, original.attention_mask)
        masked_output = model(masked.input_ids, masked.attention_mask)
        losses = {
            "keywords": F.binary_cross_entropy_with_logits(original_output.keyword_logits, keyword_targets),
            "emotion": F.cross_entropy(original_output.emotion_logits, emotion_targets),
            "masked": F.cross_entropy(masked_output.masked_keyword_logits, masked_targets),
            "consistency": (1.0 - F.cosine_similarity(original_output.embedding, masked_output.embedding, dim=1)).mean(),
        }
        total = losses["keywords"] + losses["emotion"] + losses["masked"] + consistency_weight * losses["consistency"]
        losses["total"] = total
        values = {name: float(loss.detach().cpu()) for name, loss in losses.items()}
        if not all(math.isfinite(value) for value in values.values()):
            raise RuntimeError("training loss is not finite")
        for name, value in values.items():
            history[name].append(value)
        total.backward()
        optimizer.step()

    output_dir = _resolve_path(config_path, str(training["output_dir"]))
    output_dir.mkdir(parents=True, exist_ok=True)
    checkpoint_path = output_dir / "keypoint-mask.pt"
    torch.save({
        "format": "omr-keypoint-v1", "model_config": asdict(config),
        "model_state": model.state_dict(), "optimizer_state": optimizer.state_dict(),
        "concepts": list(CONCEPTS), "emotions": list(EMOTIONS),
        "tokenizer": {"format": "utf8-byte-v1", "max_length": max_length},
        "sample_count": sample_count, "seen_sample_count": len(seen_indices),
        "seed": seed, "steps": steps, "losses": history,
    }, checkpoint_path)
    return KeypointTrainingResult(
        final_losses={name: values[-1] for name, values in history.items()},
        initial_total_loss=history["total"][0], sample_count=sample_count,
        seen_sample_count=len(seen_indices), steps=steps, device=device.type,
        checkpoint_path=checkpoint_path, runtime_seconds=time.perf_counter() - started, seed=seed,
    )


def load_keypoint_checkpoint(path: Path, device: torch.device) -> LoadedKeypointCheckpoint:
    payload = torch.load(path, map_location=device, weights_only=True)
    if payload.get("format") != "omr-keypoint-v1":
        raise ValueError("unsupported keypoint checkpoint format")
    if payload.get("concepts") != list(CONCEPTS) or payload.get("emotions") != list(EMOTIONS):
        raise ValueError("checkpoint ontology does not match runtime ontology")
    tokenizer_metadata = payload.get("tokenizer")
    model_config = payload.get("model_config")
    if not isinstance(tokenizer_metadata, dict) or not isinstance(model_config, dict):
        raise ValueError("checkpoint tokenizer metadata is missing")
    if tokenizer_metadata.get("format") != "utf8-byte-v1":
        raise ValueError("checkpoint tokenizer metadata has an unsupported format")
    try:
        config = SceneKeypointConfig(**model_config)
        tokenizer_max_length = int(tokenizer_metadata["max_length"])
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError("checkpoint tokenizer metadata is malformed") from exc
    expected_tokenizer_values = {
        "vocab_size": ByteSceneTokenizer.vocab_size,
        "pad_id": ByteSceneTokenizer.pad_id,
        "mask_id": ByteSceneTokenizer.mask_id,
        "max_length": tokenizer_max_length,
        "keyword_count": len(CONCEPTS),
        "emotion_count": len(EMOTIONS),
    }
    actual_model_values = {
        "vocab_size": config.vocab_size,
        "pad_id": config.pad_id,
        "mask_id": config.mask_id,
        "max_length": config.max_length,
        "keyword_count": config.keyword_count,
        "emotion_count": config.emotion_count,
    }
    if actual_model_values != expected_tokenizer_values:
        raise ValueError("checkpoint tokenizer metadata does not match the model")
    model = SceneKeypointModel(config).to(device)
    model.load_state_dict(payload["model_state"])
    model.eval()
    tokenizer = ByteSceneTokenizer(max_length=tokenizer_max_length)
    return LoadedKeypointCheckpoint(model=model, tokenizer=tokenizer, metadata=payload)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("config", type=Path)
    args = parser.parse_args()
    print("KEYPOINT_TRAINING_RESULT_JSON=" + json.dumps(train_keypoints(args.config).json_dict(), sort_keys=True))


if __name__ == "__main__":
    main()
