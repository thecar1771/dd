"""Compact Transformer for scene concepts, emotion, and masked recovery."""

from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import Tensor, nn


@dataclass(frozen=True)
class SceneKeypointConfig:
    vocab_size: int
    max_length: int
    d_model: int
    nhead: int
    num_layers: int
    dim_feedforward: int
    dropout: float
    keyword_count: int
    emotion_count: int
    pad_id: int = 0
    mask_id: int = 2


@dataclass(frozen=True)
class SceneKeypointOutput:
    embedding: Tensor
    keyword_logits: Tensor
    emotion_logits: Tensor
    masked_keyword_logits: Tensor


class SceneKeypointModel(nn.Module):
    def __init__(self, config: SceneKeypointConfig):
        super().__init__()
        self.config = config
        self.token_embedding = nn.Embedding(config.vocab_size, config.d_model, padding_idx=config.pad_id)
        self.position_embedding = nn.Embedding(config.max_length, config.d_model)
        layer = nn.TransformerEncoderLayer(
            d_model=config.d_model, nhead=config.nhead,
            dim_feedforward=config.dim_feedforward, dropout=config.dropout,
            activation="gelu", batch_first=True, norm_first=False,
        )
        self.encoder = nn.TransformerEncoder(
            layer, num_layers=config.num_layers, enable_nested_tensor=False
        )
        self.normalization = nn.LayerNorm(config.d_model)
        self.keyword_head = nn.Linear(config.d_model, config.keyword_count)
        self.emotion_head = nn.Linear(config.d_model, config.emotion_count)
        self.masked_keyword_head = nn.Linear(config.d_model, config.keyword_count)

    def forward(self, input_ids: Tensor, attention_mask: Tensor) -> SceneKeypointOutput:
        if input_ids.ndim != 2 or attention_mask.shape != input_ids.shape:
            raise ValueError("input_ids and attention_mask must have matching rank-2 shapes")
        if input_ids.shape[1] > self.config.max_length:
            raise ValueError("input exceeds configured maximum length")
        positions = torch.arange(input_ids.shape[1], device=input_ids.device).unsqueeze(0)
        hidden = self.token_embedding(input_ids) + self.position_embedding(positions)
        hidden = self.encoder(hidden, src_key_padding_mask=~attention_mask)
        hidden = self.normalization(hidden)
        embedding = hidden[:, 0]
        mask_matches = input_ids.eq(self.config.mask_id)
        mask_positions = mask_matches.to(torch.int64).argmax(dim=1)
        rows = torch.arange(input_ids.shape[0], device=input_ids.device)
        mask_embedding = hidden[rows, mask_positions]
        mask_embedding = torch.where(mask_matches.any(dim=1, keepdim=True), mask_embedding, embedding)
        return SceneKeypointOutput(
            embedding=embedding,
            keyword_logits=self.keyword_head(embedding),
            emotion_logits=self.emotion_head(embedding),
            masked_keyword_logits=self.masked_keyword_head(mask_embedding),
        )
