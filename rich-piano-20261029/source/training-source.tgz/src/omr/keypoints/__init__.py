"""Scene keypoint extraction components."""
