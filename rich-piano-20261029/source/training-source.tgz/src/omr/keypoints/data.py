"""Deterministic multilingual scene-description corpus and masking."""

from __future__ import annotations

import hashlib
import json
import random
from pathlib import Path
from typing import Dict, List

from pydantic import BaseModel, ConfigDict, Field

LANGUAGES = ("ko", "en", "ja", "es", "fr")
CONCEPTS = ("sunlight", "forest", "person", "tiger", "winter", "ocean", "city", "spring", "night", "mountain")
EMOTIONS = ("warm_serenity", "majesty", "cold_solitude", "wonder", "energy")
SURFACES: Dict[str, Dict[str, str]] = {
    "ko": {"sunlight": "햇빛", "forest": "숲", "person": "사람", "tiger": "호랑이", "winter": "겨울", "ocean": "바다", "city": "도시", "spring": "봄", "night": "밤", "mountain": "산"},
    "en": {"sunlight": "sunlight", "forest": "forest", "person": "person", "tiger": "tiger", "winter": "winter", "ocean": "ocean", "city": "city", "spring": "spring", "night": "night", "mountain": "mountain"},
    "ja": {"sunlight": "日光", "forest": "森", "person": "人", "tiger": "虎", "winter": "冬", "ocean": "海", "city": "都市", "spring": "春", "night": "夜", "mountain": "山"},
    "es": {"sunlight": "luz solar", "forest": "bosque", "person": "persona", "tiger": "tigre", "winter": "invierno", "ocean": "océano", "city": "ciudad", "spring": "primavera", "night": "noche", "mountain": "montaña"},
    "fr": {"sunlight": "lumière", "forest": "forêt", "person": "personne", "tiger": "tigre", "winter": "hiver", "ocean": "océan", "city": "ville", "spring": "printemps", "night": "nuit", "mountain": "montagne"},
}
TEMPLATES = {
    "ko": "장면에는 {a}, {b}, 그리고 {c}의 기운이 서로 이어진다.",
    "en": "The scene connects the feeling of {a}, {b}, and {c}.",
    "ja": "この情景では{a}、{b}、そして{c}の気配がつながる。",
    "es": "La escena une la sensación de {a}, {b} y {c}.",
    "fr": "La scène relie la sensation de {a}, de {b} et de {c}.",
}


class _StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class SceneProvenance(_StrictModel):
    generator: str = "omr-scene-template-v1"
    content_license: str = "CC0-1.0"
    created_at: str = "2026-10-23"


class SceneRecord(_StrictModel):
    scene_id: str = Field(min_length=1)
    language: str
    description: str = Field(min_length=1)
    keywords: List[str] = Field(min_length=1)
    keyword_surfaces: Dict[str, str]
    primary_emotion: str
    provenance: SceneProvenance = Field(default_factory=SceneProvenance)


class MaskedScenePair(_StrictModel):
    scene_id: str
    original_description: str
    masked_description: str
    masked_keyword: str
    masked_keyword_surface: str


def _emotion_for(concepts: List[str]) -> str:
    if "tiger" in concepts or "mountain" in concepts:
        return "majesty"
    if "winter" in concepts or "night" in concepts:
        return "cold_solitude"
    if "sunlight" in concepts and ("forest" in concepts or "person" in concepts):
        return "warm_serenity"
    if "city" in concepts:
        return "energy"
    return "wonder"


def generate_scene_records(count: int, seed: int) -> List[SceneRecord]:
    if count <= 0:
        raise ValueError("count must be positive")
    rng = random.Random(seed)
    records: List[SceneRecord] = []
    for index in range(count):
        language = LANGUAGES[index % len(LANGUAGES)]
        concepts = rng.sample(list(CONCEPTS), 3)
        surfaces = {concept: SURFACES[language][concept] for concept in concepts}
        description = TEMPLATES[language].format(a=surfaces[concepts[0]], b=surfaces[concepts[1]], c=surfaces[concepts[2]])
        records.append(SceneRecord(
            scene_id=f"synthetic-{seed:04d}-{index:06d}", language=language,
            description=description, keywords=concepts, keyword_surfaces=surfaces,
            primary_emotion=_emotion_for(concepts),
        ))
    return records


def mask_scene_record(record: SceneRecord, seed: int) -> MaskedScenePair:
    rng = random.Random(f"{seed}:{record.scene_id}")
    concept = record.keywords[rng.randrange(len(record.keywords))]
    surface = record.keyword_surfaces[concept]
    if surface not in record.description:
        raise ValueError(f"keyword surface is absent from description: {surface}")
    return MaskedScenePair(
        scene_id=record.scene_id, original_description=record.description,
        masked_description=record.description.replace(surface, "<mask>", 1),
        masked_keyword=concept, masked_keyword_surface=surface,
    )


def write_scene_records(records: List[SceneRecord], output: Path) -> str:
    output.parent.mkdir(parents=True, exist_ok=True)
    payload = "".join(json.dumps(record.model_dump(mode="json"), ensure_ascii=False, sort_keys=True) + "\n" for record in records).encode("utf-8")
    output.write_bytes(payload)
    digest = hashlib.sha256(payload).hexdigest()
    output.with_suffix(output.suffix + ".sha256").write_text(digest + "\n", encoding="utf-8")
    return digest


def load_scene_records(path: Path) -> List[SceneRecord]:
    return [SceneRecord.model_validate_json(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
