"""Optional image-caption adapters."""
