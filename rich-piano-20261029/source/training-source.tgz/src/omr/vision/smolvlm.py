"""Lazy SmolVLM image captioning boundary for the OMR PoC."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Callable, Optional

MODEL_ID = "HuggingFaceTB/SmolVLM-256M-Instruct"
CAPTION_PROMPT = (
    "Describe the visible subjects, setting, light, season, colors, spatial "
    "relationships, and emotional atmosphere. Stay grounded in the image and "
    "write one concise English paragraph for music interpretation."
)


class SmolVLMCaptioner:
    def __init__(self, model_id: str = MODEL_ID, pipeline_factory: Optional[Callable[..., Any]] = None) -> None:
        self.model_id = model_id
        self._pipeline_factory = pipeline_factory
        self._pipeline = None

    def load(self) -> None:
        if self._pipeline is not None:
            return
        factory = self._pipeline_factory
        if factory is None:
            try:
                from transformers import pipeline
            except (ImportError, ModuleNotFoundError) as exc:
                raise RuntimeError("vision dependencies are missing; install the 'vision' extra") from exc
            factory = pipeline
        self._pipeline = factory("image-text-to-text", model=self.model_id, device_map="auto")

    def caption(self, image_path: Path, max_new_tokens: int = 120) -> str:
        image_path = image_path.resolve()
        if not image_path.is_file():
            raise FileNotFoundError(image_path)
        self.load()
        messages = [{
            "role": "user",
            "content": [
                {"type": "image", "image": str(image_path)},
                {"type": "text", "text": CAPTION_PROMPT},
            ],
        }]
        outputs = self._pipeline(text=messages, max_new_tokens=max_new_tokens, return_full_text=False)
        if not outputs or not isinstance(outputs[0].get("generated_text"), str):
            raise RuntimeError("SmolVLM returned no caption text")
        caption = outputs[0]["generated_text"].strip()
        if not caption:
            raise RuntimeError("SmolVLM returned an empty caption")
        return caption
