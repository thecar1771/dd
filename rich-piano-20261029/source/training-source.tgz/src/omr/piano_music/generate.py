"""Joint-piano phrase sampling with explicit readable-playing and form constraints."""
from __future__ import annotations

import argparse
from dataclasses import replace
from fractions import Fraction
import hashlib
import json
from pathlib import Path

import torch

from omr.genres.contracts import Chord, Composition, ScoreEvent
from omr.genres.plans import build_plan
from omr.genres.export import write_midi
from .export import piano_musicxml, read_piano_xml_events


class PianoGrammar:
    """Finite joint-note grammar, not independently generated hand tracks.

    The supplied harmony, eighth-note rhythm grid and small hand spans are
    readability/composition constraints. Musical choices among them use logits.
    """
    def __init__(self, tokenizer, *, root=0, quality='major', max_notes=14, previous_rh=None, upper=79):
        self.t = tokenizer
        self.chord = {(root + interval) % 12 for interval in (0, 3 if quality == 'minor' else 4, 7)}
        self.scale = {0, 2, 4, 5, 7, 9, 11}
        self.max_notes = max_notes
        self.previous_rh = previous_rh
        self.upper = upper
        self.notes = []
        self.encoded = [self.t.ids['BAR'], self.t.ids['LEN_48']]
        self.stage, self.done = 'pos', False
        self.onset = self.duration = 0
        self.pitch = None

    def _pitches(self, onset, duration):
        active = [n for n in self.notes if n[0] <= onset < n[0] + n[1]]
        used = [n[2] for n in self.notes if n[0] == onset]
        lower = max(used) + 1 if used else 36
        left_count = sum(n[2] < 60 for n in self.notes)
        right_count = len(self.notes) - left_count
        remaining = self.max_notes - len(self.notes)
        force_left = (not self.notes or (onset == 42 and not left_count)
                      or (remaining <= 1 and not left_count))
        force_right = (remaining <= max(0, 2 - right_count)
                       or (48 - onset) // 6 <= max(0, 2 - right_count))
        values = []
        for pitch in range(max(36, lower), self.upper + 1):
            right = pitch >= 60
            if force_left and right or force_right and not right:
                continue
            if pitch in [n[2] for n in active]:
                continue
            hand = [n[2] for n in active if (n[2] >= 60) == right]
            if len(hand) >= 2 or hand and max(hand + [pitch]) - min(hand + [pitch]) > 12:
                continue
            if any(abs(pitch - held) % 12 not in (0, 3, 4, 5, 7, 8, 9) for held in hand):
                continue
            if right:
                if pitch % 12 not in (self.chord if onset % 24 == 0 else self.scale):
                    continue
                if self.previous_rh is not None and abs(pitch - self.previous_rh) > 7:
                    continue
            elif pitch % 12 not in self.chord:
                continue
            values.append(pitch)
        return values

    def allowed(self):
        ids = self.t.ids
        if self.done:
            return []
        if self.stage == 'pos':
            left = sum(n[2] < 60 for n in self.notes)
            right = len(self.notes) - left
            complete = len(self.notes) >= 5 and left >= 1 and right >= 2
            values = [ids['END_BAR']] if complete else []
            if len(self.notes) >= self.max_notes:
                return values
            minimum = self.notes[-1][0] if self.notes else 0
            for position in range(minimum, 48, 6):
                if not self.notes and position != 0:
                    continue
                if (48 - position) // 6 < max(1, 5 - len(self.notes), 2 - right):
                    continue
                if self._pitches(position, 6):
                    values.append(ids[f'POS_{position}'])
            return values
        if self.stage == 'duration':
            return [ids[f'DUR_{d}'] for d in (6, 12, 18, 24) if self.onset + d <= 48]
        if self.stage == 'pitch':
            return [ids[f'PITCH_{p}'] for p in self._pitches(self.onset, self.duration)]
        if self.stage == 'velocity':
            return [ids[f'VELOCITY_{i}'] for i in range(5, 11)]
        raise RuntimeError(self.stage)

    def advance(self, token):
        if token not in self.allowed():
            raise ValueError('token outside playable piano grammar')
        name = self.t.tokens[token]
        self.encoded.append(token)
        if name == 'END_BAR':
            self.done = True
        elif self.stage == 'pos':
            self.onset = int(name.split('_')[-1])
            self.stage = 'duration'
        elif self.stage == 'duration':
            self.duration = int(name.split('_')[-1])
            self.stage = 'pitch'
        elif self.stage == 'pitch':
            self.pitch = int(name.split('_')[-1])
            self.stage = 'velocity'
        else:
            velocity = self.t.decode_velocity(int(name.split('_')[-1]))
            self.notes.append([self.onset, self.duration, self.pitch, velocity])
            if self.pitch >= 60:
                self.previous_rh = self.pitch
            self.stage = 'pos'


@torch.inference_mode()
def sample_bar(model, tok, history, *, root, quality, seed, previous_rh=None, upper=79, temperature=.7):
    device = next(model.parameters()).device
    model.eval()
    rng = torch.Generator(device=device).manual_seed(seed)
    grammar = PianoGrammar(tok, root=root, quality=quality, previous_rh=previous_rh, upper=upper)
    prefix = tok.prefix('major', 'romantic')
    history = list(history)
    sampled = 0
    while not grammar.done:
        while len(prefix) + sum(map(len, history)) + len(grammar.encoded) > model.config.max_sequence_length:
            if not history:
                raise RuntimeError('piano bar does not fit model context')
            history.pop(0)
        context = prefix + [token for bar in history for token in bar] + grammar.encoded
        choices = grammar.allowed()
        if not choices:
            raise RuntimeError('playable-piano constraint dead end; no partial score published')
        if len(choices) == 1:
            selected = choices[0]
        else:
            logits = model(torch.tensor([context], dtype=torch.long, device=device))[0, -1].float()
            possible = torch.tensor(choices, device=device)
            probabilities = torch.softmax(logits[possible] / temperature, dim=-1)
            if not torch.isfinite(probabilities).all():
                raise RuntimeError('nonfinite piano probabilities')
            selected = possible[torch.multinomial(probabilities, 1, generator=rng)].item()
            sampled += 1
        grammar.advance(selected)
    bar = tok.decode_bar(grammar.encoded)
    return bar, grammar.encoded, dict(sampled_choices=sampled, prior_bars_in_context=len(history),
                                     previous_rh=grammar.previous_rh, terminated=True)


def compose(checkpoint, *, output, seed=20261028, device='cpu', allow_research=False, title='고요한 하루'):
    from .train import load_checkpoint
    output = Path(output)
    if output.exists() and any(output.iterdir()):
        raise FileExistsError('preserve existing piano piece')
    torch.set_num_threads(1 if device == 'cpu' else 8)
    model, tok, identity = load_checkpoint(Path(checkpoint), device, allow_research=allow_research)
    roots = [0, 5, 0, 7] + [0, 9, 5, 7, 0, 9, 2, 7] + [9, 4, 5, 0, 2, 9, 5, 7] + [0, 9, 5, 7, 0, 9, 2, 7] + [5, 7, 0, 0]
    chords = tuple(Chord(r, 'minor' if r in (2, 4, 9) else 'major') for r in roots)
    plan = build_plan('선율과 양손의 조화를 위한 피아노 독주', genre='ballad', mood='calm', bars=32, bpm=76, seed=seed)
    plan = replace(plan, parts=('piano_rh', 'piano_lh'), chords=chords,
                   instruments={'piano_rh': 'acoustic_piano', 'piano_lh': 'acoustic_piano'})
    bars, history, reports, previous = [], [], [], None
    for index, chord in enumerate(chords):
        if 20 <= index < 28:
            source = index - 16
            bar = dict(bars[source], notes=[list(n) for n in bars[source]['notes']])
            encoded = tok.encode_bar(bar)
            report = dict(source='explicit reprise of generated A phrase', source_bar=source)
        elif index == 31:
            bar = dict(length=48, notes=[[0, 48, p, v] for p, v in [(36, 48), (48, 48), (60, 56), (64, 52), (67, 52)]])
            encoded = tok.encode_bar(bar)
            report = dict(source='authored final tonic cadence; not model-sampled')
        else:
            bar, encoded, report = sample_bar(model, tok, history, root=chord.root, quality=chord.quality,
                                              seed=seed + index * 104729, previous_rh=previous,
                                              upper=81 if 12 <= index < 19 else 79)
            report['source'] = 'joint-piano Transformer logits under explicit harmony/playability constraints'
        bar['meter'] = [4, 4]
        bars.append(bar)
        history.append(encoded)
        melody = [n[2] for n in bar['notes'] if n[2] >= 60]
        if melody:
            previous = melody[-1]
        reports.append(dict(bar=index, **report))
        print(json.dumps({'piano_bar': index + 1, 'notes': len(bar['notes']), 'source': report['source']}), flush=True)
    events = []
    for index, bar in enumerate(bars):
        factor = .82 if index < 4 else 1.02 if 12 <= index < 20 else .74 if index >= 28 else .94
        for onset, duration, pitch, velocity in bar['notes']:
            events.append(ScoreEvent(index, Fraction(onset, 12), Fraction(duration, 12),
                                     'piano_lh' if pitch < 60 else 'piano_rh', pitch,
                                     max(30, min(86, round(velocity * factor)))))
    metadata = dict(title=title, instrument='solo_piano', seed=seed, usage_profile=identity.get('usage_profile'),
                    form_labels={0: 'Intro', 4: 'A', 12: 'B', 20: "A'", 28: 'Coda'},
                    checkpoint_sha256=hashlib.sha256(Path(checkpoint).read_bytes()).hexdigest(),
                    note_source='actual-score joint-piano multi-bar Transformer; no K-pop or vocal model used',
                    form_source='explicit Intro-A-B-A reprise-Coda composition aid, not learned long-form planning',
                    constraints='sampled bars: supplied C-major harmony, eighth-note grid, max two simultaneous notes per hand with consonant dyads, octave hand span, seven-semitone RH step bound; authored final tonic has a three-note RH triad',
                    notation_hand_assignment='pitch below MIDI60 LH, otherwise RH; not learned fingering',
                    velocity_edits='explicit section-dependent dynamics after note sampling',
                    generation=reports, model_identity=identity,
                    limitations='Symbolic metrics do not establish musical listening quality; reprise and cadence are explicitly supplied.')
    c = Composition(plan, tuple(events), metadata)
    xml = piano_musicxml(c, title=title)
    expected = sorted((e.bar, e.onset, e.duration, e.pitch, e.part) for e in c.events)
    if sorted(read_piano_xml_events(xml)) != expected:
        raise RuntimeError('piano grand-staff XML changed event timing')
    output.mkdir(parents=True, exist_ok=True)
    (output / 'score.musicxml').write_text(xml, encoding='utf-8')
    write_midi(c, output / 'score.mid')
    (output / 'composition.json').write_text(json.dumps(c.to_dict(), ensure_ascii=False, indent=2), encoding='utf-8')
    (output / 'provenance.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'output': str(output), 'bars': 32, 'piano_notes': len(events), 'xml_roundtrip': True}))
    return c


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--checkpoint', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    ap.add_argument('--seed', type=int, default=20261028)
    ap.add_argument('--device', default='cpu')
    ap.add_argument('--allow-research-model', action='store_true')
    ap.add_argument('--title', default='고요한 하루')
    args = ap.parse_args()
    compose(args.checkpoint, output=args.output, seed=args.seed, device=args.device,
            allow_research=args.allow_research_model, title=args.title)


if __name__ == '__main__':
    main()
