"""Versioned joint-hand piano events; windows never split or discard a bar.

Masks index the token being predicted, not its predecessor. Prefix and carried
bars have False masks; each source bar and the final EOS are targeted once.
Meter stays in source metadata: LEN describes actual duration, including pickups.
"""
from __future__ import annotations

from numbers import Integral

FORMAT = 'omr-joint-piano-tokens-v1'
MODES = ('major', 'minor', 'unknown')
STYLES = ('classical', 'romantic', 'baroque', 'jazz', 'folk', 'modern', 'unknown')
VELOCITY_BINS = 16


def _integer(value, low, high, label):
    if isinstance(value, bool) or not isinstance(value, Integral) or not low <= value <= high:
        raise ValueError(f'{label} must be an integer in {low}..{high}: {value!r}')
    return int(value)


class PianoTokenizer:
    format = FORMAT
    velocity_bins = VELOCITY_BINS

    def __init__(self):
        self.tokens = ['PAD', 'BOS', 'EOS', 'BAR', 'END_BAR']
        for name, values in [('MODE', MODES), ('STYLE', STYLES),
                             ('LEN', range(1, 193)), ('POS', range(192)),
                             ('DUR', range(1, 193)), ('PITCH', range(21, 109)),
                             ('VELOCITY', range(VELOCITY_BINS))]:
            self.tokens.extend(f'{name}_{value}' for value in values)
        self.ids = {name: i for i, name in enumerate(self.tokens)}
        self.pad_id = self.ids['PAD']

    @staticmethod
    def encode_velocity(velocity):
        return _integer(velocity, 1, 127, 'velocity') // 8

    @staticmethod
    def decode_velocity(bin_index):
        return min(127, _integer(bin_index, 0, 15, 'velocity bin') * 8 + 4)

    def prefix(self, mode='major', style='romantic'):
        if mode not in MODES or style not in STYLES:
            raise ValueError(f'unsupported mode/style: {mode!r}/{style!r}')
        return [self.ids['BOS'], self.ids[f'MODE_{mode}'], self.ids[f'STYLE_{style}']]

    def encode_bar(self, bar):
        if not isinstance(bar, dict):
            raise ValueError('bar must be a dictionary')
        length = _integer(bar.get('length'), 1, 192, 'bar length')
        if 'meter' in bar:
            meter = bar['meter']
            if not isinstance(meter, (list, tuple)) or len(meter) != 2:
                raise ValueError('meter requires numerator and denominator')
            for value in meter:
                _integer(value, 1, 1024, 'meter')
        if not isinstance(bar.get('notes'), (list, tuple)):
            raise ValueError('bar notes must be a list, including for empty bars')
        notes = []
        for note in bar['notes']:
            if not isinstance(note, (list, tuple)) or len(note) != 4:
                raise ValueError('note must be [onset,duration,pitch,velocity]')
            onset = _integer(note[0], 0, length-1, 'onset')
            duration = _integer(note[1], 1, length-onset, 'duration')
            pitch = _integer(note[2], 21, 108, 'piano pitch')
            velocity = self.encode_velocity(note[3])
            notes.append((onset, duration, pitch, velocity))
        notes.sort(key=lambda n: (n[0], n[2]))
        ends = {}
        ids = [self.ids['BAR'], self.ids[f'LEN_{length}']]
        for onset, duration, pitch, velocity in notes:
            if onset < ends.get(pitch, 0):
                raise ValueError(f'same-key overlap at onset {onset}, pitch {pitch}')
            ends[pitch] = onset + duration
            ids.extend(self.ids[f'{name}_{value}'] for name, value in
                       [('POS', onset), ('DUR', duration), ('PITCH', pitch), ('VELOCITY', velocity)])
        return ids + [self.ids['END_BAR']]

    def decode_bar(self, ids):
        try:
            names = [self.tokens[_integer(i, 0, len(self.tokens)-1, 'token id')] for i in ids]
            if len(names) < 3 or names[0] != 'BAR' or names[-1] != 'END_BAR':
                raise ValueError('bar requires BAR and END_BAR boundaries')
            if not names[1].startswith('LEN_') or (len(names)-3) % 4:
                raise ValueError('malformed bar header or note stages')
            length, notes = int(names[1][4:]), []
            for start in range(2, len(names)-1, 4):
                values = []
                for name, token in zip(('POS', 'DUR', 'PITCH', 'VELOCITY'), names[start:start+4]):
                    if not token.startswith(name+'_'):
                        raise ValueError(f'expected {name}, received {token}')
                    values.append(int(token.split('_', 1)[1]))
                values[3] = self.decode_velocity(values[3])
                notes.append(values)
            bar = dict(length=length, notes=notes)
            # Reject invalid ordering/overlaps rather than silently repairing samples.
            if self.encode_bar(bar) != list(ids):
                raise ValueError('bar must use chronological onset,pitch order')
            return bar
        except (TypeError, IndexError, KeyError) as exc:
            raise ValueError('invalid piano bar token stream') from exc

    def encode_piece(self, piece):
        prefix, bars = self._piece(piece)
        return prefix + [t for bar in bars for t in bar] + [self.ids['EOS']]

    def _piece(self, piece):
        if not isinstance(piece, dict) or not isinstance(piece.get('bars'), list) or not piece['bars']:
            raise ValueError('piece requires a nonempty list of bars (bars may have no notes)')
        prefix = self.prefix(piece.get('mode', 'unknown'), piece.get('style', 'unknown'))
        bars = []
        for index, bar in enumerate(piece['bars']):
            try:
                bars.append(self.encode_bar(bar))
            except ValueError as exc:
                raise ValueError(f"piece {piece.get('id', '?')} bar {index}: {exc}") from exc
        return prefix, bars

    def windows(self, piece, max_tokens=1536, context_bars=2):
        _integer(max_tokens, 7, 1_000_000, 'max_tokens')
        _integer(context_bars, 0, 1_000_000, 'context_bars')
        prefix, bars = self._piece(piece)
        # Reserve room for EOS even for an oversized non-final bar. A source bar
        # is either fully representable under this contract or explicitly rejected.
        for index, bar in enumerate(bars):
            if len(prefix) + len(bar) + 1 > max_tokens:
                raise ValueError(f"piece {piece.get('id', '?')} bar {index} too dense to fit: "
                                 f'{len(prefix)+len(bar)+1} tokens exceeds {max_tokens}')
        result, next_bar = [], 0
        while next_bar < len(bars):
            first_context = max(0, next_bar-context_bars)
            while len(prefix) + sum(map(len, bars[first_context:next_bar+1])) + 1 > max_tokens:
                first_context += 1
            ids = prefix + [t for b in bars[first_context:next_bar] for t in b]
            mask = [False] * len(ids)
            while next_bar < len(bars) and len(ids) + len(bars[next_bar]) + 1 <= max_tokens:
                ids.extend(bars[next_bar])
                mask.extend([True] * len(bars[next_bar]))
                next_bar += 1
            if next_bar == len(bars):
                ids.append(self.ids['EOS'])
                mask.append(True)
            result.append((ids, mask))
        return result
