"""A true two-staff piano part, reusing exact note engraving from the exporter."""
from copy import deepcopy
from fractions import Fraction
from xml.etree import ElementTree as ET

from omr.genres.export import musicxml


def _staff(note, number):
    node = ET.Element('staff')
    node.text = str(number)
    before = next((i for i, child in enumerate(note) if child.tag in ('beam', 'notations', 'lyric', 'play')), len(note))
    note.insert(before, node)


def piano_musicxml(composition, title='Piano Solo'):
    if composition.plan.parts != ('piano_rh', 'piano_lh'):
        raise ValueError('piano solo requires exactly right and left hand')
    if any(e.lyric or e.unpitched for e in composition.events):
        raise ValueError('piano solo has no sung lyrics or percussion')
    root = ET.fromstring(musicxml(composition, title=title))
    listed = root.find('part-list')
    first = listed.find('score-part')
    first.find('part-name').text = 'Piano'
    first.find('part-abbreviation').text = 'Pno.'
    first.find('score-instrument/instrument-name').text = 'Acoustic Grand Piano'
    for node in list(listed)[1:]:
        listed.remove(node)
    right, left = root.findall('part')
    for rmeasure, lmeasure in zip(right.findall('measure'), left.findall('measure')):
        attrs = rmeasure.find('attributes')
        if attrs is not None:
            clef = attrs.find('clef')
            clef.set('number', '1')
            staves = ET.Element('staves')
            staves.text = '2'
            attrs.insert(list(attrs).index(clef), staves)
            lclef = deepcopy(lmeasure.find('attributes/clef'))
            if lclef is None:
                lclef = ET.fromstring('<clef><sign>F</sign><line>4</line></clef>')
            lclef.set('number', '2')
            attrs.append(lclef)
        for note in rmeasure.findall('note'):
            _staff(note, 1)
        divisions = int(rmeasure.findtext('attributes/divisions') or right.findtext('measure/attributes/divisions'))
        backup = ET.SubElement(rmeasure, 'backup')
        ET.SubElement(backup, 'duration').text = str(4 * divisions)
        for child in lmeasure:
            if child.tag == 'attributes':
                continue
            child = deepcopy(child)
            if child.tag == 'note':
                voice = child.find('voice')
                if voice is not None:
                    voice.text = str(4 + int(voice.text))
                _staff(child, 2)
            rmeasure.append(child)
    root.remove(left)
    for node in root.findall('identification/miscellaneous/miscellaneous-field'):
        if node.get('name') == 'genre':
            node.text = 'piano_solo'
    for rehearsal in root.findall('.//rehearsal'):
        names = {'intro': 'Intro', 'verse': 'A', 'chorus': "A'", 'bridge': 'B', 'outro': 'Coda'}
        rehearsal.text = names.get(rehearsal.text, rehearsal.text)
    # The new piano form is supplied, separately from the compatibility plan's
    # generic sections. Remove old rehearsal directions when explicit form exists.
    labels = composition.metadata.get('form_labels', {})
    if labels:
        for measure in right.findall('measure'):
            for d in list(measure.findall('direction')):
                if d.find('direction-type/rehearsal') is not None:
                    measure.remove(d)
            bar = int(measure.get('number')) - 1
            label = labels.get(str(bar), labels.get(bar))
            if label:
                d = ET.Element('direction', placement='above')
                ET.SubElement(ET.SubElement(d, 'direction-type'), 'rehearsal').text = label
                index = next((i for i, c in enumerate(measure) if c.tag == 'note'), len(measure))
                measure.insert(index, d)
                dynamics = ET.Element('direction', placement='below')
                kind = {0: 'p', 4: 'mp', 12: 'mf', 20: 'mp', 28: 'p'}.get(bar, 'mp')
                ET.SubElement(ET.SubElement(ET.SubElement(dynamics, 'direction-type'), 'dynamics'), kind)
                ET.SubElement(dynamics, 'staff').text = '1'
                measure.insert(index + 1, dynamics)
    last = right.findall('measure')[-1]
    barline = ET.SubElement(last, 'barline', location='right')
    ET.SubElement(barline, 'bar-style').text = 'light-heavy'
    return '<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(root, encoding='unicode')


def read_piano_xml_events(text):
    """Independent exact event reader: voices, staff, chord onsets and split ties."""
    root = ET.fromstring(text)
    if len(root.findall('part')) != 1:
        raise ValueError('one piano part expected')
    events, tied = [], {}
    divisions = 1
    steps = dict(C=0, D=2, E=4, F=5, G=7, A=9, B=11)
    for bar, measure in enumerate(root.find('part').findall('measure')):
        divisions = int(measure.findtext('attributes/divisions') or divisions)
        cursor, chord_start = Fraction(0), Fraction(0)
        for node in measure:
            if node.tag in ('backup', 'forward'):
                direction = -1 if node.tag == 'backup' else 1
                cursor += direction * Fraction(int(node.findtext('duration')), divisions)
                if not 0 <= cursor <= 4:
                    raise ValueError('invalid piano staff cursor')
            elif node.tag == 'note':
                duration = Fraction(int(node.findtext('duration')), divisions)
                is_chord = node.find('chord') is not None
                onset = chord_start if is_chord else cursor
                if not is_chord:
                    chord_start = cursor
                    cursor += duration
                pitch = node.find('pitch')
                if pitch is None:
                    continue
                midi = (int(pitch.findtext('octave')) + 1) * 12 + steps[pitch.findtext('step')] + int(pitch.findtext('alter') or 0)
                role = 'piano_lh' if node.findtext('staff') == '2' else 'piano_rh'
                key = (role, node.findtext('voice'), midi)
                kinds = {t.get('type') for t in node.findall('tie')}
                if 'stop' in kinds:
                    if key not in tied:
                        raise ValueError('orphan piano tie')
                    prior = events[tied[key]]
                    if prior[0] != bar or prior[1] + prior[2] != onset:
                        raise ValueError('noncontiguous split tie')
                    events[tied[key]] = (bar, prior[1], prior[2] + duration, midi, role)
                else:
                    events.append((bar, onset, duration, midi, role))
                if 'start' in kinds:
                    tied[key] = tied.get(key, len(events) - 1)
                else:
                    tied.pop(key, None)
        if cursor != 4:
            raise ValueError('piano measure is incomplete')
    if tied:
        raise ValueError('hanging piano ties')
    return events
