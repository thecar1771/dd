"""Actual solo-piano scores: joint hands, auditable conversion and grouped splits."""
from __future__ import annotations

import bisect
from collections import Counter, defaultdict, deque
import csv
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import re
import unicodedata

from omr.real_music.data import canonical_notes


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def restricted_license(name):
    compact = re.sub(r'[^A-Z0-9]', '', str(name).upper())
    return any(term in compact for term in ('NONCOMMERCIAL', 'CCBYNC', 'SHAREALIKE', 'CCBYSA'))


def joint_bars(rows, *, measures=None):
    if not rows:
        raise ValueError('no solo piano notes')
    if any(r.get('drum') or r.get('program', 0) not in range(4) for r in rows):
        raise ValueError('input must be solo piano, not an accompaniment or another instrument')
    groups = defaultdict(list)
    meta = {}
    for row in rows:
        bar = int(row['bar'])
        signature = (int(row['bar_ticks']), tuple(row['meter']))
        if bar in meta and meta[bar] != signature:
            raise ValueError('inconsistent piano track measure metadata')
        meta[bar] = signature
        groups[bar].extend(row['notes'])
    count = max(meta) + 1 if measures is None else int(measures)
    report = Counter()
    result = []
    length, meter = meta[min(meta)]
    for bar in range(count):
        if bar in meta:
            length, meter = meta[bar]
        if not 1 <= length <= 192:
            raise ValueError('unsupported piano measure length; preserve raw source')
        for onset, duration, pitch, velocity in groups[bar]:
            if not (0 <= onset < length and 0 < duration <= length - onset and 21 <= pitch <= 108 and 1 <= velocity <= 127):
                raise ValueError('invalid solo-piano note bounds')
        notes, changes = canonical_notes(groups[bar])
        notes.sort(key=lambda n: (n[0], n[2]))
        report.update(changes)
        result.append(dict(length=length, meter=list(meter), notes=notes))
    report['empty_bars_retained'] = sum(not b['notes'] for b in result)
    return result, dict(report)


def midi_bars(path):
    """Canonicalize physical keys across all tracks BEFORE any bar splitting."""
    import mido
    mid = mido.MidiFile(str(path))
    if mid.type == 2 or mid.ticks_per_beat <= 0:
        raise ValueError('synchronous PPQ solo-piano MIDI required')
    programs, active, raw = defaultdict(int), defaultdict(deque), []
    meters, timed, last_clock = {0: (4, 4)}, [], 0
    report = Counter()

    def quant(clock):
        exact = Fraction(clock * 12, mid.ticks_per_beat)
        value = (exact + Fraction(1, 2)).numerator // (exact + Fraction(1, 2)).denominator
        report['quantized_time_fields'] += exact.denominator != 1
        return value

    for track, messages in enumerate(mid.tracks):
        clock = 0
        for order, msg in enumerate(messages):
            clock += msg.time
            timed.append((clock, track, order, msg))
        last_clock = max(last_clock, clock)
    for clock, track, order, msg in sorted(timed, key=lambda item: item[:3]):
        if msg.type == 'time_signature':
            meters[quant(clock)] = (msg.numerator, msg.denominator)
        elif msg.type == 'program_change':
            programs[msg.channel] = msg.program
        elif msg.type == 'control_change' and msg.control == 64:
            report['sustain_messages_not_modeled'] += 1
        elif msg.type == 'note_on' and msg.velocity:
            if msg.channel == 9 or programs[msg.channel] not in range(4):
                raise ValueError('input must be solo piano')
            if not 21 <= msg.note <= 108:
                raise ValueError('source note outside piano keyboard')
            active[(track, msg.channel, msg.note)].append((clock, msg.velocity))
        elif msg.type in ('note_on', 'note_off'):
            queue = active[(track, msg.channel, msg.note)]
            if not queue:
                raise ValueError('unmatched piano note off')
            start, velocity = queue.popleft()
            if clock <= start:
                report['zero_duration_notes_excluded'] += 1
                continue
            onset = quant(start)
            end = max(onset + 1, quant(clock))
            raw.append([onset, end - onset, msg.note, velocity])
    if any(active.values()) or not raw:
        raise ValueError('unmatched piano note on or empty MIDI')
    report['raw_positive_duration_notes'] = len(raw)
    raw_end = max(quant(last_clock), max(o + d for o, d, p, v in raw))
    # This order prevents a clipped note from resurrecting in the next measure.
    notes, changes = canonical_notes(raw)
    report.update(changes)
    report['canonical_absolute_notes'] = len(notes)
    meter_times, bars, starts, position = sorted(meters), [], [], 0
    while position < raw_end:
        index = bisect.bisect_right(meter_times, position) - 1
        num, den = meters[meter_times[index]]
        exact = Fraction(num * 48, den)
        if exact.denominator != 1 or not 1 <= exact <= 192:
            raise ValueError('unrepresentable solo-piano measure length')
        length = int(exact)
        partial = index + 1 < len(meter_times) and meter_times[index + 1] < position + length
        if partial:
            length = meter_times[index + 1] - position
            report['explicit_partial_bars'] += 1
        starts.append(position)
        bars.append(dict(length=length, meter=[num, den], notes=[]))
        position += length
    for onset, duration, pitch, velocity in notes:
        end = onset + duration
        bar = bisect.bisect_right(starts, onset) - 1
        while onset < end:
            stop = min(end, starts[bar] + bars[bar]['length'])
            bars[bar]['notes'].append([onset - starts[bar], stop - onset, pitch, velocity])
            if stop < end:
                report['cross_bar_held_note_splits'] += 1
            onset, bar = stop, bar + 1
    for bar in bars:
        bar['notes'].sort(key=lambda n: (n[0], n[2]))
    report['empty_bars_retained'] = sum(not b['notes'] for b in bars)
    report['meter_changes'] = len(meters) - 1
    report['joint_order'] = 'all physical-key events canonicalized in absolute time before measure splitting'
    report['bar_alignment_policy'] = 'complete explicit MIDI meter timeline including silent and partial measures; undeclared pickup phase not inferred'
    report['cross_bar_policy'] = 'canonical held notes split at actual bar boundaries for tokens; source retained'
    report['sustain_policy'] = 'key-held durations only; controller messages retained in raw source'
    return bars, dict(report)


def _fraction(value, default=0):
    return Fraction(str(value).strip()) if str(value).strip() not in ('', 'nan', 'NA') else Fraction(default)


def dcml_bars(notes_path, measures_path):
    with Path(measures_path).open(encoding='utf-8-sig', newline='') as f:
        measures = list(csv.DictReader(f, delimiter='\t'))
    with Path(notes_path).open(encoding='utf-8-sig', newline='') as f:
        rows = list(csv.DictReader(f, delimiter='\t'))
    # Keep literal score order and actual pickup/ending lengths. Repeats remain
    # notated once; do not pretend this is an unfolded performance transcription.
    locations, bars, position = {}, [], 0
    signature = '4/4'
    for row in measures:
        mc = int(row['mc'])
        signature = row.get('timesig') or signature
        num, den = map(int, signature.split('/'))
        actual = _fraction(row.get('act_dur', ''), Fraction(num, den))
        length = round(actual * 48)
        if not 1 <= length <= 192:
            raise ValueError('unrepresentable DCML measure length')
        if mc in locations:
            raise ValueError('duplicate DCML measure counter')
        locations[mc] = (len(bars), position)
        bars.append(dict(length=length, meter=[num, den], notes=[]))
        position += length
    raw = []
    report = Counter()
    for row in rows:
        if row.get('gracenote', '').strip() not in ('', '0', 'False', 'false', 'nan', 'NA'):
            report['grace_notes_not_modeled'] += 1
            continue
        duration = _fraction(row.get('duration', '')) * 48
        if duration <= 0:
            report['nonpositive_duration_notes_excluded'] += 1
            continue
        index, start = locations[int(row['mc'])]
        exact = _fraction(row['mc_onset']) * 48
        onset, dur = round(exact), max(1, round(duration))
        report['quantized_note_fields'] += int(exact.denominator != 1) + int(duration.denominator != 1)
        pitch = int(row['midi'])
        if not 21 <= pitch <= 108:
            raise ValueError('DCML pitch outside piano keyboard')
        raw.append([start + onset, dur, pitch, 72, row.get('tied', '').strip(),
                    row.get('staff', '1'), row.get('voice', '1')])
    raw.sort(key=lambda n: (n[0], n[2], n[5], n[6]))
    joined, active = [], {}
    for onset, duration, pitch, velocity, tied, staff, voice in raw:
        key = (pitch, staff, voice)
        prior = active.get(key)
        if tied in ('0', '-1') and prior is not None and joined[prior][0] + joined[prior][1] == onset:
            joined[prior][1] += duration
            report['tied_continuations_merged'] += 1
            if tied == '-1':
                active.pop(key, None)
            continue
        if tied in ('0', '-1'):
            report['orphan_tie_continuations'] += 1
        joined.append([onset, duration, pitch, velocity])
        if tied in ('1', '0'):
            active[key] = len(joined) - 1
        else:
            active.pop(key, None)
    joined, changes = canonical_notes(joined)
    report.update(changes)
    starts = [0]
    for bar in bars:
        starts.append(starts[-1] + bar['length'])
    for onset, duration, pitch, velocity in joined:
        end = onset + duration
        if onset < 0 or end > starts[-1] or not bars:
            raise ValueError('DCML note outside measured score')
        bar = bisect.bisect_right(starts, onset) - 1
        while onset < end:
            stop = min(end, starts[bar + 1])
            bars[bar]['notes'].append([onset - starts[bar], stop - onset, pitch, velocity])
            if stop < end:
                report['cross_bar_held_note_splits'] += 1
            onset = stop
            bar += 1
    for bar in bars:
        bar['notes'].sort(key=lambda n: (n[0], n[2]))
    report['empty_bars_retained'] = sum(not b['notes'] for b in bars)
    report['velocity_policy'] = '72: score has no per-note performed velocity; not inferred as a performance label'
    report['repeat_policy'] = 'literal score order, not unfolded repeat performance'
    return bars, dict(report)


_SURNAMES = ('bortkiewicz', 'burgmuller', 'mendelssohn', 'saintsaens', 'rachmaninoff', 'rachmaninov',
             'dvorak', 'bartok', 'poulenc', 'schulhoff', 'medtner', 'kozeluh', 'kozeluch', 'gade', 'balakirev',
             'schumann', 'schubert', 'beethoven', 'scarlatti', 'scriabin', 'chopin', 'mozart', 'bach',
             'haydn', 'liszt', 'brahms', 'grieg', 'debussy', 'ravel', 'clementi', 'czerny', 'hanon',
             'fauré', 'faure', 'joplin', 'tchaikovsky', 'tschaikowsky', 'handel', 'hummel', 'couperin',
             'albeniz', 'granados', 'satie', 'gounod', 'diabelli', 'kullak', 'godowsky', 'reger')


def composer_key(name):
    text = unicodedata.normalize('NFKD', str(name))
    compact = ''.join(c for c in text.lower() if c.isascii() and c.isalpha())
    for surname in _SURNAMES:
        if surname in compact:
            return {'rachmaninov': 'rachmaninoff', 'tschaikowsky': 'tchaikovsky'}.get(surname, surname)
    match = re.match(r'[A-Z][a-z]+', str(name))
    return match.group().lower() if match else compact or 'unknown'


def split_and_deduplicate(pieces, seed=20261028):
    # Composer grouping is deliberately conservative: movements, editions and
    # cross-source arrangements never straddle partitions for known composers.
    accepted, duplicates, seen = [], [], {}
    for piece in pieces:
        content = digest([(b['length'], b['meter'], [n[:3] for n in b['notes']]) for b in piece['bars']])
        if content in seen:
            duplicates.append(dict(id=piece['id'], duplicate_of=seen[content], source=piece['source']))
            continue
        seen[content] = piece['id']
        accepted.append(dict(piece, content_sha256=content, group=composer_key(piece['composer'])))
    weights = Counter()
    for p in accepted:
        weights[p['group']] += sum(len(b['notes']) for b in p['bars'])
    if len(weights) < 3:
        raise ValueError('three independent composer groups required')
    total = sum(weights.values())
    targets = dict(train=.8 * total, validation=.1 * total, test=.1 * total)
    used = Counter()
    assignments = {}
    groups = sorted(weights, key=lambda g: (-weights[g], digest([seed, g])))
    for index, group in enumerate(groups):
        if index == 0:
            split = 'train'
        elif len(groups) - index <= sum(not used[s] for s in targets):
            split = next(s for s in targets if not used[s])
        else:
            split = min(targets, key=lambda s: used[s] / targets[s])
        assignments[group] = split
        used[split] += weights[group]
    # A large composer's collection may fill a held-out budget on its own.
    # Still include several independent composers in each held-out partition.
    if len(groups) >= 9:
        for split in ('validation', 'test'):
            while sum(v == split for v in assignments.values()) < 3:
                choices = [g for g in groups if assignments[g] == 'train']
                group = min(choices, key=lambda g: (weights[g], digest([seed, g])))
                assignments[group] = split
    return [dict(p, split=assignments[p['group']]) for p in accepted], duplicates


def normalize_key(bars):
    """Krumhansl-style histogram estimate; a documented heuristic, not key ground truth."""
    import numpy as np
    hist = np.zeros(12)
    for bar in bars:
        for onset, duration, pitch, velocity in bar['notes']:
            hist[pitch % 12] += duration
    if hist.sum() == 0:
        raise ValueError('empty piano score')
    profiles = {'major': [6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88],
                'minor': [6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17]}
    candidates = [(float(np.corrcoef(hist, np.roll(profile, tonic))[0, 1]), mode, tonic)
                  for mode, profile in profiles.items() for tonic in range(12)]
    score, mode, tonic = max(candidates)
    target = 0 if mode == 'major' else 9
    shifts = sorted({target - tonic, target - tonic - 12, target - tonic + 12}, key=abs)
    pitches = [n[2] for b in bars for n in b['notes']]
    shift = next((s for s in shifts if min(pitches) + s >= 21 and max(pitches) + s <= 108), None)
    if shift is None:
        raise ValueError('key normalization cannot fit all notes on piano keyboard without dropping/folding')
    result = [dict(b, notes=[[o, d, p + shift, v] for o, d, p, v in b['notes']]) for b in bars]
    return result, dict(mode=mode, estimated_original_tonic=tonic, semitone_shift=shift,
                        histogram_correlation=score, method='duration-weighted pitch-class profile estimate, not annotated ground truth')
