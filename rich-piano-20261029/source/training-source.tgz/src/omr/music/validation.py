"""Structural checks applied before accepting generated score events."""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Sequence, Tuple

from omr.schema import NoteEvent


@dataclass(frozen=True)
class ValidationIssue:
    code: str
    message: str
    event_index: int


@dataclass(frozen=True)
class ValidationResult:
    valid: bool
    issues: List[ValidationIssue]


def validate_notes(
    notes: Sequence[NoteEvent],
    meter: Tuple[int, int],
    pitch_range: Tuple[int, int],
    lyric_count: Optional[int] = None,
) -> ValidationResult:
    """Report score errors without rewriting the generated notes."""

    numerator, denominator = meter
    if numerator <= 0 or denominator <= 0:
        raise ValueError("meter values must be positive")
    low_pitch, high_pitch = pitch_range
    if not (0 <= low_pitch <= high_pitch <= 127):
        raise ValueError("pitch range must be inside MIDI bounds")

    measure_duration = numerator * 4 / denominator
    issues: List[ValidationIssue] = []
    previous_start = -1.0
    epsilon = 1e-8
    for index, note in enumerate(notes):
        if (
            lyric_count is not None
            and note.syllable_index is not None
            and note.syllable_index >= lyric_count
        ):
            issues.append(
                ValidationIssue(
                    "DANGLING_SYLLABLE",
                    "note references a lyric syllable that does not exist",
                    index,
                )
            )
        if note.start < previous_start:
            issues.append(
                ValidationIssue(
                    "NON_MONOTONIC_START",
                    "note starts earlier than the previous event",
                    index,
                )
            )
        previous_start = note.start

        if note.duration <= 0:
            issues.append(
                ValidationIssue(
                    "NON_POSITIVE_DURATION", "note duration must be positive", index
                )
            )
            continue
        if note.pitch is not None and not (low_pitch <= note.pitch <= high_pitch):
            issues.append(
                ValidationIssue(
                    "PITCH_OUT_OF_RANGE",
                    f"pitch must be between {low_pitch} and {high_pitch}",
                    index,
                )
            )
        if note.start < 0:
            issues.append(
                ValidationIssue("NEGATIVE_START", "note start must be non-negative", index)
            )
            continue

        position_in_measure = note.start % measure_duration
        if position_in_measure + note.duration > measure_duration + epsilon:
            issues.append(
                ValidationIssue(
                    "MEASURE_OVERFLOW",
                    "note extends beyond its measure without an explicit tie",
                    index,
                )
            )

    return ValidationResult(valid=not issues, issues=issues)
