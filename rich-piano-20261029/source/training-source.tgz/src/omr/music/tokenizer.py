"""A deterministic REMI-like tokenizer for conditioned melody training."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Iterable, List, Optional

from omr.schema import NoteEvent, SongExample


class TokenSequenceError(ValueError):
    """A generated symbolic sequence violates the tokenizer grammar."""

    def __init__(self, code: str, message: str, token_index: int) -> None:
        super().__init__(f"{code} at token {token_index}: {message}")
        self.code = code
        self.token_index = token_index


class OMRTokenizer:
    """Encode global meaning first and quantized monophonic note events second."""

    ticks_per_quarter = 4
    max_bars = 64
    max_positions = 32
    max_duration_ticks = 64
    max_syllables = 256

    languages = ("ko", "en", "ja", "zh", "es", "fr", "de", "it", "pt", "ru", "ar")
    emotions = (
        "warmth",
        "wonder",
        "majesty",
        "awe",
        "serenity",
        "cold",
        "melancholy",
        "joy",
        "sadness",
        "tension",
        "calm",
        "hope",
        "tenderness",
        "mystery",
    )
    meters = ("2/4", "3/4", "4/4", "6/8")
    modes = ("major", "minor", "dorian", "phrygian", "lydian", "mixolydian")
    chord_roots = ("C", "C#", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B")
    chord_qualities = ("", "m", "7", "maj7", "m7", "dim", "aug", "sus4")

    def __init__(self) -> None:
        self.tokens = self._build_tokens()
        self.token_to_id: Dict[str, int] = {
            token: index for index, token in enumerate(self.tokens)
        }
        self.id_to_token: Dict[int, str] = {
            index: token for token, index in self.token_to_id.items()
        }

    @classmethod
    def _build_tokens(cls) -> List[str]:
        tokens = ["PAD", "BOS", "EOS", "UNK"]
        tokens.extend(f"LANG_{language}" for language in cls.languages)
        tokens.append("LANG_OTHER")
        tokens.extend(f"EMOTION_{emotion}" for emotion in cls.emotions)
        tokens.append("EMOTION_OTHER")
        tokens.extend(("TEMPO_SLOW", "TEMPO_MEDIUM", "TEMPO_FAST"))
        tokens.extend(f"METER_{meter.replace('/', '_')}" for meter in cls.meters)
        tokens.append("METER_OTHER")
        tokens.extend(f"MODE_{mode}" for mode in cls.modes)
        tokens.append("MODE_OTHER")
        tokens.extend(
            (
                "LANGUAGE_TEXT_START",
                "PRIMARY_EMOTION_TEXT_START",
                "SECONDARY_EMOTIONS_START",
                "EMOTION_ARC_START",
                "TEMPO_TEXT_START",
                "MODE_TEXT_START",
                "CHORDS_START",
                "LYRICS_START",
                "LYRICS_END",
                "LYRIC_START",
                "LYRIC_END",
                "SURFACE_START",
                "PRONUNCIATION_START",
                "PHONEMES_START",
                "STRESS_START",
                "FIELD_END",
                "ITEM_SEPARATOR",
                "PHRASE_TRUE",
                "PHRASE_FALSE",
                "MUSIC_START",
            )
        )
        tokens.extend(f"VAD_VALENCE_{value}" for value in range(21))
        tokens.extend(f"VAD_AROUSAL_{value}" for value in range(21))
        tokens.extend(f"VAD_DOMINANCE_{value}" for value in range(21))
        tokens.extend(f"KEYWORD_{value}" for value in range(11))
        tokens.extend(f"LYRIC_INDEX_{index}" for index in range(cls.max_syllables))
        tokens.extend(f"BYTE_{value}" for value in range(256))
        tokens.append("CHORD_NONE")
        tokens.extend(
            f"CHORD_{root}{quality}"
            for root in cls.chord_roots
            for quality in cls.chord_qualities
        )
        tokens.extend(f"BAR_{bar}" for bar in range(cls.max_bars))
        tokens.extend(f"POSITION_{position}" for position in range(cls.max_positions))
        tokens.append("NO_SYLLABLE")
        tokens.extend(f"SYLLABLE_{index}" for index in range(cls.max_syllables))
        tokens.append("REST")
        tokens.extend(f"PITCH_{pitch}" for pitch in range(128))
        tokens.extend(
            f"DURATION_{duration}" for duration in range(1, cls.max_duration_ticks + 1)
        )
        return tokens

    @property
    def pad_id(self) -> int:
        return self.token_to_id["PAD"]

    @property
    def vocab_size(self) -> int:
        return len(self.tokens)

    def convert_ids_to_tokens(self, ids: Iterable[int]) -> List[str]:
        return [self.id_to_token.get(token_id, "UNK") for token_id in ids]

    def save_vocab(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(
                {
                    "format": "omr-remi-v2",
                    "ticks_per_quarter": self.ticks_per_quarter,
                    "tokens": self.tokens,
                },
                ensure_ascii=False,
                indent=2,
            )
            + "\n",
            encoding="utf-8",
        )

    def encode(self, example: SongExample) -> List[int]:
        meter = f"{example.meter_numerator}/{example.meter_denominator}"
        if meter not in self.meters:
            raise ValueError("meter is not supported by this tokenizer")
        bar_ticks = round(
            example.meter_numerator
            * (4 / example.meter_denominator)
            * self.ticks_per_quarter
        )
        if bar_ticks <= 0 or bar_ticks > self.max_positions:
            raise ValueError("meter cannot be represented by this tokenizer")

        language_token = (
            f"LANG_{example.language}"
            if example.language in self.languages
            else "LANG_OTHER"
        )
        emotion_token = (
            f"EMOTION_{example.emotion.primary}"
            if example.emotion.primary in self.emotions
            else "EMOTION_OTHER"
        )
        if example.tempo_bpm < 70:
            tempo_token = "TEMPO_SLOW"
        elif example.tempo_bpm <= 120:
            tempo_token = "TEMPO_MEDIUM"
        else:
            tempo_token = "TEMPO_FAST"
        meter_token = f"METER_{meter.replace('/', '_')}"
        mode_token = (
            f"MODE_{example.mode}" if example.mode in self.modes else "MODE_OTHER"
        )
        chord_token = self._chord_token(example.chords[0] if example.chords else None)

        encoded_tokens = [
            "BOS",
            language_token,
            "LANGUAGE_TEXT_START",
            *self._encode_text(example.language),
            "FIELD_END",
            emotion_token,
            "PRIMARY_EMOTION_TEXT_START",
            *self._encode_text(example.emotion.primary),
            "FIELD_END",
            "SECONDARY_EMOTIONS_START",
            *self._encode_items(example.emotion.secondary),
            "FIELD_END",
            f"VAD_VALENCE_{self._quantize_vad(example.emotion.valence)}",
            f"VAD_AROUSAL_{self._quantize_vad(example.emotion.arousal)}",
            f"VAD_DOMINANCE_{self._quantize_vad(example.emotion.dominance)}",
            "EMOTION_ARC_START",
            *self._encode_items(example.emotion.arc),
            "FIELD_END",
            tempo_token,
            "TEMPO_TEXT_START",
            *self._encode_text(str(example.tempo_bpm)),
            "FIELD_END",
            meter_token,
            mode_token,
            "MODE_TEXT_START",
            *self._encode_text(example.mode),
            "FIELD_END",
            chord_token,
            "CHORDS_START",
            *self._encode_items(example.chords),
            "FIELD_END",
            "LYRICS_START",
        ]
        for lyric_index, lyric in enumerate(example.lyrics):
            if lyric_index >= self.max_syllables:
                raise ValueError("lyric count is outside tokenizer range")
            encoded_tokens.extend(
                [
                    "LYRIC_START",
                    f"LYRIC_INDEX_{lyric_index}",
                    "SURFACE_START",
                    *self._encode_text(lyric.surface),
                    "FIELD_END",
                    "PRONUNCIATION_START",
                    *self._encode_text(lyric.pronunciation),
                    "FIELD_END",
                    "PHONEMES_START",
                    *self._encode_items(lyric.phonemes),
                    "FIELD_END",
                    "STRESS_START",
                    *self._encode_items([str(value) for value in lyric.stress]),
                    "FIELD_END",
                    f"KEYWORD_{min(10, int(lyric.keyword_weight * 10 + 0.5))}",
                    "PHRASE_TRUE" if lyric.phrase_boundary else "PHRASE_FALSE",
                    "LYRIC_END",
                ]
            )
        encoded_tokens.extend(["LYRICS_END", "MUSIC_START"])
        for note in example.notes:
            start_ticks = self._quantize(note.start, "start")
            duration_ticks = self._quantize(note.duration, "duration")
            if duration_ticks < 1 or duration_ticks > self.max_duration_ticks:
                raise ValueError("note duration is outside tokenizer range")
            bar, position = divmod(start_ticks, bar_ticks)
            if bar >= self.max_bars or position >= self.max_positions:
                raise ValueError("note start is outside tokenizer range")
            if note.syllable_index is None:
                syllable_token = "NO_SYLLABLE"
            elif note.syllable_index >= len(example.lyrics):
                raise ValueError("syllable index does not reference an existing lyric")
            else:
                syllable_token = f"SYLLABLE_{note.syllable_index}"
            pitch_token = "REST" if note.pitch is None else f"PITCH_{note.pitch}"
            encoded_tokens.extend(
                [
                    f"BAR_{bar}",
                    f"POSITION_{position}",
                    syllable_token,
                    pitch_token,
                    f"DURATION_{duration_ticks}",
                ]
            )
        encoded_tokens.append("EOS")
        return [self.token_to_id[token] for token in encoded_tokens]

    def decode(self, ids: List[int]) -> List[NoteEvent]:
        tokens = self.convert_ids_to_tokens(ids)
        if not tokens or tokens[0] != "BOS":
            raise TokenSequenceError("INVALID_TOKEN_ORDER", "BOS must be first", 0)
        if tokens[-1] != "EOS":
            raise TokenSequenceError(
                "INVALID_TOKEN_ORDER", "EOS must be last", max(0, len(tokens) - 1)
            )
        if tokens.count("MUSIC_START") != 1:
            raise TokenSequenceError(
                "INVALID_TOKEN_ORDER", "exactly one MUSIC_START is required", 0
            )
        music_start = tokens.index("MUSIC_START")
        lyric_indices = [
            int(token.removeprefix("LYRIC_INDEX_"))
            for token in tokens[:music_start]
            if token.startswith("LYRIC_INDEX_")
        ]
        lyric_count = max(lyric_indices, default=-1) + 1
        bar_ticks = 4 * self.ticks_per_quarter
        for token in tokens[:music_start]:
            if token == "METER_OTHER":
                raise TokenSequenceError(
                    "UNSUPPORTED_METER", "METER_OTHER cannot be decoded safely", 0
                )
            if token.startswith("METER_") and token != "METER_OTHER":
                numerator, denominator = token.removeprefix("METER_").split("_")
                bar_ticks = round(
                    int(numerator) * (4 / int(denominator)) * self.ticks_per_quarter
                )
                break

        notes: List[NoteEvent] = []
        index = music_start + 1
        music_token_count = len(tokens) - index - 1
        if music_token_count % 5 != 0:
            raise TokenSequenceError(
                "INVALID_TOKEN_ORDER", "music events must contain five tokens", index
            )
        while index < len(tokens) - 1:
            group = tokens[index : index + 5]
            if not (
                group[0].startswith("BAR_")
                and
                group[1].startswith("POSITION_")
                and (group[2] == "NO_SYLLABLE" or group[2].startswith("SYLLABLE_"))
                and (group[3] == "REST" or group[3].startswith("PITCH_"))
                and group[4].startswith("DURATION_")
            ):
                raise TokenSequenceError(
                    "INVALID_TOKEN_ORDER", "invalid music event token group", index
                )
            bar = int(group[0].removeprefix("BAR_"))
            position = int(group[1].removeprefix("POSITION_"))
            if position >= bar_ticks:
                raise TokenSequenceError(
                    "INVALID_POSITION", "position falls outside the measure", index + 1
                )
            syllable_index: Optional[int] = None
            if group[2] != "NO_SYLLABLE":
                syllable_index = int(group[2].removeprefix("SYLLABLE_"))
                if syllable_index >= lyric_count:
                    raise TokenSequenceError(
                        "DANGLING_SYLLABLE",
                        "music event references a missing lyric",
                        index + 2,
                    )
            pitch: Optional[int] = None
            if group[3] != "REST":
                pitch = int(group[3].removeprefix("PITCH_"))
            duration_ticks = int(group[4].removeprefix("DURATION_"))
            notes.append(
                NoteEvent(
                    pitch=pitch,
                    start=(bar * bar_ticks + position) / self.ticks_per_quarter,
                    duration=duration_ticks / self.ticks_per_quarter,
                    syllable_index=syllable_index,
                )
            )
            index += 5
        return notes

    def _quantize(self, value: float, field_name: str) -> int:
        ticks = round(value * self.ticks_per_quarter)
        if abs(ticks / self.ticks_per_quarter - value) > 1e-6:
            raise ValueError(f"{field_name} must align to sixteenth-note resolution")
        return ticks

    def _chord_token(self, chord: Optional[str]) -> str:
        if chord is None:
            return "CHORD_NONE"
        candidate = f"CHORD_{chord}"
        return candidate if candidate in self.token_to_id else "CHORD_NONE"

    def _encode_text(self, value: str) -> List[str]:
        return [f"BYTE_{byte}" for byte in value.encode("utf-8")]

    def _encode_items(self, values: Iterable[str]) -> List[str]:
        tokens: List[str] = []
        for index, value in enumerate(values):
            if index:
                tokens.append("ITEM_SEPARATOR")
            tokens.extend(self._encode_text(value))
        return tokens

    @staticmethod
    def _quantize_vad(value: float) -> int:
        return max(0, min(20, int((value + 1.0) * 10)))
